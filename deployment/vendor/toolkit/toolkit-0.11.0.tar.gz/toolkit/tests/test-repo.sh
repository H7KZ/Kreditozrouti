#!/usr/bin/env bash
# Repository integration: toolkit.conf parsing, install (control copy, units, sudo rule), jobs,
# boot reconcile and release target resolution. Needs root on Ubuntu 26.04 (CI or a container).
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
toolkit="$toolkit_root/bin/toolkit"
version="$(cat "$toolkit_root/VERSION")"
((EUID == 0)) || {
  printf 'test-repo.sh needs root\n' >&2
  exit 1
}
work="$(mktemp -d)"
trap 'rm -rf -- "$work" /opt/toolkit/demo; rm -f /etc/sudoers.d/toolkit-runner-tkdemo' EXIT
fail() {
  printf 'FAIL: %s\n' "$*" >&2
  exit 1
}

id tkdemo >/dev/null 2>&1 || useradd -m tkdemo
repo="$work/repo"
mkdir -p "$repo/deployment/vendor/toolkit" "$repo/deployment/backup" "$repo/deployment/monitoring" "$repo/scripts" "$work/units" "$work/bin"
for file in toolkit toolkit.lock vendor/toolkit/validate-lock.sh vendor/toolkit/log.sh vendor/toolkit/toolkit.lock \
  "vendor/toolkit/toolkit-$version.tar.gz" "vendor/toolkit/toolkit-$version.tar.gz.sha256"; do
  printf 'managed %s\n' "$file" >"$repo/deployment/$file"
done
printf 'BACKUP_COMPONENTS=(db)\n' >"$repo/deployment/backup/components.sh"
printf 'SECRET=1\n' >"$repo/deployment/backup/.env"
printf 'printf "%%s %%s %%s\\n" "$TOOLKIT_REPOSITORY" "$TOOLKIT_DEPLOY_USER" "$TOOLKIT_DEPLOY_HOME" >"%s/job.out"\n' "$work" >"$repo/deployment/monitoring/retain.sh"
printf 'touch "%s/before.ran"\n' "$work" >"$repo/scripts/firewall.sh"
cat >"$repo/deployment/toolkit.conf" <<'CONF'
# demo repository
REPOSITORY=demo
RELEASE_TARGETS=production:demo/versions/production development:demo/versions/development
RECONCILE_BEFORE=scripts/firewall.sh
BACKUP_COMPONENTS=deployment/backup/components.sh
BACKUP_4H_AT=*-*-* 00/4:15:00 UTC
BACKUP_DAILY_AT=*-*-* 01:15:00 UTC
JOBS=umami-retention
JOB_UMAMI_RETENTION_RUN=deployment/monitoring/retain.sh
JOB_UMAMI_RETENTION_ENVIRONMENT=monitoring
JOB_UMAMI_RETENTION_AT=*-*-* 03:17:00 UTC
CONF
# The release controller is replaced by a recorder: only argument mapping is under test here.
cat >"$work/bin/python3" <<STUB
#!/bin/bash
printf '%s\n' "\$*" >>"$work/python.calls"
STUB
chmod +x "$work/bin/python3"
export TOOLKIT_UNIT_DIR="$work/units" TOOLKIT_SKIP_BACKUP_TOOLS=1
printf 'old\n' >"$work/units/toolkit-demo-retired.service"

bash "$toolkit" --repo-root "$repo" install --deploy-user tkdemo >"$work/install.out" 2>&1 || {
  cat "$work/install.out" >&2
  fail 'install failed'
}
control=/opt/toolkit/demo
for path in deployment/toolkit deployment/toolkit.conf deployment/vendor/toolkit/log.sh "deployment/vendor/toolkit/toolkit-$version.tar.gz" \
  deployment/backup/components.sh deployment/monitoring/retain.sh scripts/firewall.sh; do
  [[ -f "$control/$path" ]] || fail "control copy lacks $path"
done
[[ ! -e "$control/deployment/backup/.env" ]] || fail 'control copy must not include dotenv files'
grep -qx 'DEPLOY_USER=tkdemo' "$control/host.env" || fail 'host.env lacks the deploy user'
[[ "$(stat -c '%U' "$control/deployment/toolkit")" == root ]] || fail 'control copy must be root-owned'
grep -qx "tkdemo ALL=(root) NOPASSWD: /usr/local/libexec/toolkit-run-bundle \*" /etc/sudoers.d/toolkit-runner-tkdemo || fail 'sudo rule missing'
[[ -x /usr/local/libexec/toolkit-run-bundle ]] || fail 'runner missing'
for unit in toolkit-demo-reconcile.service toolkit-demo-backup@.service toolkit-demo-backup@4h.timer toolkit-demo-backup@daily.timer \
  toolkit-demo-umami-retention.service toolkit-demo-umami-retention.timer; do
  [[ -f "$work/units/$unit" ]] || fail "unit $unit missing"
done
[[ ! -e "$work/units/toolkit-demo-retired.service" ]] || fail 'undeclared unit was kept'
grep -qx "ExecStart=$control/deployment/toolkit backup run %i" "$work/units/toolkit-demo-backup@.service" || fail 'backup ExecStart'
grep -qx 'OnCalendar=\*-\*-\* 00/4:15:00 UTC' "$work/units/toolkit-demo-backup@4h.timer" || fail 'backup schedule'
grep -qx "ExecStart=$control/deployment/toolkit job umami-retention" "$work/units/toolkit-demo-umami-retention.service" || fail 'job ExecStart'
grep -q 'systemctl enable --now toolkit-demo-backup@4h.timer' "$work/install.out" || fail 'install should print enable commands'

# Jobs run under the repository lock with the deploy identity, from the control copy.
bash "$toolkit" --repo-root "$control" job umami-retention >/dev/null 2>&1 || fail 'job failed'
read -r job_repo job_user job_home <"$work/job.out"
[[ "$job_repo $job_user $job_home" == "demo tkdemo /home/tkdemo" ]] || fail "job environment: $(cat "$work/job.out")"

# Boot reconcile: pre-step once, then every target in order with resolved roots.
PATH="$work/bin:$PATH" bash "$toolkit" --repo-root "$control" reconcile >/dev/null 2>&1 || fail 'reconcile failed'
[[ -f "$work/before.ran" ]] || fail 'RECONCILE_BEFORE did not run'
grep -q 'reconcile --repository demo --environment production --root /home/tkdemo/demo/versions/production --user tkdemo' "$work/python.calls" || fail 'production reconcile args'
grep -q 'reconcile --repository demo --environment development --root /home/tkdemo/demo/versions/development --user tkdemo' "$work/python.calls" || fail 'development reconcile args'

# Release by target name: the sudo caller is the deploy user.
: >"$work/python.calls"
SUDO_USER=tkdemo PATH="$work/bin:$PATH" bash "$toolkit" --repo-root "$repo" release rollback production --release-id previous >/dev/null 2>&1 || fail 'release by target failed'
grep -q 'rollback --repository demo --environment production --root /home/tkdemo/demo/versions/production --user tkdemo --release-id previous' "$work/python.calls" ||
  fail "release args: $(cat "$work/python.calls")"

# Configuration errors are reported, not guessed.
printf 'JOB_ORPHAN_RUN=x.sh\n' >>"$repo/deployment/toolkit.conf"
bash "$toolkit" --repo-root "$repo" doctor >"$work/doctor.out" 2>&1 && fail 'orphan job key accepted'
grep -q 'belongs to a job missing from JOBS' "$work/doctor.out" || fail "orphan job message: $(cat "$work/doctor.out")"
sed -i '$d' "$repo/deployment/toolkit.conf"
bash "$toolkit" --repo-root "$repo" doctor >"$work/doctor.out" 2>&1 || true
grep -q '^ok   demo: installed copy matches this checkout' "$work/doctor.out" || fail "doctor should match the install: $(cat "$work/doctor.out")"
grep -q 'line [0-9]*:' "$work/doctor.out" && fail "doctor shell error: $(cat "$work/doctor.out")"
grep -q 'toolkit-demo-backup@4h.timer' "$work/doctor.out" || fail "doctor should report units: $(cat "$work/doctor.out")"

printf 'toolkit repository integration checks passed\n'
