#!/usr/bin/env bash
# Host maintenance under every repository lock and the host lock: package updates, journal
# retention and a short health report. Docker resources are never pruned here.

toolkit_maintenance_usage() {
  cat <<'USAGE'
Usage: sudo deployment/toolkit maintenance [--reboot] [--dry-run]
  --reboot   reboot one minute after finishing when packages require it
  --dry-run  report pending upgrades without installing them
USAGE
}

toolkit_maintenance_locked() {
  local reboot="$1" dry_run="$2"
  export DEBIAN_FRONTEND=noninteractive
  toolkit_log info 'maintenance apt update'
  apt-get update -q || return 1
  if ((dry_run == 1)); then
    apt-get -s dist-upgrade | grep '^Inst ' || toolkit_log info 'maintenance no pending upgrades'
    return 0
  fi
  toolkit_log info 'maintenance apt upgrade'
  apt-get -y -q -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold dist-upgrade || return 1
  apt-get -y -q autoremove || return 1
  apt-get -q clean
  journalctl --vacuum-time=14d >/dev/null 2>&1 || toolkit_log warn 'maintenance journal vacuum failed'
  toolkit_log info "maintenance health failed_units=$(systemctl list-units --failed --no-legend --plain 2>/dev/null | wc -l) root_use=$(df -P / | awk 'NR == 2 {print $5}') load=\"$(cut -d' ' -f1-3 /proc/loadavg)\""
  if [[ -f /var/run/reboot-required ]]; then
    if ((reboot == 1)); then
      toolkit_log warn 'maintenance reboot required; rebooting in one minute'
      shutdown -r +1 'toolkit maintenance: packages require a reboot' || return 1
    else
      toolkit_log warn "maintenance reboot required by: $(tr '\n' ' ' </var/run/reboot-required.pkgs 2>/dev/null)"
    fi
  fi
}

toolkit_maintenance() {
  local reboot=0 dry_run=0
  while (($#)); do
    case "$1" in
    --reboot) reboot=1 ;;
    --dry-run) dry_run=1 ;;
    -h | --help)
      toolkit_maintenance_usage
      return 0
      ;;
    *) toolkit_die "unknown maintenance option: $1" ;;
    esac
    shift
  done
  toolkit_require_root
  toolkit_with_locks --all-repositories --host-window --action maintenance --timeout 3600 -- \
    toolkit_maintenance_locked "$reboot" "$dry_run"
}
