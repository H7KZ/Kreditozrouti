#!/usr/bin/env bash
# Restore drill: fetch the newest backup of each component, restore it into a throwaway container
# of the production image (no network, no application containers) and sanity-check the result.
#
# Components declare how in their list:  BACKUP_DRILL[name]="<kind> <image source>"
#   kinds: postgres-tar (globals.sql + db.dump tar), postgres (custom-format dump), mysql, mariadb,
#          redis (RDB file), archive (tar of files), skip
#   image source: a Compose file or directory, relative to the repository root, searched for the
#          kind's image (postgres:, mysql:, mariadb:, redis:), or a literal image reference.
# An optional `drill_check_<component with _>` function in the list runs after the default
# checks with the container name (or, for archives, the extracted directory) and fails the drill
# by returning non-zero.

TOOLKIT_DRILL_WORK=''
declare -ga TOOLKIT_DRILL_CONTAINERS=()

toolkit_drill_log() {
  printf 'drill: %s\n' "$*" >&2
}

toolkit_drill_fail() {
  toolkit_drill_log "FAILED $*"
  exit 1
}

toolkit_drill_image() {
  local kind="$1" source="$2" prefix image root="${TOOLKIT_REPO_ROOT:-$PWD}"
  case "$kind" in
  postgres | postgres-tar) prefix='postgres:' ;;
  *) prefix="$kind:" ;;
  esac
  if [[ -e "$root/$source" ]]; then
    image="$(grep -rhoE "image: *['\"]?${prefix}[^ '\"]+" "$root/$source" | head -1 | sed -E "s/^image: *['\"]?//")"
    [[ -n "$image" ]] || toolkit_drill_fail "no ${prefix} image in $source"
    printf '%s\n' "$image"
  else
    printf '%s\n' "$source"
  fi
}

toolkit_drill_wait() {
  local name="$1"
  shift
  for _ in $(seq 1 90); do
    docker exec "$name" "$@" >/dev/null 2>&1 && return 0
    sleep 2
  done
  toolkit_drill_fail "$name did not become ready"
}

toolkit_drill_start() {
  local name="$1"
  shift
  docker run -d --name "$name" --network none "$@" >/dev/null || toolkit_drill_fail "cannot start $name"
  TOOLKIT_DRILL_CONTAINERS+=("$name")
}

toolkit_drill_counts() {
  local component="$1" tables="$2" rows="$3"
  ((tables > 0 && rows > 0)) || toolkit_drill_fail "$component: restored database looks empty (tables=$tables rows=$rows)"
  toolkit_drill_log "$component ok tables=$tables rows=$rows"
}

toolkit_drill_postgres() {
  local component="$1" image="$2" file="$3" kind="$4"
  local name="drill-$component-$$"
  toolkit_drill_start "$name" -e POSTGRES_PASSWORD=drill "$image"
  toolkit_drill_wait "$name" pg_isready -U postgres
  if [[ "$kind" == postgres-tar ]]; then
    mkdir "$TOOLKIT_DRILL_WORK/$component" && tar -C "$TOOLKIT_DRILL_WORK/$component" -xf "$file" || toolkit_drill_fail "$component: not a valid tar"
    [[ -s "$TOOLKIT_DRILL_WORK/$component/db.dump" && -s "$TOOLKIT_DRILL_WORK/$component/globals.sql" ]] || toolkit_drill_fail "$component: archive misses db.dump or globals.sql"
    docker cp "$TOOLKIT_DRILL_WORK/$component/." "$name:/tmp/restore"
    # Roles that already exist are expected to error; the data restore must not.
    docker exec "$name" psql -U postgres -X -q -f /tmp/restore/globals.sql >/dev/null 2>&1 || true
  else
    docker exec "$name" mkdir -p /tmp/restore && docker cp "$file" "$name:/tmp/restore/db.dump"
  fi
  docker exec "$name" createdb -U postgres restored
  docker exec "$name" pg_restore --exit-on-error --no-owner --no-privileges -U postgres -d restored /tmp/restore/db.dump ||
    toolkit_drill_fail "$component: pg_restore failed"
  docker exec "$name" psql -U postgres -d restored -X -q -c 'ANALYZE' >/dev/null
  toolkit_drill_counts "$component" \
    "$(docker exec "$name" psql -U postgres -d restored -XAtc "SELECT count(*) FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")" \
    "$(docker exec "$name" psql -U postgres -d restored -XAtc 'SELECT coalesce(sum(n_live_tup),0)::bigint FROM pg_stat_user_tables')"
  TOOLKIT_DRILL_TARGET="$name"
}

toolkit_drill_mysql() {
  local component="$1" image="$2" file="$3" kind="$4" client=mysql
  local name="drill-$component-$$"
  local where="table_schema NOT IN ('mysql','information_schema','performance_schema','sys')"
  [[ -s "$file" ]] || toolkit_drill_fail "$component: empty dump"
  [[ "$kind" != mariadb ]] || client=mariadb
  # MYSQL_DATABASE gives dumps without CREATE DATABASE a default schema; --databases dumps make their own.
  toolkit_drill_start "$name" -e MYSQL_ROOT_PASSWORD=drill -e MARIADB_ROOT_PASSWORD=drill -e MYSQL_DATABASE=restored -e MARIADB_DATABASE=restored "$image"
  # Probe over TCP: the init-time throwaway server only listens on a socket.
  toolkit_drill_wait "$name" sh -c "MYSQL_PWD=drill $client -h127.0.0.1 -uroot -e 'SELECT 1'"
  docker exec -i "$name" sh -c "MYSQL_PWD=drill exec $client -uroot restored" <"$file" || toolkit_drill_fail "$component: import failed"
  toolkit_drill_counts "$component" \
    "$(docker exec "$name" sh -c "MYSQL_PWD=drill $client -uroot -N -e \"SELECT COUNT(*) FROM information_schema.tables WHERE $where\"")" \
    "$(docker exec "$name" sh -c "MYSQL_PWD=drill $client -uroot -N -e \"SELECT COALESCE(SUM(table_rows),0) FROM information_schema.tables WHERE $where\"")"
  TOOLKIT_DRILL_TARGET="$name"
}

toolkit_drill_redis() {
  local component="$1" image="$2" file="$3" keys
  local name="drill-$component-$$"
  [[ "$(head -c 5 "$file")" == REDIS ]] || toolkit_drill_fail "$component: not an RDB file"
  docker create --name "$name" --network none "$image" redis-server --appendonly no --dir /data --dbfilename dump.rdb >/dev/null
  TOOLKIT_DRILL_CONTAINERS+=("$name")
  docker cp "$file" "$name:/data/dump.rdb"
  docker start "$name" >/dev/null
  toolkit_drill_wait "$name" redis-cli ping
  keys="$(docker exec "$name" redis-cli DBSIZE | awk '{print $NF}')"
  ((keys > 0)) || toolkit_drill_fail "$component: restored database is empty"
  toolkit_drill_log "$component ok keys=$keys"
  TOOLKIT_DRILL_TARGET="$name"
}

toolkit_drill_archive() {
  local component="$1" file="$2" count
  count="$(tar -tf "$file" | grep -vc '/$' || true)"
  ((count > 0)) || toolkit_drill_fail "$component: archive holds no files"
  mkdir "$TOOLKIT_DRILL_WORK/$component.files" && tar -C "$TOOLKIT_DRILL_WORK/$component.files" -xf "$file" || toolkit_drill_fail "$component: archive does not extract"
  toolkit_drill_log "$component ok files=$count"
  TOOLKIT_DRILL_TARGET="$TOOLKIT_DRILL_WORK/$component.files"
}

toolkit_drill_component() {
  local repository="$1" component="$2" spec kind source file hook
  spec="${BACKUP_DRILL[$component]:-}"
  [[ -n "$spec" ]] || toolkit_drill_fail "$component has no BACKUP_DRILL entry in the component list"
  read -r kind source <<<"$spec"
  [[ "$kind" != skip ]] || {
    toolkit_drill_log "$component skipped"
    return 0
  }
  file="$TOOLKIT_DRILL_WORK/$component.restore"
  toolkit_backup_fetch "$repository" "$component" -o "$file" >/dev/null
  TOOLKIT_DRILL_TARGET=''
  case "$kind" in
  postgres | postgres-tar) toolkit_drill_postgres "$component" "$(toolkit_drill_image "$kind" "$source")" "$file" "$kind" ;;
  mysql | mariadb) toolkit_drill_mysql "$component" "$(toolkit_drill_image "$kind" "$source")" "$file" "$kind" ;;
  redis) toolkit_drill_redis "$component" "$(toolkit_drill_image redis "$source")" "$file" ;;
  archive) toolkit_drill_archive "$component" "$file" ;;
  *) toolkit_drill_fail "$component: unknown drill kind $kind" ;;
  esac
  hook="drill_check_${component//-/_}"
  if declare -F "$hook" >/dev/null; then
    "$hook" "$TOOLKIT_DRILL_TARGET" || toolkit_drill_fail "$component: $hook rejected the restore"
    toolkit_drill_log "$component check $hook ok"
  fi
  rm -rf -- "$file" "${TOOLKIT_DRILL_WORK:?}/$component" "$TOOLKIT_DRILL_WORK/$component.files"
}

toolkit_drill_cleanup() {
  local status=$?
  ((${#TOOLKIT_DRILL_CONTAINERS[@]} == 0)) || docker rm -f "${TOOLKIT_DRILL_CONTAINERS[@]}" >/dev/null 2>&1 || true
  [[ -z "$TOOLKIT_DRILL_WORK" ]] || rm -rf -- "$TOOLKIT_DRILL_WORK"
  toolkit_backup_ping "${BACKUP_HC_DRILL_URL:-}" "/$status"
}

toolkit_backup_drill() {
  (($# >= 1)) || toolkit_die 'usage: toolkit backup drill [repo] [component ...]'
  local repository="$1" component
  shift
  local -a selected=("$@")
  toolkit_backup_load_config "$repository"
  toolkit_backup_load_components
  command -v docker >/dev/null 2>&1 || toolkit_die 'drill needs docker'
  ((${#selected[@]})) || selected=("${BACKUP_COMPONENTS[@]}")
  # A subshell owns the cleanup trap, so containers go away even when a fetch dies.
  (
    TOOLKIT_DRILL_WORK="$(mktemp -d)"
    trap toolkit_drill_cleanup EXIT
    for component in "${selected[@]}"; do
      [[ " ${BACKUP_COMPONENTS[*]} " == *" $component "* ]] || toolkit_drill_fail "unknown component: $component"
      toolkit_drill_component "$repository" "$component"
    done
    toolkit_drill_log "all ${#selected[@]} components restored"
  )
}
