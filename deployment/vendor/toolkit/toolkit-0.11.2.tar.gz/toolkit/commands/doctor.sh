#!/usr/bin/env bash
# Read-only host and repository diagnostics. Every line is "<ok|warn|fail> <area>: <detail>";
# fail lines make the command exit 1. Nothing is changed, locks are probed without waiting.

TOOLKIT_DOCTOR_FAILURES=0

toolkit_doctor_line() {
  local level="$1" area="$2"
  shift 2
  printf '%-4s %s: %s\n' "$level" "$area" "$*"
  [[ "$level" != fail ]] || TOOLKIT_DOCTOR_FAILURES=1
}

toolkit_doctor_unit() {
  local repo="$1" unit="$2" enabled state result last
  if [[ ! -f "$TOOLKIT_UNIT_DIR/$unit" ]]; then
    toolkit_doctor_line fail "$repo" "$unit is not installed; run: sudo deployment/toolkit install --deploy-user <user>"
    return
  fi
  command -v systemctl >/dev/null 2>&1 || return 0
  [[ "$unit" == *@.service ]] && return 0
  enabled="$(systemctl is-enabled "$unit" 2>/dev/null || true)"
  if [[ "$unit" == *.timer ]]; then
    state="$(systemctl show -p NextElapseUSecRealtime --value "$unit" 2>/dev/null || true)"
    [[ "$enabled" == enabled ]] && toolkit_doctor_line ok "$repo" "$unit enabled, next ${state:-unknown}" ||
      toolkit_doctor_line warn "$repo" "$unit is $enabled; enable after a manual run: systemctl enable --now $unit"
    return
  fi
  result="$(systemctl show -p Result --value "$unit" 2>/dev/null || true)"
  last="$(systemctl show -p ExecMainExitTimestamp --value "$unit" 2>/dev/null || true)"
  if [[ "$result" != success && -n "$last" ]]; then
    toolkit_doctor_line fail "$repo" "$unit last run failed ($result at $last); see: journalctl -u $unit -n 100"
  elif [[ "$enabled" == disabled ]]; then
    toolkit_doctor_line warn "$repo" "$unit is disabled (will not run at boot); enable: systemctl enable $unit"
  else
    toolkit_doctor_line ok "$repo" "$unit ${enabled:-unknown}, last ${last:-never}"
  fi
}

toolkit_doctor_backup_instance() {
  local repo="$1" cadence="$2" unit result last
  unit="toolkit-$repo-backup@$cadence.service"
  command -v systemctl >/dev/null 2>&1 || return 0
  result="$(systemctl show -p Result --value "$unit" 2>/dev/null || true)"
  last="$(systemctl show -p ExecMainExitTimestamp --value "$unit" 2>/dev/null || true)"
  if [[ -z "$last" ]]; then
    toolkit_doctor_line warn "$repo" "$cadence backup never ran; try: sudo systemctl start $unit"
  elif [[ "$result" != success ]]; then
    toolkit_doctor_line fail "$repo" "$cadence backup failed at $last; see: journalctl -u $unit -n 200"
  else
    toolkit_doctor_line ok "$repo" "$cadence backup succeeded at $last"
  fi
}

toolkit_doctor_backups() {
  local repo="$1" file key missing=() tool owner
  file="$(toolkit_repo_env_file "$repo")"
  [[ ! -f "/etc/toolkit/backup/$repo.env" ]] ||
    toolkit_doctor_line warn "$repo" "legacy /etc/toolkit/backup/$repo.env: sudo mv /etc/toolkit/backup/$repo.env $file"
  if [[ ! -f "$file" ]]; then
    toolkit_doctor_line fail "$repo" "backups are declared but $file is missing (root, 0600)"
  elif [[ ! -r "$file" ]]; then
    toolkit_doctor_line warn "$repo" "cannot read $file; rerun doctor with sudo"
  else
    owner="$(stat -c '%u:%a' "$file")"
    [[ "$owner" == 0:600 ]] || toolkit_doctor_line fail "$repo" "$file must be root-owned mode 0600 (is $owner)"
    for key in BACKUP_BUCKET BACKUP_B2_KEY_ID BACKUP_B2_KEY BACKUP_AGE_RECIPIENT; do
      grep -q "^$key=." "$file" || missing+=("$key")
    done
    ((${#missing[@]} == 0)) && toolkit_doctor_line ok "$repo" "$file has the required keys" ||
      toolkit_doctor_line fail "$repo" "$file lacks ${missing[*]}"
    grep -q '^BACKUP_HC_DAILY_URL=.' "$file" || toolkit_doctor_line warn "$repo" 'no BACKUP_HC_*_URL: failed backups will not alert'
    ! grep -q '^BACKUP_AGE_IDENTITY=' "$file" || toolkit_doctor_line fail "$repo" 'BACKUP_AGE_IDENTITY (the private key) must never be on the host'
    ! grep -q '^BACKUP_COMPONENTS_FILE=' "$file" || toolkit_doctor_line warn "$repo" "BACKUP_COMPONENTS_FILE in $file is ignored (toolkit.conf declares the list); remove it"
  fi
  for tool in age rclone zstd curl; do
    command -v "$tool" >/dev/null 2>&1 || toolkit_doctor_line fail "$repo" "backup tool $tool missing; run: sudo deployment/toolkit backup install-tools"
  done
  if (
    # shellcheck disable=SC2034 # read by toolkit_backup_load_components
    BACKUP_COMPONENTS_FILE="$TOOLKIT_REPO_ROOT/${TOOLKIT_REPO[BACKUP_COMPONENTS]}"
    toolkit_backup_load_components >/dev/null 2>&1 || exit 1
    for key in "${BACKUP_COMPONENTS[@]}"; do
      declare -F "produce_${key//-/_}" >/dev/null && [[ "${BACKUP_CADENCE[$key]:-}" =~ ^(4h|daily)$ ]] || exit 1
    done
  ); then
    toolkit_doctor_line ok "$repo" "component list ${TOOLKIT_REPO[BACKUP_COMPONENTS]} loads"
  else
    toolkit_doctor_line fail "$repo" "component list ${TOOLKIT_REPO[BACKUP_COMPONENTS]} does not load or a component lacks a producer/cadence"
  fi
  toolkit_doctor_backup_instance "$repo" 4h
  toolkit_doctor_backup_instance "$repo" daily
}

toolkit_doctor_repository() {
  local repo control user home target job
  repo="$(toolkit_repo_name)"
  control="$(toolkit_repo_control_dir)"
  if [[ "$TOOLKIT_REPO_ROOT" != "$control" ]]; then
    if [[ ! -f "$control/deployment/toolkit.lock" ]]; then
      toolkit_doctor_line fail "$repo" "not installed on this host; run: sudo deployment/toolkit install --deploy-user <user>"
      return
    elif ! cmp -s "$control/deployment/toolkit.lock" "$TOOLKIT_REPO_ROOT/deployment/toolkit.lock"; then
      toolkit_doctor_line warn "$repo" "installed copy pins $(sed -n 's/^TOOLKIT_VERSION=//p' "$control/deployment/toolkit.lock"), this checkout pins $TOOLKIT_VERSION; reinstall to update units and scripts"
    else
      toolkit_doctor_line ok "$repo" "installed copy matches this checkout (toolkit $TOOLKIT_VERSION)"
    fi
  fi
  user="$(sed -n 's/^DEPLOY_USER=//p' "$control/host.env" 2>/dev/null)"
  if [[ -n "$user" ]] && home="$(getent passwd "$user" | cut -d: -f6)" && [[ -n "$home" ]]; then
    for target in "${TOOLKIT_REPO_TARGETS[@]}"; do
      if [[ -L "$home/${target#*:}/current" ]]; then
        toolkit_doctor_line ok "$repo" "${target##*/} current=$(basename -- "$(readlink "$home/${target#*:}/current")")"
      else
        toolkit_doctor_line warn "$repo" "${target##*/} has no current release at $home/${target#*:}"
      fi
    done
  else
    toolkit_doctor_line warn "$repo" "no deploy user recorded in $control/host.env"
  fi
  ((${#TOOLKIT_REPO_TARGETS[@]} == 0)) || toolkit_doctor_unit "$repo" "toolkit-$repo-reconcile.service"
  if [[ -n "${TOOLKIT_REPO[BACKUP_COMPONENTS]:-}" ]]; then
    toolkit_doctor_unit "$repo" "toolkit-$repo-backup@.service"
    toolkit_doctor_unit "$repo" "toolkit-$repo-backup@4h.timer"
    toolkit_doctor_unit "$repo" "toolkit-$repo-backup@daily.timer"
    toolkit_doctor_backups "$repo"
  fi
  for job in "${TOOLKIT_REPO_JOBS[@]}"; do
    toolkit_doctor_unit "$repo" "toolkit-$repo-$job.service"
    toolkit_doctor_unit "$repo" "toolkit-$repo-$job.timer"
  done
  if [[ -n "${TOOLKIT_REPO[MAINTENANCE_AT]:-}" ]]; then
    toolkit_doctor_unit host toolkit-maintenance.service
    toolkit_doctor_unit host toolkit-maintenance.timer
  fi
}

toolkit_doctor_host() {
  local use control repo lock path legacy failed
  if (toolkit_assert_supported_platform) >/dev/null 2>&1; then
    toolkit_doctor_line ok host 'Ubuntu 26.04 amd64'
  else
    toolkit_doctor_line fail host 'unsupported platform (toolkit needs Ubuntu 26.04 amd64)'
  fi
  if docker info >/dev/null 2>&1; then
    toolkit_doctor_line ok host "docker $(docker version --format '{{.Server.Version}}' 2>/dev/null)"
  else
    toolkit_doctor_line fail host 'docker is not reachable'
  fi
  use="$(df -P / | awk 'NR == 2 { gsub("%", "", $5); print $5 }')"
  if ((use >= 95)); then
    toolkit_doctor_line fail host "root filesystem ${use}% full"
  elif ((use >= 85)); then
    toolkit_doctor_line warn host "root filesystem ${use}% full"
  else
    toolkit_doctor_line ok host "root filesystem ${use}% used"
  fi
  [[ ! -f /var/run/reboot-required ]] || toolkit_doctor_line warn host 'reboot required after package updates'
  if [[ -x "$TOOLKIT_RUNNER_PATH" ]]; then
    cmp -s "$TOOLKIT_RUNNER_PATH" "$TOOLKIT_ROOT/packaging/run-bundle.py" &&
      toolkit_doctor_line ok host 'bundle runner matches this release' ||
      toolkit_doctor_line ok host 'bundle runner installed (from another release; format 1 is shared)'
  else
    toolkit_doctor_line warn host 'no bundle runner; deploy users cannot run toolkit commands (install any repository)'
  fi
  for legacy in /usr/local/bin/toolkit /opt/toolkit/current /opt/toolkit/releases; do
    [[ ! -e "$legacy" && ! -L "$legacy" ]] ||
      toolkit_doctor_line warn host "legacy host CLI path $legacy; once no unit uses it: sudo rm -rf /usr/local/bin/toolkit /opt/toolkit/current /opt/toolkit/previous /opt/toolkit/releases"
  done
  for legacy in /etc/sudoers.d/toolkit-ci-*; do
    [[ ! -e "$legacy" ]] ||
      toolkit_doctor_line warn host "legacy sudo rule $legacy; the runner rule is /etc/sudoers.d/toolkit-runner-<user>: sudo rm $legacy"
  done
  if command -v systemctl >/dev/null 2>&1; then
    failed="$(systemctl list-units --failed --no-legend --plain 2>/dev/null | awk '{print $1}' | tr '\n' ' ')"
    [[ -z "${failed// /}" ]] && toolkit_doctor_line ok host 'no failed systemd units' || toolkit_doctor_line fail host "failed units: $failed"
    for legacy in $(systemctl list-unit-files --no-legend --plain 'toolkit-backup@*' '*-reconcile.service' '*-umami-retention.*' 'infra-wp-cron.*' 2>/dev/null | awk '$1 !~ /^toolkit-.*-reconcile/ {print $1}'); do
      toolkit_doctor_line warn host "pre-0.11 unit $legacy; disable and remove it once the repository is reinstalled"
    done
  fi
  for lock in /run/lock/toolkit/host.lock /run/lock/toolkit/repos/*/repository.lock; do
    [[ -f "$lock" ]] || continue
    if flock -n "$lock" true 2>/dev/null; then
      toolkit_doctor_line ok host "${lock#/run/lock/toolkit/} free"
    else
      toolkit_doctor_line warn host "${lock#/run/lock/toolkit/} held (an operation is running)"
    fi
  done
  # One pass over the last week's records; scheduled jobs write many.
  while IFS= read -r path; do
    toolkit_doctor_line warn host "recent failed operation ${path#/var/lib/toolkit/operations/}"
  done < <(find /var/lib/toolkit/operations -name '*.json' -mtime -7 -print0 2>/dev/null |
    xargs -0 -r grep -l '"state": *"\(failed\|interrupted\)"' 2>/dev/null | sort)
  for control in "$TOOLKIT_REPO_CONTROL_ROOT"/*/deployment/toolkit.lock; do
    [[ -f "$control" ]] || continue
    repo="${control#"$TOOLKIT_REPO_CONTROL_ROOT"/}"
    toolkit_doctor_line ok host "repository ${repo%%/*} installed with toolkit $(sed -n 's/^TOOLKIT_VERSION=//p' "$control")"
  done
}

toolkit_doctor() {
  (($# == 0)) || toolkit_die 'usage: deployment/toolkit doctor'
  ((EUID == 0)) || printf 'note: run with sudo for complete results\n'
  toolkit_doctor_host
  if toolkit_repo_active; then
    toolkit_repo_load
    toolkit_doctor_repository
  fi
  return "$TOOLKIT_DOCTOR_FAILURES"
}
