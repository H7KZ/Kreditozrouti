#!/usr/bin/env bash
# Repository context: deployment/toolkit.conf of the checkout or installed control copy that
# invoked the toolkit through its deployment/toolkit entrypoint (global --repo-root).

declare -g TOOLKIT_REPO_ROOT="${TOOLKIT_REPO_ROOT:-}"
declare -gA TOOLKIT_REPO=()
declare -ga TOOLKIT_REPO_TARGETS=() TOOLKIT_REPO_JOBS=()
TOOLKIT_REPO_CONTROL_ROOT=/opt/toolkit
TOOLKIT_REPO_CONFIG_DIR="${TOOLKIT_CONFIG_DIR:-/etc/toolkit}"

toolkit_repo_known_key() {
  case "$1" in
  REPOSITORY | RELEASE_TARGETS | RECONCILE_BEFORE | BACKUP_COMPONENTS | BACKUP_4H_AT | BACKUP_DAILY_AT | MAINTENANCE_AT | JOBS) return 0 ;;
  JOB_*_RUN | JOB_*_AT | JOB_*_ENVIRONMENT | JOB_*_HOST_WINDOW | JOB_*_TIMEOUT) return 0 ;;
  *) return 1 ;;
  esac
}

# A path inside the repository: relative, normalized, no traversal.
toolkit_repo_validate_path() {
  [[ "$1" =~ ^[A-Za-z0-9._-]+(/[A-Za-z0-9._-]+)*$ && "/$1/" != *'/../'* && "/$1/" != *'/./'* ]]
}

# systemd OnCalendar expressions; systemd-analyze validates them during install.
toolkit_repo_validate_calendar() {
  [[ "$1" =~ ^[A-Za-z0-9\ *:/,.~+-]+$ ]]
}

# Operation records accept only these environments (contracts/handoff-v1.md).
toolkit_repo_valid_environment() {
  [[ "$1" =~ ^(development|production|infrastructure|monitoring|analytics)$ ]]
}

toolkit_repo_job_key() {
  local name="${1^^}"
  printf 'JOB_%s_%s' "${name//-/_}" "$2"
}

toolkit_repo_active() {
  [[ -n "$TOOLKIT_REPO_ROOT" ]]
}

toolkit_repo_load() {
  local path line line_number=0 key value target environment job
  toolkit_repo_active || toolkit_die 'this command needs repository context: run it through deployment/toolkit'
  [[ "$TOOLKIT_REPO_ROOT" == /* && -d "$TOOLKIT_REPO_ROOT" ]] || toolkit_die "repository root is not a directory: $TOOLKIT_REPO_ROOT"
  path="$TOOLKIT_REPO_ROOT/deployment/toolkit.conf"
  [[ -f "$path" && ! -L "$path" ]] || toolkit_die "missing $path; every consuming repository declares its integration there"
  toolkit_file_check_utf8 "$path"
  TOOLKIT_REPO=()
  while IFS= read -r line || [[ -n "$line" ]]; do
    ((line_number += 1))
    line="${line%$'\r'}"
    [[ "$line" =~ ^[[:space:]]*(#|$) ]] && continue
    [[ "$line" == *=* ]] || toolkit_die "toolkit.conf line $line_number must be KEY=value"
    key="${line%%=*}"
    value="$(toolkit_trim_value "${line#*=}")"
    [[ "$key" =~ ^[A-Z][A-Z0-9_]*$ ]] && toolkit_repo_known_key "$key" || toolkit_die "toolkit.conf line $line_number has unknown key $key"
    [[ -z "${TOOLKIT_REPO[$key]+present}" ]] || toolkit_die "toolkit.conf line $line_number duplicates $key"
    TOOLKIT_REPO["$key"]="$value"
  done <"$path"

  toolkit_validate_slug "${TOOLKIT_REPO[REPOSITORY]:-}" || toolkit_die 'toolkit.conf REPOSITORY must be a lowercase slug'
  read -r -a TOOLKIT_REPO_TARGETS <<<"${TOOLKIT_REPO[RELEASE_TARGETS]:-}"
  for target in "${TOOLKIT_REPO_TARGETS[@]}"; do
    environment="${target%%:*}"
    [[ "$target" == *:* ]] && toolkit_repo_valid_environment "$environment" && toolkit_repo_validate_path "${target#*:}" ||
      toolkit_die "RELEASE_TARGETS entry must be <environment>:<path below the deploy home> with environment development, production, infrastructure, monitoring or analytics: $target"
  done
  for key in RECONCILE_BEFORE BACKUP_COMPONENTS; do
    [[ -z "${TOOLKIT_REPO[$key]:-}" ]] || toolkit_repo_validate_path "${TOOLKIT_REPO[$key]}" || toolkit_die "$key must be a repository-relative path"
  done
  if [[ -n "${TOOLKIT_REPO[BACKUP_COMPONENTS]:-}" ]]; then
    for key in BACKUP_4H_AT BACKUP_DAILY_AT; do
      toolkit_repo_validate_calendar "${TOOLKIT_REPO[$key]:-}" || toolkit_die "BACKUP_COMPONENTS needs a $key schedule (systemd OnCalendar)"
    done
  fi
  [[ -z "${TOOLKIT_REPO[MAINTENANCE_AT]:-}" ]] || toolkit_repo_validate_calendar "${TOOLKIT_REPO[MAINTENANCE_AT]}" || toolkit_die 'MAINTENANCE_AT must be a systemd OnCalendar expression'
  read -r -a TOOLKIT_REPO_JOBS <<<"${TOOLKIT_REPO[JOBS]:-}"
  for job in "${TOOLKIT_REPO_JOBS[@]}"; do
    toolkit_validate_slug "$job" || toolkit_die "job names must be lowercase slugs: $job"
    toolkit_repo_validate_path "$(toolkit_repo_job "$job" RUN)" || toolkit_die "$(toolkit_repo_job_key "$job" RUN) must be a repository-relative script"
    toolkit_repo_validate_calendar "$(toolkit_repo_job "$job" AT)" || toolkit_die "$(toolkit_repo_job_key "$job" AT) must be a systemd OnCalendar expression"
    toolkit_repo_valid_environment "$(toolkit_repo_job "$job" ENVIRONMENT)" ||
      toolkit_die "$(toolkit_repo_job_key "$job" ENVIRONMENT) must be development, production, infrastructure, monitoring or analytics"
    [[ "$(toolkit_repo_job "$job" HOST_WINDOW)" =~ ^(true|false)$ ]] || toolkit_die "$(toolkit_repo_job_key "$job" HOST_WINDOW) must be true or false"
    toolkit_validate_uint "$(toolkit_repo_job "$job" TIMEOUT)" 1 3600 || toolkit_die "$(toolkit_repo_job_key "$job" TIMEOUT) must be 1-3600 seconds"
  done
  for key in "${!TOOLKIT_REPO[@]}"; do
    [[ "$key" != JOB_* ]] || [[ " ${TOOLKIT_REPO_JOBS[*]} " == *" $(toolkit_repo_key_job "$key") "* ]] || toolkit_die "$key belongs to a job missing from JOBS"
  done
}

# Job setting with defaults: ENVIRONMENT=production, HOST_WINDOW=false, TIMEOUT=1800.
toolkit_repo_job() {
  local key default=''
  key="$(toolkit_repo_job_key "$1" "$2")"
  case "$2" in
  ENVIRONMENT) default=production ;;
  HOST_WINDOW) default=false ;;
  TIMEOUT) default=1800 ;;
  esac
  printf '%s' "${TOOLKIT_REPO[$key]:-$default}"
}

toolkit_repo_key_job() {
  local name="${1#JOB_}"
  name="${name%_*}"
  [[ "$1" != *_HOST_WINDOW ]] || name="${name%_HOST}"
  name="${name,,}"
  printf '%s' "${name//_/-}"
}

toolkit_repo_name() {
  printf '%s' "${TOOLKIT_REPO[REPOSITORY]}"
}

toolkit_repo_control_dir() {
  printf '%s/%s' "$TOOLKIT_REPO_CONTROL_ROOT" "$(toolkit_repo_name)"
}

# The deploy account: explicit --user, then the sudo caller, then the installed host.env.
toolkit_repo_deploy_user() {
  local explicit="${1:-}" file line
  if [[ -n "$explicit" ]]; then
    printf '%s' "$explicit"
    return
  fi
  if [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != root ]]; then
    printf '%s' "$SUDO_USER"
    return
  fi
  file="$TOOLKIT_REPO_ROOT/host.env"
  if [[ -f "$file" && ! -L "$file" ]]; then
    while IFS= read -r line; do
      [[ "$line" == DEPLOY_USER=* ]] && {
        printf '%s' "${line#DEPLOY_USER=}"
        return
      }
    done <"$file"
  fi
  toolkit_die 'cannot tell the deploy user: pass --user, run through sudo, or install the repository (deployment/toolkit install)'
}

toolkit_repo_user_home() {
  local entry
  entry="$(getent passwd "$1")" || toolkit_die "deploy user does not exist: $1"
  [[ "$(cut -d: -f3 <<<"$entry")" != 0 ]] || toolkit_die 'the deploy user must not be root'
  cut -d: -f6 <<<"$entry"
}

# Prints "<environment> <absolute root> <target name>" for a release target name or environment.
toolkit_repo_target() {
  local wanted="$1" home="$2" target path name
  for target in "${TOOLKIT_REPO_TARGETS[@]}"; do
    path="${target#*:}"
    name="${path##*/}"
    if [[ "$wanted" == "$name" ]]; then
      printf '%s %s %s\n' "${target%%:*}" "$home/$path" "$name"
      return 0
    fi
  done
  return 1
}

# Operator configuration and secrets for a repository: /etc/toolkit/<repo>.env.
toolkit_repo_env_file() {
  printf '%s/%s.env' "$TOOLKIT_REPO_CONFIG_DIR" "$1"
}
