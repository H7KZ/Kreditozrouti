# VPS toolkit

Host CLI for deploys, rollbacks, boot reconcile, backups and locks on the shared Ubuntu 26.04 VPS.
Every consuming repository pins a packaged release of this directory.

Guides live outside the package so they can change without a release:
**[docs/toolkit](../docs/toolkit/README.md)** — overview, [releasing](../docs/toolkit/releasing.md),
[consumers](../docs/toolkit/consumers.md), [host](../docs/toolkit/host.md),
[commands](../docs/toolkit/commands.md), [changelog](../docs/toolkit/CHANGELOG.md).

| Path | Contents |
| --- | --- |
| `VERSION` | Release version. Bump it with every change in this directory |
| `bin/toolkit` | Entry point and command dispatch |
| `commands/`, `lib/` | Command implementations and shared helpers |
| `consumer/` | Managed scripts copied into every consuming repository's `deployment/` |
| `packaging/` | Release builder, hook, vendoring, host installer, CI bundle runner |
| `contracts/` | Frozen cross-repository protocols and JSON schemas |
| `config/` | Example host configuration |
| `tests/` | CI test suite |
