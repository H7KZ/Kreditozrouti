#!/usr/bin/env python3
"""Exercise distribution through Git snapshots and the bundle-runner CLI."""
import hashlib
import io
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]


class PackagingTests(unittest.TestCase):
    def setUp(self):
        self.work = tempfile.TemporaryDirectory()
        self.addCleanup(self.work.cleanup)
        self.root = Path(self.work.name)
        (self.root / "toolkit/packaging").mkdir(parents=True)
        shutil.copy(ROOT / "toolkit/packaging/build-release.py", self.root / "toolkit/packaging")
        (self.root / "toolkit/VERSION").write_text("0.9.0\n")
        (self.root / "toolkit/bin").mkdir()
        (self.root / "toolkit/bin/toolkit").write_text("#!/bin/bash\nprintf 'bundled version=0.9.0 args=%s\\n' \"$*\"\n")
        self.git("init", "-q")
        self.git("add", ".")

    def git(self, *args):
        return subprocess.run(["git", "-C", str(self.root), *args], check=True, capture_output=True)

    def build(self, output="dist", check=True):
        return subprocess.run([sys.executable, str(self.root / "toolkit/packaging/build-release.py"),
                               str(self.root / output), "--ref", "index"], capture_output=True, check=check)

    def test_staged_snapshot_excludes_unstaged_and_untracked_content(self):
        self.git("config", "user.name", "Test")
        self.git("config", "user.email", "test@localhost")
        (self.root / "toolkit/data.txt").write_text("staged\n")
        self.git("add", "toolkit/data.txt")
        (self.root / "toolkit/data.txt").write_text("unstaged-secret\n")
        (self.root / "toolkit/.env").write_text("untracked-secret\n")
        self.build()
        self.build("second")
        archive = self.root / "dist/toolkit-0.9.0.tar.gz"
        self.assertEqual(archive.read_bytes(), (self.root / "second" / archive.name).read_bytes())
        with tarfile.open(archive) as stream:
            self.assertEqual(stream.extractfile("toolkit/data.txt").read(), b"staged\n")
            self.assertNotIn("toolkit/.env", stream.getnames())
        self.git("commit", "-qm", "Snapshot")
        committed = subprocess.run([sys.executable, str(self.root / "toolkit/packaging/build-release.py"),
                                    str(self.root / "committed")], capture_output=True)
        self.assertEqual(committed.returncode, 0, committed.stderr)
        self.assertEqual(archive.read_bytes(), (self.root / "committed" / archive.name).read_bytes())

    def test_version_cannot_be_reused_for_changed_source(self):
        self.build()
        (self.root / "toolkit/new.txt").write_text("changed\n")
        self.git("add", "toolkit/new.txt")
        result = self.build(check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn(b"bump toolkit/VERSION", result.stderr)

    @unittest.skipUnless(shutil.which("sh"), "hook requires sh")
    def test_hook_uses_staged_packaging_code_and_stages_only_generated_files(self):
        hook = self.root / ".husky/pre-commit"
        hook.parent.mkdir()
        shutil.copy(ROOT / ".husky/pre-commit", hook)
        helper = self.root / "toolkit/packaging/pre-commit.py"
        shutil.copy(ROOT / "toolkit/packaging/pre-commit.py", helper)
        shutil.copy(ROOT / "toolkit/packaging/vendor.py", self.root / "toolkit/packaging/vendor.py")
        shutil.copytree(ROOT / "toolkit/consumer", self.root / "toolkit/consumer")
        self.git("add", ".")
        # Neither unstaged generator templates nor the unstaged helper may enter the commit.
        builder = self.root / "toolkit/packaging/build-release.py"
        builder.write_text(builder.read_text().replace("Requires Ubuntu 26.04 amd64", "unstaged-readme-secret"))
        helper.write_text("raise SystemExit('unstaged-helper')\n")
        output = self.root / "deployment/vendor/toolkit"
        output.mkdir(parents=True)
        (output / ".env").write_text("untracked-secret\n")
        result = subprocess.run(["sh", str(hook)], cwd=self.root, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        readme = self.git("show", ":deployment/vendor/toolkit/README.md").stdout
        self.assertIn(b"Requires Ubuntu 26.04 amd64", readme)
        self.assertNotIn(b"unstaged-readme-secret", readme)
        staged = self.git("ls-files", "-s").stdout.decode()
        self.assertNotIn("deployment/vendor/toolkit/.env", staged)
        # Infrastructure consumes its own release: pin and managed scripts are staged, executable.
        for path in ("deployment/verify-toolkit-pin.sh", "deployment/install-toolkit.sh",
                     "deployment/vendor/toolkit/validate-lock.sh"):
            self.assertRegex(staged, rf"100755 \w+ 0\t{path}\n")
        self.assertEqual(self.git("show", ":deployment/toolkit.lock").stdout,
                         self.git("show", ":deployment/vendor/toolkit/toolkit.lock").stdout)

    @unittest.skipUnless(hasattr(os, "geteuid") and os.geteuid() == 0, "runner CLI requires root")
    def test_runner_executes_shipped_code_and_preserves_arguments_without_host_cli(self):
        self.build()
        result = self.runner("release", "rollback", "--release-id", "previous")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn(b"bundled version=0.9.0 args=release rollback --release-id previous", result.stdout)

    def runner(self, *command):
        return subprocess.run([sys.executable, str(ROOT / "toolkit/packaging/run-bundle.py"),
                               "--archive", str(self.root / "dist/toolkit-0.9.0.tar.gz"),
                               "--checksum", str(self.root / "dist/toolkit-0.9.0.tar.gz.sha256"),
                               "--lock", str(self.root / "dist/toolkit.lock"), "--", *command], capture_output=True)

    @unittest.skipUnless(hasattr(os, "geteuid") and os.geteuid() == 0, "runner CLI requires root")
    def test_runner_rejects_tampered_payload_before_execution(self):
        self.build()
        archive = self.root / "dist/toolkit-0.9.0.tar.gz"
        archive.write_bytes(archive.read_bytes() + b"tampered")
        result = self.runner("version")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn(b"checksum/pin mismatch", result.stderr)
        self.assertEqual(result.stdout, b"")

    @unittest.skipUnless(hasattr(os, "geteuid") and os.geteuid() == 0, "runner CLI requires root")
    def test_runner_rejects_traversal_even_with_matching_checksums(self):
        self.build()
        archive = self.root / "dist/toolkit-0.9.0.tar.gz"
        with tarfile.open(archive, "w:gz") as stream:
            member = tarfile.TarInfo("toolkit/../../escape")
            member.size = 1
            stream.addfile(member, io.BytesIO(b"x"))
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        (archive.parent / (archive.name + ".sha256")).write_text(f"{digest}  {archive.name}\n")
        lock = archive.parent / "toolkit.lock"
        lock.write_text("\n".join(f"TOOLKIT_ARCHIVE_SHA256={digest}" if line.startswith("TOOLKIT_ARCHIVE_SHA256=")
                                  else line for line in lock.read_text().splitlines()) + "\n")
        result = self.runner("version")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn(b"unsafe/duplicate", result.stderr)
        self.assertEqual(result.stdout, b"")


if __name__ == "__main__":
    unittest.main()
