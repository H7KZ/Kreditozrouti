#!/usr/bin/env python3
"""Exercise consumer vendoring and the managed pin verification it installs."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
MANAGED = ("toolkit.lock", "verify-toolkit-pin.sh", "install-toolkit.sh", "vendor/toolkit/toolkit.lock",
           "vendor/toolkit/README.md", "vendor/toolkit/validate-lock.sh", "vendor/toolkit/toolkit-0.10.0.tar.gz",
           "vendor/toolkit/toolkit-0.10.0.tar.gz.sha256")


class VendorTests(unittest.TestCase):
    def setUp(self):
        work = tempfile.TemporaryDirectory()
        self.addCleanup(work.cleanup)
        self.infrastructure = Path(work.name) / "infrastructure"
        self.consumer = Path(work.name) / "consumer"
        source = self.infrastructure / "toolkit"
        shutil.copytree(ROOT / "toolkit/consumer", source / "consumer")
        (source / "packaging").mkdir()
        for script in ("build-release.py", "vendor.py"):
            shutil.copy(ROOT / "toolkit/packaging" / script, source / "packaging")
        (source / "bin").mkdir()
        (source / "bin/toolkit").write_text("#!/bin/bash\n", newline="\n")
        (source / "VERSION").write_text("0.10.0\n", newline="\n")
        self.git("init", "-q")
        self.git("add", ".")
        self.run_script("build-release.py", str(self.infrastructure / "deployment/vendor/toolkit"), "--ref", "index")
        stale = self.consumer / "deployment/vendor/toolkit"
        stale.mkdir(parents=True)
        for name in ("toolkit-0.9.3.tar.gz", "toolkit-0.9.3.tar.gz.sha256"):
            (stale / name).write_text("old\n")
        (self.consumer / "deployment/verify-toolkit-pin.sh").write_text("# hand edited\n")
        (self.consumer / "deployment/deploy.sh").write_text("# consumer owned\n")

    def git(self, *args):
        subprocess.run(["git", "-C", str(self.infrastructure), *args], check=True, capture_output=True)

    def run_script(self, script, *args, check=True):
        return subprocess.run([sys.executable, str(self.infrastructure / "toolkit/packaging" / script), *args],
                              capture_output=True, text=True, check=check)

    def vendor(self, *args, check=True):
        return self.run_script("vendor.py", *args, check=check)

    def test_vendor_writes_managed_files_and_prunes_other_versions(self):
        result = self.vendor(str(self.consumer))
        self.assertIn("toolkit none -> 0.10.0", result.stdout)
        deployment = self.consumer / "deployment"
        published = self.infrastructure / "deployment/vendor/toolkit"
        for path in MANAGED:
            self.assertTrue((deployment / path).is_file(), path)
        self.assertEqual((deployment / "toolkit.lock").read_bytes(), (published / "toolkit.lock").read_bytes())
        self.assertEqual((deployment / "verify-toolkit-pin.sh").read_bytes(),
                         (ROOT / "toolkit/consumer/verify-toolkit-pin.sh").read_bytes())
        self.assertFalse((deployment / "vendor/toolkit/toolkit-0.9.3.tar.gz").exists())
        self.assertEqual((deployment / "deploy.sh").read_text(), "# consumer owned\n")
        self.assertIn("up to date", self.vendor("--check", str(self.consumer)).stdout)

    def test_check_reports_drift_without_changing_files(self):
        self.vendor(str(self.consumer))
        edited = self.consumer / "deployment/install-toolkit.sh"
        edited.write_text("# hand edited\n")
        result = self.vendor("--check", str(self.consumer), check=False)
        self.assertEqual(result.returncode, 1)
        self.assertIn("differs  deployment/install-toolkit.sh", result.stdout)
        (self.consumer / "deployment/toolkit.lock").unlink()
        self.assertIn("missing  deployment/toolkit.lock", self.vendor("--check", str(self.consumer), check=False).stdout)
        self.assertEqual(edited.read_text(), "# hand edited\n")

    def test_infrastructure_keeps_every_published_version(self):
        shelf = self.infrastructure / "deployment/vendor/toolkit/toolkit-0.9.3.tar.gz"
        shelf.write_text("published earlier\n")
        self.vendor(str(self.infrastructure))
        self.assertTrue(shelf.exists())
        self.assertTrue((self.infrastructure / "deployment/verify-toolkit-pin.sh").is_file())

    def test_unpackaged_version_bump_is_rejected(self):
        (self.infrastructure / "toolkit/VERSION").write_text("0.10.1\n", newline="\n")
        self.git("add", "toolkit/VERSION")
        result = self.vendor(str(self.consumer), check=False)
        self.assertEqual(result.returncode, 1)
        self.assertIn("toolkit/VERSION is 0.10.1 but the packaged release is 0.10.0", result.stderr)
        self.assertFalse((self.consumer / "deployment/toolkit.lock").exists())

    @unittest.skipIf(os.name == "nt" or not shutil.which("sha256sum"), "needs GNU userland")
    def test_pin_verification_rejects_edited_managed_copies(self):
        self.vendor(str(self.consumer))
        deployment = self.consumer / "deployment"

        def verify():
            return subprocess.run(["bash", str(deployment / "verify-toolkit-pin.sh")], capture_output=True, text=True)

        self.assertEqual(verify().returncode, 0, verify().stderr)
        # Installed control directories may carry only part of the managed set.
        (deployment / "install-toolkit.sh").unlink()
        self.assertEqual(verify().returncode, 0)
        (deployment / "install-toolkit.sh").write_text("# hand edited\n")
        self.assertIn("install-toolkit.sh differs from toolkit 0.10.0", verify().stderr)
        self.vendor(str(self.consumer))
        lock = deployment / "vendor/toolkit/toolkit.lock"
        lock.write_text(lock.read_text() + "EXTRA=1\n")
        self.assertIn("vendor/toolkit/toolkit.lock differs", verify().stderr)


if __name__ == "__main__":
    unittest.main()
