#!/usr/bin/env python3
"""Build only staged toolkit source and stage its distribution, on every commit."""
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"]).decode().strip())
with tempfile.TemporaryDirectory() as directory:
    staged = Path(directory) / "toolkit/packaging"
    staged.mkdir(parents=True)
    for script in ("build-release.py", "vendor.py"):
        (staged / script).write_bytes(subprocess.check_output(["git", "show", f":toolkit/packaging/{script}"], cwd=root))
    subprocess.run([sys.executable, str(staged / "build-release.py"), str(root / "deployment/vendor/toolkit"),
                    "--repository", str(root), "--ref", "index"], cwd=root, check=True)
    # Infrastructure consumes its own release exactly like Ohlidame, Kreditozrouti and PortfolioV7.
    subprocess.run([sys.executable, str(staged / "vendor.py"), "--infrastructure", str(root), str(root)],
                   cwd=root, check=True, stdout=subprocess.DEVNULL)
lock = (root / "deployment/toolkit.lock").read_text(encoding="utf-8")
version = next(line.split("=", 1)[1] for line in lock.splitlines() if line.startswith("TOOLKIT_VERSION="))
subprocess.run(["git", "add", "--", "deployment/toolkit.lock", "deployment/vendor/toolkit/toolkit.lock",
                "deployment/vendor/toolkit/README.md", f"deployment/vendor/toolkit/toolkit-{version}.tar.gz",
                f"deployment/vendor/toolkit/toolkit-{version}.tar.gz.sha256"], cwd=root, check=True)
subprocess.run(["git", "add", "--chmod=+x", "--", "deployment/install-toolkit.sh", "deployment/verify-toolkit-pin.sh",
                "deployment/vendor/toolkit/validate-lock.sh"], cwd=root, check=True)
