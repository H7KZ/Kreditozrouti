#!/usr/bin/env bash

TOOLKIT_ACTIVE_OPERATION_ID=''
TOOLKIT_ACTIVE_OPERATION_REPOSITORY=''
TOOLKIT_ACTIVE_OPERATION_ENVIRONMENT=''
TOOLKIT_ACTIVE_OPERATION_STATE=''
TOOLKIT_ACTIVE_OPERATION_FAILURE_PHASE='preflight'

toolkit_validate_operation_id() {
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$ && "$1" != . && "$1" != .. ]]
}

toolkit_validate_operation_value() {
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$ ]]
}

toolkit_operation_path() {
  local repository="$1" environment="$2" operation_id="$3"
  toolkit_validate_slug "$repository" || toolkit_die 'operation repository must be a lowercase slug'
  [[ "$environment" =~ ^(development|production|infrastructure)$ ]] || toolkit_die 'operation environment is invalid'
  toolkit_validate_operation_id "$operation_id" || toolkit_die 'operation id is invalid'
  printf '/var/lib/toolkit/operations/%s/%s/%s.json\n' "$repository" "$environment" "$operation_id"
}

toolkit_write_operation_record() {
  local repository="$1" environment="$2" operation_id="$3" action="$4" state="$5"
  local started_at="$6" finished_at="$7" release_id="$8" failure_phase="$9" path parent
  toolkit_require_root
  toolkit_validate_slug "$repository" || toolkit_die 'operation repository must be a lowercase slug'
  [[ "$environment" =~ ^(development|production|infrastructure)$ ]] || toolkit_die 'operation environment is invalid'
  toolkit_validate_operation_id "$operation_id" || toolkit_die 'operation id is invalid'
  [[ "$action" =~ ^(deploy|rollback|backup_capture|backup_restore|proxy|toolkit|cleanup|maintenance)$ ]] || toolkit_die 'operation action is invalid'
  [[ "$state" =~ ^(running|succeeded|failed|interrupted)$ ]] || toolkit_die 'operation state is invalid'
  [[ -z "$release_id" ]] || toolkit_validate_operation_value "$release_id" || toolkit_die 'operation release id is invalid'
  [[ -z "$failure_phase" ]] || toolkit_validate_operation_value "$failure_phase" || toolkit_die 'operation failure phase is invalid'
  [[ "$state" == running && "$finished_at" == null || "$state" != running && "$finished_at" != null ]] || toolkit_die 'operation timestamps do not match state'
  toolkit_validate_operation_value "$started_at" || toolkit_die 'operation start timestamp is invalid'
  [[ "$finished_at" == null ]] || toolkit_validate_operation_value "$finished_at" || toolkit_die 'operation finish timestamp is invalid'

  path="$(toolkit_operation_path "$repository" "$environment" "$operation_id")"
  parent="$(dirname -- "$path")"
  [[ ! -L /var && ! -L /var/lib && ! -L /var/lib/toolkit && ! -L /var/lib/toolkit/operations && ! -L "/var/lib/toolkit/operations/$repository" && ! -L "/var/lib/toolkit/operations/$repository/$environment" ]] || toolkit_die 'operation status directory must not contain symlinks'
  install -d -o root -g root -m 0700 "$parent" || toolkit_die 'cannot prepare operation status directory'
  [[ "$(stat -c '%u' "$parent")" == 0 && "$(stat -c '%a' "$parent")" == 700 ]] || toolkit_die 'operation status directory is not root-only'
  if [[ "$state" == running ]]; then
    [[ ! -e "$path" && ! -L "$path" ]] || toolkit_die 'operation id already has a status record'
  fi

  toolkit_atomic_write_file "$path" 0600 <<RECORD
{
  "schema_version": 1,
  "operation_id": "$operation_id",
  "repository": "$repository",
  "environment": "$environment",
  "action": "$action",
  "state": "$state",
  "started_at": "$started_at",
  "finished_at": $([[ "$finished_at" == null ]] && printf null || printf '"%s"' "$finished_at"),
  "toolkit_version": "$TOOLKIT_VERSION",
  "release_id": $([[ -z "$release_id" ]] && printf null || printf '"%s"' "$release_id"),
  "failure_phase": $([[ -z "$failure_phase" ]] && printf null || printf '"%s"' "$failure_phase")
}
RECORD
}

toolkit_operation_start() {
  local repository='' environment='' action='' operation_id='' release_id='' started_at
  while (($#)); do
    case "$1" in
    --repository)
      (($# >= 2)) || toolkit_die '--repository requires a value'
      repository="$2"
      shift 2
      ;;
    --environment)
      (($# >= 2)) || toolkit_die '--environment requires a value'
      environment="$2"
      shift 2
      ;;
    --action)
      (($# >= 2)) || toolkit_die '--action requires a value'
      action="$2"
      shift 2
      ;;
    --operation-id)
      (($# >= 2)) || toolkit_die '--operation-id requires a value'
      operation_id="$2"
      shift 2
      ;;
    --release-id)
      (($# >= 2)) || toolkit_die '--release-id requires a value'
      release_id="$2"
      shift 2
      ;;
    *) toolkit_die "unknown operation start option: $1" ;;
    esac
  done
  [[ -n "$repository" && -n "$environment" && -n "$action" ]] || toolkit_die 'operation start requires repository, environment and action'
  [[ -n "$operation_id" ]] || operation_id="$(date -u +'%Y%m%dT%H%M%SZ')-$$-$RANDOM"
  started_at="$(date -u +'%Y-%m-%dT%H:%M:%S.%NZ')"
  toolkit_write_operation_record "$repository" "$environment" "$operation_id" "$action" running "$started_at" null "$release_id" ''
  printf 'operation_id=%s\n' "$operation_id"
}

toolkit_operation_finish() {
  local repository='' environment='' operation_id='' state='' failure_phase='' path
  local started_at action release_id finished_at
  while (($#)); do
    case "$1" in
    --repository)
      (($# >= 2)) || toolkit_die '--repository requires a value'
      repository="$2"
      shift 2
      ;;
    --environment)
      (($# >= 2)) || toolkit_die '--environment requires a value'
      environment="$2"
      shift 2
      ;;
    --operation-id)
      (($# >= 2)) || toolkit_die '--operation-id requires a value'
      operation_id="$2"
      shift 2
      ;;
    --state)
      (($# >= 2)) || toolkit_die '--state requires a value'
      state="$2"
      shift 2
      ;;
    --failure-phase)
      (($# >= 2)) || toolkit_die '--failure-phase requires a value'
      failure_phase="$2"
      shift 2
      ;;
    *) toolkit_die "unknown operation finish option: $1" ;;
    esac
  done
  [[ -n "$repository" && -n "$environment" && -n "$operation_id" && "$state" =~ ^(succeeded|failed|interrupted)$ ]] || toolkit_die 'operation finish requires repository, environment, operation id and a terminal state'
  path="$(toolkit_operation_path "$repository" "$environment" "$operation_id")"
  [[ -f "$path" && ! -L "$path" && "$(stat -c '%u' "$path")" == 0 && "$(stat -c '%a' "$path")" == 600 ]] || toolkit_die 'running operation status is missing or unsafe'
  grep -Fxq '  "state": "running",' "$path" || toolkit_die 'operation status is not running'
  grep -Fxq "  \"operation_id\": \"$operation_id\"," "$path" || toolkit_die 'operation status identity mismatch'
  started_at="$(sed -n 's/^  "started_at": "\([^"]*\)",$/\1/p' "$path")"
  action="$(sed -n 's/^  "action": "\([^"]*\)",$/\1/p' "$path")"
  release_id="$(sed -n 's/^  "release_id": \(null\|"[^"]*"\),$/\1/p' "$path")"
  if [[ "$release_id" == null ]]; then
    release_id=''
  else
    release_id="${release_id:1:${#release_id}-2}"
  fi
  [[ -n "$started_at" && -n "$action" ]] || toolkit_die 'operation status record is malformed'
  finished_at="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  toolkit_write_operation_record "$repository" "$environment" "$operation_id" "$action" "$state" "$started_at" "$finished_at" "$release_id" "$failure_phase"
}

toolkit_operation_on_exit() {
  local status="$1" final_state
  local -a finish_args=()
  [[ -n "$TOOLKIT_ACTIVE_OPERATION_ID" && "$TOOLKIT_ACTIVE_OPERATION_STATE" == running ]] || return 0
  final_state=succeeded
  if ((status != 0)); then
    final_state=failed
    ((status < 128)) || final_state=interrupted
  fi
  finish_args+=(
    --repository "$TOOLKIT_ACTIVE_OPERATION_REPOSITORY"
    --environment "$TOOLKIT_ACTIVE_OPERATION_ENVIRONMENT"
    --operation-id "$TOOLKIT_ACTIVE_OPERATION_ID"
    --state "$final_state"
  )
  if [[ "$final_state" != succeeded ]]; then
    finish_args+=(--failure-phase "$TOOLKIT_ACTIVE_OPERATION_FAILURE_PHASE")
  fi
  toolkit_operation_finish "${finish_args[@]}"
}
