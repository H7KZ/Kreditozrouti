#!/usr/bin/env bash
# shellcheck disable=SC2034 # TOOLKIT_ACTIVE_OPERATION_* are read by operations.sh

toolkit_with_locks() {
  local repository='' environment='' action='' operation_id='' release_id='' timeout=300 command_started=0 host_path project_dir project_path host_fd project_fd status
  while (($#)); do
    case "$1" in
    --repository)
      (($# >= 2)) || toolkit_die '--repository requires a value'
      repository="$2"
      shift 2
      ;;
    --environment)
      (($# >= 2)) || toolkit_die '--environment requires a value'
      environment="$2"
      shift 2
      ;;
    --timeout)
      (($# >= 2)) || toolkit_die '--timeout requires a value'
      timeout="$2"
      shift 2
      ;;
    --action)
      (($# >= 2)) || toolkit_die '--action requires a value'
      action="$2"
      shift 2
      ;;
    --operation-id)
      (($# >= 2)) || toolkit_die '--operation-id requires a value'
      operation_id="$2"
      shift 2
      ;;
    --release-id)
      (($# >= 2)) || toolkit_die '--release-id requires a value'
      release_id="$2"
      shift 2
      ;;
    --)
      shift
      command_started=1
      break
      ;;
    *) toolkit_die "unknown with-lock option: $1" ;;
    esac
  done

  ((command_started == 1 && $# > 0)) || toolkit_die 'with-lock requires -- COMMAND [ARG ...]'
  toolkit_require_root
  [[ "$timeout" =~ ^[1-9][0-9]{0,3}$ ]] && ((timeout <= 3600)) || toolkit_die '--timeout must be an integer from 1 through 3600 seconds'
  if [[ -n "$repository" || -n "$environment" ]]; then
    toolkit_validate_slug "$repository" || toolkit_die '--repository must be a lowercase slug'
    toolkit_validate_slug "$environment" || toolkit_die '--environment must be a lowercase slug'
  fi
  if [[ -n "$action" ]]; then
    [[ -n "$repository" && -n "$environment" ]] || toolkit_die '--action requires repository and environment locks'
    local start_output
    local -a start_args=(--repository "$repository" --environment "$environment" --action "$action")
    [[ -z "$operation_id" ]] || start_args+=(--operation-id "$operation_id")
    [[ -z "$release_id" ]] || start_args+=(--release-id "$release_id")
    start_output="$(toolkit_operation_start "${start_args[@]}")"
    TOOLKIT_ACTIVE_OPERATION_ID="${start_output#operation_id=}"
    TOOLKIT_ACTIVE_OPERATION_REPOSITORY="$repository"
    TOOLKIT_ACTIVE_OPERATION_ENVIRONMENT="$environment"
    TOOLKIT_ACTIVE_OPERATION_STATE=running
    TOOLKIT_ACTIVE_OPERATION_FAILURE_PHASE=preflight
    toolkit_log info "operation_started operation_id=$TOOLKIT_ACTIVE_OPERATION_ID action=$action repository=$repository environment=$environment"
  elif [[ -n "$operation_id" || -n "$release_id" ]]; then
    toolkit_die '--operation-id and --release-id require --action'
  fi
  toolkit_assert_supported_platform
  command -v flock >/dev/null 2>&1 || toolkit_die 'flock is required for lock coordination'

  host_path='/run/lock/toolkit/host.lock'
  TOOLKIT_ACTIVE_OPERATION_FAILURE_PHASE=lock
  [[ ! -L /run/lock/toolkit && ! -L "$host_path" ]] || toolkit_die 'toolkit lock path must not be a symlink'
  install -d -o root -g root -m 0755 /run/lock/toolkit || toolkit_die 'cannot prepare toolkit lock directory'
  : >>"$host_path" || toolkit_die 'cannot open shared host lock'
  chmod 0644 "$host_path" || toolkit_die 'cannot set shared host lock permissions'
  exec {host_fd}>>"$host_path" || toolkit_die 'cannot open shared host lock'
  toolkit_log info "waiting for host lock timeout_seconds=$timeout"
  if ! flock -x -w "$timeout" "$host_fd"; then
    exec {host_fd}>&-
    toolkit_die "timed out waiting for host lock: $host_path"
  fi
  toolkit_log info "acquired host lock path=$host_path"

  if [[ -n "$repository" ]]; then
    project_dir="/run/lock/toolkit/repos/$repository"
    project_path="$project_dir/$environment.lock"
    [[ ! -L /run/lock/toolkit/repos && ! -L "$project_dir" && ! -L "$project_path" ]] || toolkit_die 'repository lock path must not be a symlink'
    install -d -o root -g root -m 0755 /run/lock/toolkit/repos "$project_dir" || toolkit_die 'cannot prepare repository lock directory'
    : >>"$project_path" || toolkit_die 'cannot open repository/environment lock'
    chmod 0644 "$project_path" || toolkit_die 'cannot set repository/environment lock permissions'
    exec {project_fd}>>"$project_path" || toolkit_die 'cannot open repository/environment lock'
    toolkit_log info "waiting for repository lock repository=$repository environment=$environment timeout_seconds=$timeout"
    if ! flock -x -w "$timeout" "$project_fd"; then
      exec {project_fd}>&-
      flock -u "$host_fd"
      exec {host_fd}>&-
      toolkit_die "timed out waiting for repository/environment lock: $project_path"
    fi
    toolkit_log info "acquired repository lock repository=$repository environment=$environment"
  fi

  TOOLKIT_ACTIVE_OPERATION_FAILURE_PHASE='command'
  "$@"
  status=$?
  if [[ -n "$repository" ]]; then
    flock -u "$project_fd"
    exec {project_fd}>&-
  fi
  flock -u "$host_fd"
  exec {host_fd}>&-
  return "$status"
}
