#!/usr/bin/env python3
"""Build only staged toolkit source and stage its release on the shelf, on every commit."""
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"]).decode().strip())
with tempfile.TemporaryDirectory() as directory:
    builder = Path(directory) / "toolkit/packaging/build-release.py"
    builder.parent.mkdir(parents=True)
    builder.write_bytes(subprocess.check_output(["git", "show", ":toolkit/packaging/build-release.py"], cwd=root))
    subprocess.run([sys.executable, str(builder), str(root / "releases"), "--repository", str(root), "--ref", "index"],
                   cwd=root, check=True)
lock = (root / "releases/toolkit.lock").read_text(encoding="utf-8")
version = next(line.split("=", 1)[1] for line in lock.splitlines() if line.startswith("TOOLKIT_VERSION="))
subprocess.run(["git", "add", "--", "releases/toolkit.lock", "releases/README.md", f"releases/toolkit-{version}.tar.gz",
                f"releases/toolkit-{version}.tar.gz.sha256"], cwd=root, check=True)
