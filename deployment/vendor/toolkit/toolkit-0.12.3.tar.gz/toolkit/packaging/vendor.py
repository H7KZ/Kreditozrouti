#!/usr/bin/env python3
"""Pin consuming repositories to the newest release on this checkout's shelf, or check them.

Copies releases/ (written by the pre-commit hook) into <repo>/deployment/vendor/toolkit/, writes
both lock copies, extracts the managed files from the release archive, and removes other vendored
versions and retired managed files. With --check nothing changes; drift exits 1.

  npm run vendor -- ../Ohlidame              npm run repin    (every known consumer)
  npm run vendor -- --check ../Ohlidame      npm run status
"""
import argparse
import hashlib
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "releases"
# Release archive member -> managed copy below the consumer's deployment/ directory.
MANAGED_SCRIPTS = {
    "toolkit/consumer/toolkit": "toolkit",
    "toolkit/consumer/validate-lock.sh": "vendor/toolkit/validate-lock.sh",
    "toolkit/consumer/log.sh": "vendor/toolkit/log.sh",
}
EXECUTABLE = {"toolkit", "vendor/toolkit/validate-lock.sh"}
# Managed by releases before 0.11.0; deployment/toolkit replaced them.
RETIRED = ("verify-toolkit-pin.sh", "install-toolkit.sh")
VENDORED_ARCHIVE = re.compile(r"toolkit-\d+\.\d+\.\d+\.tar\.gz(\.sha256)?")
LOCK_KEYS = {"VERSION": "TOOLKIT_VERSION", "SOURCE_COMMIT": "TOOLKIT_SOURCE_COMMIT"}


def fields(text):
    result = {}
    for line in text.splitlines():
        key, separator, value = line.partition("=")
        if not separator or key in result:
            raise ValueError(f"malformed or duplicate field: {line!r}")
        result[key] = value
    return result


def published_release():
    """Return the newest version and {deployment-relative path: bytes} every consumer must hold."""
    lock_bytes = (SOURCE / "toolkit.lock").read_bytes()
    lock = fields(lock_bytes.decode())
    version = lock["TOOLKIT_VERSION"]
    source_version = subprocess.run(["git", "-C", str(ROOT), "show", ":toolkit/VERSION"],
                                    capture_output=True, text=True, check=True).stdout.strip()
    if source_version != version:
        raise ValueError(f"toolkit/VERSION is {source_version} but the newest release is {version}; "
                         "commit the toolkit change (the hook packages it) or run npm run package")
    name = f"toolkit-{version}.tar.gz"
    archive = (SOURCE / name).read_bytes()
    checksum = (SOURCE / f"{name}.sha256").read_bytes()
    digest = hashlib.sha256(archive).hexdigest()
    if lock["TOOLKIT_ARCHIVE_SHA256"] != digest or checksum != f"{digest}  {name}\n".encode():
        raise ValueError(f"{SOURCE / name} does not match its lock or checksum; run npm run package")
    files = {}
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as stream:
        for key, value in fields(stream.extractfile("toolkit/MANIFEST").read().decode()).items():
            if lock.get(LOCK_KEYS.get(key, key)) != value:
                raise ValueError(f"toolkit.lock disagrees with the release manifest on {key}")
        for member, path in MANAGED_SCRIPTS.items():
            try:
                files[path] = stream.extractfile(member).read()
            except KeyError:
                raise ValueError(f"toolkit {version} has no {member}") from None
    files.update({
        "toolkit.lock": lock_bytes,
        "vendor/toolkit/toolkit.lock": lock_bytes,
        "vendor/toolkit/README.md": (SOURCE / "README.md").read_bytes(),
        f"vendor/toolkit/{name}": archive,
        f"vendor/toolkit/{name}.sha256": checksum,
    })
    return version, files


def pinned_version(deployment):
    try:
        return fields((deployment / "toolkit.lock").read_text(encoding="utf-8")).get("TOOLKIT_VERSION", "unknown")
    except (OSError, ValueError):
        return "none"


def vendor(argument, version, files, check):
    """Bring one repository to the release, or report its drift. Returns True when it already matched."""
    repository, label = argument.resolve(), argument.as_posix()
    deployment = repository / "deployment"
    if repository == ROOT:
        raise ValueError("the Toolkit repository publishes releases; it does not vendor them")
    if not deployment.is_dir():
        raise ValueError(f"{label} has no deployment/ directory")
    vendor_dir = deployment / "vendor/toolkit"
    keep = {Path(path).name for path in files if path.startswith("vendor/toolkit/")}
    stale = [] if not vendor_dir.is_dir() else sorted(
        path for path in vendor_dir.iterdir() if VENDORED_ARCHIVE.fullmatch(path.name) and path.name not in keep)
    stale += [deployment / path for path in RETIRED if (deployment / path).is_file()]
    changed = [path for path, data in files.items()
               if not (deployment / path).is_file() or (deployment / path).read_bytes() != data]
    pinned = pinned_version(deployment)
    if not changed and not stale:
        print(f"{label}: toolkit {version} up to date")
        return True
    if check:
        print(f"{label}: pinned {pinned}, expected {version}")
        for path in changed:
            print(f"  {'differs' if (deployment / path).exists() else 'missing'}  deployment/{path}")
        for path in stale:
            print(f"  stale    {path.relative_to(repository).as_posix()}")
        return False
    for path in changed:
        target = deployment / path
        if target.is_symlink():
            raise ValueError(f"refusing to replace symlink {target}")
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(f".{target.name}.vendor")
        temporary.write_bytes(files[path])
        temporary.chmod(0o755 if path in EXECUTABLE else 0o644)
        os.replace(temporary, target)
    for path in stale:
        path.unlink()
    action = f"refreshed {version}" if pinned == version else f"{pinned} -> {version}"
    print(f"{label}: toolkit {action} ({len(changed)} written, {len(stale)} removed)")
    retired = [f"deployment/{path}" for path in RETIRED if deployment / path in stale]
    paths = " ".join(["deployment/toolkit", "deployment/toolkit.lock", "deployment/vendor/toolkit", *retired])
    print(f"  review, then: git -C {label} add -A {paths} && git -C {label} commit -m 'chore(deploy): pin toolkit {version}'")
    return False


def main():
    global ROOT, SOURCE
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("repositories", nargs="+", type=Path, help="consuming repository roots")
    parser.add_argument("--check", action="store_true", help="report drift without changing files")
    parser.add_argument("--toolkit", type=Path, default=ROOT, help="Toolkit checkout holding the release shelf")
    args = parser.parse_args()
    ROOT = args.toolkit.resolve()
    SOURCE = ROOT / "releases"
    try:
        version, files = published_release()
        dirty = subprocess.run(["git", "-C", str(ROOT), "status", "--porcelain", "--", "toolkit", "releases"],
                               capture_output=True, text=True, check=True).stdout
        if dirty and not args.check:
            print("warning: the Toolkit checkout has uncommitted changes; commit them before pushing these pins")
        matched = [vendor(repository, version, files, args.check) for repository in args.repositories]
    except (ValueError, KeyError, OSError, tarfile.TarError, subprocess.CalledProcessError) as error:
        parser.exit(1, f"toolkit vendor: {error}\n")
    if args.check:
        if not all(matched):
            sys.stdout.flush()
            parser.exit(1, "toolkit vendor: drift found; run without --check to re-vendor\n")
        return


if __name__ == "__main__":
    main()
