#!/usr/bin/env python3
"""Exercise consumer vendoring and the deployment/toolkit entrypoint it installs."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
MANAGED = ("toolkit", "toolkit.lock", "vendor/toolkit/toolkit.lock", "vendor/toolkit/README.md",
           "vendor/toolkit/validate-lock.sh", "vendor/toolkit/log.sh", "vendor/toolkit/toolkit-0.11.0.tar.gz",
           "vendor/toolkit/toolkit-0.11.0.tar.gz.sha256")


class VendorTests(unittest.TestCase):
    def setUp(self):
        work = tempfile.TemporaryDirectory()
        self.addCleanup(work.cleanup)
        self.toolkit = Path(work.name) / "toolkit-repo"
        self.consumer = Path(work.name) / "consumer"
        source = self.toolkit / "toolkit"
        shutil.copytree(ROOT / "toolkit/consumer", source / "consumer")
        (source / "packaging").mkdir()
        for script in ("build-release.py", "vendor.py"):
            shutil.copy(ROOT / "toolkit/packaging" / script, source / "packaging")
        (source / "bin").mkdir()
        (source / "bin/toolkit").write_text('#!/bin/bash\nprintf "args=%s\\n" "$*"\n', newline="\n")
        (source / "VERSION").write_text("0.11.0\n", newline="\n")
        self.git("init", "-q")
        self.git("add", ".")
        self.run_script("build-release.py", str(self.toolkit / "releases"), "--ref", "index")
        deployment = self.consumer / "deployment"
        (deployment / "vendor/toolkit").mkdir(parents=True)
        for name in ("toolkit-0.10.0.tar.gz", "toolkit-0.10.0.tar.gz.sha256"):
            (deployment / "vendor/toolkit" / name).write_text("old\n")
        for retired in ("verify-toolkit-pin.sh", "install-toolkit.sh"):
            (deployment / retired).write_text("# retired managed file\n")
        (deployment / "deploy.sh").write_text("# consumer owned\n")
        (deployment / "toolkit.conf").write_text("REPOSITORY=consumer\n")

    def git(self, *args):
        subprocess.run(["git", "-C", str(self.toolkit), *args], check=True, capture_output=True)

    def run_script(self, script, *args, check=True):
        return subprocess.run([sys.executable, str(self.toolkit / "toolkit/packaging" / script), *args],
                              capture_output=True, text=True, check=check)

    def vendor(self, *args, check=True):
        return self.run_script("vendor.py", *args, check=check)

    def test_vendor_writes_managed_files_and_removes_old_and_retired_ones(self):
        result = self.vendor(str(self.consumer))
        self.assertIn("toolkit none -> 0.11.0", result.stdout)
        self.assertIn("deployment/verify-toolkit-pin.sh", result.stdout)
        deployment = self.consumer / "deployment"
        shelf = self.toolkit / "releases"
        for path in MANAGED:
            self.assertTrue((deployment / path).is_file(), path)
        self.assertEqual((deployment / "toolkit.lock").read_bytes(), (shelf / "toolkit.lock").read_bytes())
        self.assertEqual((deployment / "toolkit").read_bytes(), (ROOT / "toolkit/consumer/toolkit").read_bytes())
        for gone in ("vendor/toolkit/toolkit-0.10.0.tar.gz", "verify-toolkit-pin.sh", "install-toolkit.sh"):
            self.assertFalse((deployment / gone).exists(), gone)
        self.assertEqual((deployment / "deploy.sh").read_text(), "# consumer owned\n")
        self.assertEqual((deployment / "toolkit.conf").read_text(), "REPOSITORY=consumer\n")
        self.assertIn("up to date", self.vendor("--check", str(self.consumer)).stdout)

    def test_check_reports_drift_without_changing_files(self):
        self.vendor(str(self.consumer))
        edited = self.consumer / "deployment/toolkit"
        edited.write_text("# hand edited\n")
        result = self.vendor("--check", str(self.consumer), check=False)
        self.assertEqual(result.returncode, 1)
        self.assertIn("differs  deployment/toolkit", result.stdout)
        self.assertEqual(edited.read_text(), "# hand edited\n")
        (self.consumer / "deployment/toolkit.lock").unlink()
        self.assertIn("missing  deployment/toolkit.lock", self.vendor("--check", str(self.consumer), check=False).stdout)

    def test_toolkit_repository_cannot_vendor_itself(self):
        (self.toolkit / "deployment").mkdir()
        result = self.vendor(str(self.toolkit), check=False)
        self.assertEqual(result.returncode, 1)
        self.assertIn("publishes releases", result.stderr)

    def test_unpackaged_version_bump_is_rejected(self):
        (self.toolkit / "toolkit/VERSION").write_text("0.11.1\n", newline="\n")
        self.git("add", "toolkit/VERSION")
        result = self.vendor(str(self.consumer), check=False)
        self.assertEqual(result.returncode, 1)
        self.assertIn("toolkit/VERSION is 0.11.1 but the newest release is 0.11.0", result.stderr)
        self.assertFalse((self.consumer / "deployment/toolkit.lock").exists())

    @unittest.skipIf(os.name == "nt" or not shutil.which("sha256sum"), "needs GNU userland")
    def test_entrypoint_verifies_and_runs_only_the_pinned_release(self):
        self.vendor(str(self.consumer))
        entrypoint = self.consumer / "deployment/toolkit"
        environment = dict(os.environ, TOOLKIT_DIRECT="1")

        def run(*args):
            return subprocess.run(["bash", str(entrypoint), *args], capture_output=True, text=True, env=environment)

        self.assertEqual(run("verify").returncode, 0, run("verify").stderr)
        result = run("backup", "list")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), f"args=--repo-root {self.consumer} backup list")
        log = self.consumer / "deployment/vendor/toolkit/log.sh"
        log.write_text(log.read_text() + "# hand edited\n")
        self.assertIn("vendor/toolkit/log.sh differs from toolkit 0.11.0", run("verify").stderr)
        self.assertNotEqual(run("version").returncode, 0)
        self.vendor(str(self.consumer))
        lock = self.consumer / "deployment/vendor/toolkit/toolkit.lock"
        lock.write_text(lock.read_text() + "EXTRA=1\n")
        self.assertIn("vendor/toolkit/toolkit.lock differs", run("verify").stderr)


if __name__ == "__main__":
    unittest.main()
