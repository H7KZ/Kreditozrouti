# VPS toolkit

Deploys, rollbacks, boot reconcile, backups, jobs, locks and host maintenance for the shared
Ubuntu 26.04 VPS. Every consuming repository vendors a packaged release of this directory and runs
it through its own `deployment/toolkit`.

Guides are not packaged, so they can change without a release: https://github.com/H7KZ/Toolkit/tree/main/docs

- `VERSION` — release version; bump it with every change here
- `bin/toolkit` — entry point and command dispatch
- `commands/`, `lib/` — commands and shared helpers (`lib/repo.sh` reads `toolkit.conf`)
- `consumer/` — managed files copied into every consumer's `deployment/`
- `packaging/` — release builder, pre-commit hook, vendoring, loader (`run-bundle.py`)
- `contracts/` — frozen cross-repository protocols and JSON schemas
- `config/` — example host configuration
- `tests/` — test suite
