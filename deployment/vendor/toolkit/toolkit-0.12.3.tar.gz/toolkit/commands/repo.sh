#!/usr/bin/env bash
# Repository integration on a host: `install` copies the repository's pinned toolkit and declared
# scripts to /opt/toolkit/<repo>/ and renders its systemd units; `reconcile` and `job` run them.

TOOLKIT_RUNNER_PATH=/usr/local/libexec/toolkit-run-bundle
TOOLKIT_UNIT_DIR="${TOOLKIT_UNIT_DIR:-/etc/systemd/system}"

toolkit_install_usage() {
  cat <<'USAGE'
Usage: sudo deployment/toolkit install --deploy-user USER [--env-file FILE] [--ci-only]

Installs, from this checkout, everything the repository declares in deployment/toolkit.conf:
  /usr/local/libexec/toolkit-run-bundle   loader the deploy user may run through sudo
  /etc/sudoers.d/toolkit-runner-USER      that one sudo permission
  /opt/toolkit/<repo>/                    root-owned copy of the pinned toolkit and declared scripts
  /etc/systemd/system/toolkit-<repo>-*    reconcile, backup, job and failure-alert units, enabled
  /etc/toolkit/<repo>.env                 with --env-file: operator settings (root, 0600)
The backup timer is enabled by `backup setup` after one successful run, which install performs
while the timer is still disabled. Units the repository no longer declares are disabled and removed.
--ci-only installs only the loader and the sudo permission.
USAGE
}

# Copies one repository-relative path (a file's whole directory) into the staged control copy.
toolkit_install_copy_dir() {
  local relative="$1" stage="$2" directory
  [[ -e "$TOOLKIT_REPO_ROOT/$relative" ]] || toolkit_die "toolkit.conf names a missing path: $relative"
  directory="$(dirname -- "$relative")"
  [[ ! -L "$TOOLKIT_REPO_ROOT/$directory" ]] || toolkit_die "declared directory must not be a symlink: $directory"
  install -d -m 0755 "$stage/$directory" || toolkit_die "cannot stage $directory"
  rsync -a --no-links --exclude '.env*' --exclude '.git' --exclude '__pycache__' \
    "$TOOLKIT_REPO_ROOT/$directory/" "$stage/$directory/" || toolkit_die "cannot copy $directory"
}

# Everything install needs from a checkout: the pinned toolkit, toolkit.conf and the directories of
# the declared scripts. Used for the control copy and, through `pack`, for the Host Sync packet.
toolkit_repo_stage_files() {
  local stage="$1" file job
  install -d -m 0755 "$stage/deployment/vendor/toolkit" || toolkit_die "cannot prepare $stage"
  for file in toolkit toolkit.lock toolkit.conf vendor/toolkit/validate-lock.sh vendor/toolkit/log.sh vendor/toolkit/toolkit.lock \
    "vendor/toolkit/toolkit-$TOOLKIT_VERSION.tar.gz" "vendor/toolkit/toolkit-$TOOLKIT_VERSION.tar.gz.sha256"; do
    [[ -f "$TOOLKIT_REPO_ROOT/deployment/$file" && ! -L "$TOOLKIT_REPO_ROOT/deployment/$file" ]] || toolkit_die "missing managed file deployment/$file; re-vendor the toolkit"
    cp -- "$TOOLKIT_REPO_ROOT/deployment/$file" "$stage/deployment/$file" || toolkit_die "cannot copy deployment/$file"
  done
  for file in "${TOOLKIT_REPO[RECONCILE_BEFORE]:-}" "${TOOLKIT_REPO[BACKUP_COMPONENTS]:-}"; do
    [[ -z "$file" ]] || toolkit_install_copy_dir "$file" "$stage"
  done
  for job in "${TOOLKIT_REPO_JOBS[@]}"; do
    toolkit_install_copy_dir "$(toolkit_repo_job "$job" RUN)" "$stage"
  done
}

toolkit_install_control_copy() {
  local user="$1" home="$2" control stage
  control="$(toolkit_repo_control_dir)"
  [[ "$TOOLKIT_REPO_ROOT" != "$control" ]] || toolkit_die 'install from a checkout of the repository, not from its installed control copy'
  [[ ! -L "$TOOLKIT_REPO_CONTROL_ROOT" && ! -L "$control" ]] || toolkit_die 'control paths must not be symlinks'
  install -d -o root -g root -m 0755 "$TOOLKIT_REPO_CONTROL_ROOT" || toolkit_die 'cannot prepare /opt/toolkit'
  stage="$(mktemp -d "$TOOLKIT_REPO_CONTROL_ROOT/.stage.XXXXXXXX")" || toolkit_die 'cannot stage control copy'
  toolkit_register_temp_path "$stage"
  toolkit_repo_stage_files "$stage"
  printf 'DEPLOY_USER=%s\nDEPLOY_HOME=%s\n' "$user" "$home" >"$stage/host.env"
  chown -R root:root "$stage" && chmod -R go-w "$stage" && chmod 0755 "$stage" "$stage/deployment/toolkit" ||
    toolkit_die 'cannot protect control copy'
  if [[ -d "$control" ]]; then
    rm -rf -- "$control.old"
    mv -T -- "$control" "$control.old" || toolkit_die 'cannot retire previous control copy'
  fi
  mv -T -- "$stage" "$control" || toolkit_die 'cannot publish control copy'
  rm -rf -- "$control.old"
  toolkit_log info "control copy installed path=$control version=$TOOLKIT_VERSION"
}

toolkit_install_unit() {
  local name="$1" content="$2"
  printf '%s' "$content" >"$TOOLKIT_UNIT_DIR/.$name.new" || toolkit_die "cannot write unit $name"
  chmod 0644 "$TOOLKIT_UNIT_DIR/.$name.new"
  mv -f -- "$TOOLKIT_UNIT_DIR/.$name.new" "$TOOLKIT_UNIT_DIR/$name" || toolkit_die "cannot install unit $name"
  TOOLKIT_INSTALLED_UNITS+=("$name")
}

toolkit_install_timer() {
  local name="$1" description="$2" calendar="$3"
  if command -v systemd-analyze >/dev/null 2>&1; then
    systemd-analyze calendar "$calendar" >/dev/null 2>&1 || toolkit_die "invalid OnCalendar for $name: $calendar"
  fi
  toolkit_install_unit "$name" "[Unit]
Description=$description

[Timer]
OnCalendar=$calendar
Persistent=true
AccuracySec=1min

[Install]
WantedBy=timers.target
"
}

toolkit_install_service() {
  local name="$1" description="$2" exec="$3" timeout="$4" extra="${5:-}"
  toolkit_install_unit "$name" "[Unit]
Description=$description
Requires=docker.service
After=docker.service network-online.target
Wants=network-online.target
OnFailure=toolkit-$(toolkit_repo_name)-notify@%n.service

[Service]
Type=oneshot
User=root
UMask=0077
ExecStart=$exec
TimeoutStartSec=$timeout
KillMode=control-group
SyslogIdentifier=${name%%@*}
${extra}"
}

toolkit_install_units() {
  local repo control job existing stale
  repo="$(toolkit_repo_name)"
  control="$(toolkit_repo_control_dir)/deployment/toolkit"
  declare -ga TOOLKIT_INSTALLED_UNITS=()
  install -d -m 0755 "$TOOLKIT_UNIT_DIR" || toolkit_die "cannot prepare $TOOLKIT_UNIT_DIR"
  if ((${#TOOLKIT_REPO_TARGETS[@]})); then
    toolkit_install_service "toolkit-$repo-reconcile.service" "Toolkit: start $repo release snapshots after boot" \
      "$control reconcile" 120min "RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
"
  fi
  # Any failing toolkit unit of this repository posts to Discord (ALERT_DISCORD_WEBHOOK_URL).
  toolkit_install_unit "toolkit-$repo-notify@.service" "[Unit]
Description=Toolkit: $repo failure alert for %i

[Service]
Type=oneshot
User=root
ExecStart=$control notify %i
TimeoutStartSec=2min
"
  if [[ -n "${TOOLKIT_REPO[BACKUP_COMPONENTS]:-}" ]]; then
    toolkit_install_service "toolkit-$repo-backup.service" "Toolkit: $repo backup" "$control backup run" 3h "Nice=10
IOSchedulingClass=idle
"
    toolkit_install_timer "toolkit-$repo-backup.timer" "Toolkit: $repo backup schedule" "${TOOLKIT_REPO[BACKUP_AT]}"
  fi
  for job in "${TOOLKIT_REPO_JOBS[@]}"; do
    toolkit_install_service "toolkit-$repo-$job.service" "Toolkit: $repo $job" "$control job $job" 2h
    toolkit_install_timer "toolkit-$repo-$job.timer" "Toolkit: $repo $job schedule" "$(toolkit_repo_job "$job" AT)"
  done
  if [[ -n "${TOOLKIT_REPO[MAINTENANCE_AT]:-}" ]]; then
    local reboot_flag=""
    [[ "${TOOLKIT_REPO[MAINTENANCE_REBOOT]:-false}" != true ]] || reboot_flag=" --reboot"
    toolkit_install_service toolkit-maintenance.service 'Toolkit: host package updates and health report' "$control maintenance$reboot_flag" 2h
    toolkit_install_timer toolkit-maintenance.timer 'Toolkit: host maintenance schedule' "${TOOLKIT_REPO[MAINTENANCE_AT]}"
  fi
  # Units this repository rendered before but no longer declares.
  for existing in "$TOOLKIT_UNIT_DIR"/toolkit-"$repo"-*; do
    [[ -f "$existing" ]] || continue
    stale="$(basename -- "$existing")"
    [[ " ${TOOLKIT_INSTALLED_UNITS[*]} " != *" $stale "* ]] || continue
    if [[ -d /run/systemd/system ]] && command -v systemctl >/dev/null 2>&1; then
      systemctl disable --now "$stale" >/dev/null 2>&1 || true
    fi
    rm -f -- "$existing"
    toolkit_log info "removed undeclared unit $stale"
  done
  if [[ -d /run/systemd/system ]] && command -v systemctl >/dev/null 2>&1; then
    systemctl daemon-reload || toolkit_die 'systemctl daemon-reload failed'
  fi
}

# Declared units run from now on: timers start, the boot reconcile is enabled for the next boot.
# The backup timer is left to `backup setup` (first successful run).
toolkit_install_enable_units() {
  local unit
  [[ -d /run/systemd/system ]] && command -v systemctl >/dev/null 2>&1 || return 0
  for unit in "${TOOLKIT_INSTALLED_UNITS[@]}"; do
    case "$unit" in
    *@.service | *-backup.timer | *-backup.service) ;;
    *.timer) systemctl enable --now "$unit" >/dev/null 2>&1 || toolkit_die "cannot enable $unit" ;;
    *-reconcile.service) systemctl enable "$unit" >/dev/null 2>&1 || toolkit_die "cannot enable $unit" ;;
    esac
  done
}

# Installs operator settings rendered from secrets: allowlisted keys, single-line values.
toolkit_install_env_file() {
  local source="$1" target="$2" line key
  [[ -f "$source" && ! -L "$source" ]] || toolkit_die "--env-file is not a regular file: $source"
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -n "$line" && "$line" != '#'* ]] || continue
    [[ "$line" == *=* ]] || toolkit_die '--env-file lines must be KEY=value'
    key="${line%%=*}"
    toolkit_operator_env_key "$key" || toolkit_die "--env-file has unknown key $key"
    [[ "$key" != BACKUP_AGE_IDENTITY ]] || toolkit_die 'BACKUP_AGE_IDENTITY (the private key) must never be on the host'
  done <"$source"
  install -d -o root -g root -m 0755 "$(dirname -- "$target")" || toolkit_die "cannot prepare $(dirname -- "$target")"
  install -o root -g root -m 0600 "$source" "$target.new" && mv -f -- "$target.new" "$target" || toolkit_die "cannot install $target"
  toolkit_log info "operator settings installed path=$target"
}

toolkit_install_runner() {
  local user="$1" sudoers
  install -d -o root -g root -m 0755 "$(dirname -- "$TOOLKIT_RUNNER_PATH")"
  install -o root -g root -m 0755 "$TOOLKIT_ROOT/packaging/run-bundle.py" "$TOOLKIT_RUNNER_PATH.new" &&
    mv -f -- "$TOOLKIT_RUNNER_PATH.new" "$TOOLKIT_RUNNER_PATH" || toolkit_die 'cannot install the bundle runner'
  [[ -n "$user" ]] || return 0
  sudoers="$(mktemp)"
  printf '%s ALL=(root) NOPASSWD: %s *\n' "$user" "$TOOLKIT_RUNNER_PATH" >"$sudoers"
  visudo -cf "$sudoers" >/dev/null || toolkit_die 'generated sudoers rule failed validation'
  install -o root -g root -m 0440 "$sudoers" "/etc/sudoers.d/toolkit-runner-$user" || toolkit_die 'cannot install sudoers rule'
  rm -f -- "$sudoers"
}

toolkit_install() {
  local user='' ci_only=0 home repo env_file source_env=''
  while (($#)); do
    case "$1" in
    --deploy-user)
      (($# >= 2)) || toolkit_die '--deploy-user requires a value'
      user="$2"
      shift 2
      ;;
    --env-file)
      (($# >= 2)) || toolkit_die '--env-file requires a value'
      source_env="$2"
      shift 2
      ;;
    --ci-only)
      ci_only=1
      shift
      ;;
    -h | --help)
      toolkit_install_usage
      return 0
      ;;
    *) toolkit_die "unknown install option: $1" ;;
    esac
  done
  toolkit_require_root
  toolkit_assert_supported_platform
  if [[ -n "$user" ]]; then
    [[ "$user" =~ ^[A-Za-z_][A-Za-z0-9_-]{0,31}$ ]] || toolkit_die 'invalid deploy user name'
    home="$(toolkit_repo_user_home "$user")"
  fi
  toolkit_install_runner "$user"
  if ((ci_only == 1)); then
    toolkit_log info "bundle runner installed deploy_user=${user:-none}"
    return 0
  fi
  [[ -n "$user" ]] || toolkit_die 'install needs --deploy-user (the account that owns the release roots)'
  toolkit_repo_load
  repo="$(toolkit_repo_name)"
  toolkit_with_locks --repository "$repo" --environment production --action toolkit --release-id "$TOOLKIT_VERSION" -- \
    toolkit_install_locked "$user" "$home"
  env_file="$(toolkit_repo_env_file "$repo")"
  [[ -z "$source_env" ]] || toolkit_install_env_file "$source_env" "$env_file"
  toolkit_install_enable_units
  printf '\nInstalled %s with toolkit %s.\n' "$repo" "$TOOLKIT_VERSION"
  ((${#TOOLKIT_INSTALLED_UNITS[@]} == 0)) || printf 'Units: %s\n' "${TOOLKIT_INSTALLED_UNITS[*]}"
  [[ -n "${TOOLKIT_REPO[BACKUP_COMPONENTS]:-}" ]] || return 0
  # Outside the install lock: a backup run takes the repository lock itself.
  if [[ ! -f "$env_file" ]]; then
    toolkit_log warn "backups are declared but $env_file is missing; the backup timer stays disabled (run Host Sync)"
  elif [[ -d /run/systemd/system ]] && command -v systemctl >/dev/null 2>&1 &&
    ! systemctl is-enabled --quiet "toolkit-$repo-backup.timer" 2>/dev/null; then
    # A fresh host has nothing to capture until the first deploy; the schedule takes over then.
    if toolkit_repo_any_current "$home"; then
      toolkit_backup_setup "$repo"
    else
      toolkit_backup_setup "$repo" --enable-only
    fi
  fi
}

# True when any declared release target already has an active release on this host.
toolkit_repo_any_current() {
  local home="$1" target
  for target in "${TOOLKIT_REPO_TARGETS[@]}"; do
    [[ ! -L "$home/${target#*:}/current" ]] || return 0
  done
  return 1
}

toolkit_install_locked() {
  local user="$1" home="$2"
  toolkit_install_control_copy "$user" "$home"
  toolkit_install_units
  install -d -o root -g root -m 0755 "$TOOLKIT_REPO_CONFIG_DIR"
  if [[ -n "${TOOLKIT_REPO[BACKUP_COMPONENTS]:-}" && "${TOOLKIT_SKIP_BACKUP_TOOLS:-0}" != 1 ]]; then
    toolkit_backup_install_tools >&2
  fi
}

# Boot recovery for every declared release target, after the optional pre-reconcile script.
toolkit_repo_reconcile() {
  local user home repo target environment root name failures=0 before
  local -a selected=()
  [[ "${1:-}" != --user ]] || {
    user="$2"
    shift 2
  }
  toolkit_require_root
  toolkit_repo_load
  repo="$(toolkit_repo_name)"
  user="$(toolkit_repo_deploy_user "${user:-}")"
  home="$(toolkit_repo_user_home "$user")"
  ((${#TOOLKIT_REPO_TARGETS[@]})) || toolkit_die 'toolkit.conf declares no RELEASE_TARGETS'
  if (($#)); then
    selected=("$@")
  else
    for target in "${TOOLKIT_REPO_TARGETS[@]}"; do
      selected+=("${target##*/}")
    done
  fi
  before="${TOOLKIT_REPO[RECONCILE_BEFORE]:-}"
  if [[ -n "$before" ]] && ! "$TOOLKIT_ENTRYPOINT" with-lock --repository "$repo" --environment "${TOOLKIT_REPO_TARGETS[0]%%:*}" \
    --host-window --action maintenance --timeout 900 -- /bin/bash "$TOOLKIT_REPO_ROOT/$before"; then
    toolkit_log error "reconcile pre-step failed script=$before"
    failures=1
  fi
  for name in "${selected[@]}"; do
    read -r environment root name < <(toolkit_repo_target "$name" "$home") || toolkit_die "unknown release target: $name"
    if ! "$TOOLKIT_ENTRYPOINT" reconcile --repository "$repo" --environment "$environment" --root "$root" --user "$user"; then
      toolkit_log error "reconcile failed target=$name"
      failures=1
    fi
  done
  return "$failures"
}

# Fills --repository/--environment/--root/--user for `release <action> <target> ...`.
toolkit_repo_release_args() {
  local action="$1" name="$2" user home environment root
  shift 2
  toolkit_repo_load
  user="$(toolkit_repo_deploy_user '')"
  home="$(toolkit_repo_user_home "$user")"
  read -r environment root name < <(toolkit_repo_target "$name" "$home") || toolkit_die "unknown release target: $name (declared: ${TOOLKIT_REPO[RELEASE_TARGETS]:-none})"
  # Rollback and reconcile stay available on any host state; they only re-apply a saved snapshot.
  [[ "$action" =~ ^(stage|rollback|reconcile)$ ]] || toolkit_repo_assert_synced
  [[ ! "$action" =~ ^(deploy|activate)$ ]] || toolkit_repo_predeploy_backup "$environment" "$root"
  # shellcheck disable=SC2034 # read by bin/toolkit
  TOOLKIT_REPO_RELEASE_ARGS=("$action" --repository "$(toolkit_repo_name)" --environment "$environment" --root "$root" --user "$user" "$@")
}

toolkit_repo_job_run() {
  (($# == 1)) || toolkit_die 'usage: deployment/toolkit job <name>'
  local job="$1" script user home
  local -a lock=()
  toolkit_require_root
  toolkit_repo_load
  [[ " ${TOOLKIT_REPO_JOBS[*]} " == *" $job "* ]] || toolkit_die "unknown job: $job (declared: ${TOOLKIT_REPO[JOBS]:-none})"
  script="$TOOLKIT_REPO_ROOT/$(toolkit_repo_job "$job" RUN)"
  [[ -f "$script" && ! -L "$script" ]] || toolkit_die "job script is missing: $script"
  user="$(toolkit_repo_deploy_user '')"
  home="$(toolkit_repo_user_home "$user")"
  lock=(--repository "$(toolkit_repo_name)" --environment "$(toolkit_repo_job "$job" ENVIRONMENT)" --action maintenance --timeout "$(toolkit_repo_job "$job" TIMEOUT)")
  [[ "$(toolkit_repo_job "$job" HOST_WINDOW)" != true ]] || lock+=(--host-window)
  toolkit_with_locks "${lock[@]}" -- env TOOLKIT_REPOSITORY="$(toolkit_repo_name)" TOOLKIT_DEPLOY_USER="$user" \
    TOOLKIT_DEPLOY_HOME="$home" TOOLKIT_REPO_ROOT="$TOOLKIT_REPO_ROOT" /bin/bash "$script"
}

# Writes the Host Sync packet: what `install` needs from this checkout, nothing else. No root;
# CI runs it on the runner and uploads the directory.
toolkit_repo_pack() {
  (($# == 1)) || toolkit_die 'usage: deployment/toolkit pack <empty output directory>'
  local out="$1"
  toolkit_repo_load
  [[ ! -L "$out" ]] || toolkit_die 'pack output must not be a symlink'
  if [[ -e "$out" ]]; then
    [[ -d "$out" && -z "$(ls -A -- "$out")" ]] || toolkit_die "pack output must be a new or empty directory: $out"
  fi
  install -d -m 0700 "$out" || toolkit_die "cannot create $out"
  toolkit_repo_stage_files "$out"
  toolkit_log info "packed $(toolkit_repo_name) for host sync path=$out"
}

# OnFailure target of every toolkit unit: posts the failed unit to Discord. Never fails itself.
toolkit_repo_notify() {
  (($# == 1)) || toolkit_die 'usage: deployment/toolkit notify <unit>'
  local unit="$1" repo host body
  [[ "$unit" =~ ^[A-Za-z0-9@._:-]+$ ]] || toolkit_die 'invalid unit name'
  toolkit_repo_load
  repo="$(toolkit_repo_name)"
  toolkit_operator_env_read "$(toolkit_repo_env_file "$repo")"
  if [[ -z "${ALERT_DISCORD_WEBHOOK_URL:-}" ]]; then
    toolkit_log warn "unit failed unit=$unit; no ALERT_DISCORD_WEBHOOK_URL to notify"
    return 0
  fi
  host="$(hostname -s 2>/dev/null || echo host)"
  [[ "$host" =~ ^[A-Za-z0-9._-]+$ ]] || host=host
  body="{\"content\":\":rotating_light: **$host** \`$unit\` failed ($repo). Look: \`journalctl -u $unit -n 100\` or \`sudo deployment/toolkit doctor\`\"}"
  curl -fsS -m 10 --retry 3 -H 'Content-Type: application/json' --data-binary "$body" -o /dev/null \
    "$ALERT_DISCORD_WEBHOOK_URL" >/dev/null 2>&1 || toolkit_log warn "failure alert could not be delivered unit=$unit"
  return 0
}

# Before a release replaces a running non-development one, capture every backup component (a
# migration may change data). Runs before the deploy takes the repository lock; a failed capture
# stops the deploy. TOOLKIT_SKIP_PREDEPLOY_BACKUP=1 (as root on the host) skips it.
toolkit_repo_predeploy_backup() {
  local environment="$1" root="$2" repo
  [[ -n "${TOOLKIT_REPO[BACKUP_COMPONENTS]:-}" && "$environment" != development && -L "$root/current" ]] || return 0
  [[ "${TOOLKIT_SKIP_PREDEPLOY_BACKUP:-0}" != 1 ]] || return 0
  repo="$(toolkit_repo_name)"
  [[ -f "$(toolkit_repo_env_file "$repo")" ]] || return 0
  toolkit_log info "pre-deploy backup repository=$repo environment=$environment"
  toolkit_backup_run "$repo" || toolkit_die 'pre-deploy backup failed; nothing was deployed (fix the backup or set TOOLKIT_SKIP_PREDEPLOY_BACKUP=1 on the host)'
}

# A deploy refuses to run on a host Host Sync has not prepared: the installed control copy must pin
# this checkout's toolkit and every declared timer and the boot reconcile must be enabled.
toolkit_repo_assert_synced() {
  local repo control unit
  local -a units=()
  [[ "${TOOLKIT_SKIP_SYNC_CHECK:-0}" != 1 ]] || return 0
  [[ -d /run/systemd/system ]] && command -v systemctl >/dev/null 2>&1 || return 0
  repo="$(toolkit_repo_name)"
  control="$(toolkit_repo_control_dir)"
  [[ -f "$control/deployment/toolkit.lock" ]] && cmp -s "$control/deployment/toolkit.lock" "$TOOLKIT_REPO_ROOT/deployment/toolkit.lock" ||
    toolkit_die "host is not synced for $repo (installed toolkit differs from this release); run the Host Sync workflow"
  ((${#TOOLKIT_REPO_TARGETS[@]} == 0)) || units+=("toolkit-$repo-reconcile.service")
  [[ -z "${TOOLKIT_REPO[BACKUP_COMPONENTS]:-}" ]] || units+=("toolkit-$repo-backup.timer")
  for unit in "${TOOLKIT_REPO_JOBS[@]}"; do
    units+=("toolkit-$repo-$unit.timer")
  done
  [[ -z "${TOOLKIT_REPO[MAINTENANCE_AT]:-}" ]] || units+=(toolkit-maintenance.timer)
  for unit in "${units[@]}"; do
    systemctl is-enabled --quiet "$unit" 2>/dev/null ||
      toolkit_die "host is not synced for $repo ($unit is not enabled); run the Host Sync workflow"
  done
}
