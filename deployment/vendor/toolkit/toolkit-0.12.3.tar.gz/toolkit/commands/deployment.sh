#!/usr/bin/env bash

toolkit_deployment() {
  local action="$1" repository='' environment='' arg previous=''
  shift
  local -a arguments=("$action" "$@")
  for arg in "$@"; do
    case "$previous" in
    --repository) repository="$arg" ;;
    --environment) environment="$arg" ;;
    esac
    previous="$arg"
  done
  toolkit_validate_slug "$repository" || toolkit_die 'release requires --repository <slug>'
  toolkit_validate_slug "$environment" || toolkit_die 'release requires --environment <slug>'
  toolkit_require_root
  toolkit_assert_supported_platform
  command -v python3 >/dev/null 2>&1 || toolkit_die 'release commands require python3'
  local operation_action=deploy
  [[ "$action" != rollback ]] || operation_action=rollback
  [[ "$action" != reconcile ]] || operation_action=maintenance
  # The controller holds this repository lock throughout. Its host lock covers only
  # Compose mutations and health, so downloads never occupy the shared capacity window.
  toolkit_with_locks --repository "$repository" --environment "$environment" \
    --action "$operation_action" --timeout 1800 -- \
    python3 "$(toolkit_resolve_root "${BASH_SOURCE[0]%/commands/*}/bin/toolkit")/lib/deployment.py" "${arguments[@]}"
}
