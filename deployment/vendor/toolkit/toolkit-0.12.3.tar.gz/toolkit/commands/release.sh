#!/usr/bin/env bash

toolkit_stage_archive() {
  local archive="$1" checksum="$2" destination="$3" expected listed extra actual
  local -a lines=()
  [[ -f "$archive" && -r "$archive" && ! -L "$archive" ]] || toolkit_die 'release archive must be a readable regular file, not a symlink'
  [[ -f "$checksum" && -r "$checksum" && ! -L "$checksum" ]] || toolkit_die 'release checksum must be a readable regular file, not a symlink'
  mapfile -t lines <"$checksum"
  ((${#lines[@]} == 1)) || toolkit_die 'checksum file must contain exactly one line'
  read -r expected listed extra <<<"${lines[0]}"
  [[ "$expected" =~ ^[a-f0-9]{64}$ && -z "${extra:-}" ]] || toolkit_die 'checksum file must begin with one SHA-256 digest'
  if [[ -n "${listed:-}" && "$listed" != "$(basename -- "$archive")" ]]; then
    toolkit_die 'checksum filename does not match the archive basename'
  fi

  cp -- "$archive" "$destination/release.tar.gz" || toolkit_die 'cannot stage release archive'
  actual="$(sha256sum -- "$destination/release.tar.gz" | awk '{print $1}')" || toolkit_die 'cannot hash staged release archive'
  [[ "$actual" == "$expected" ]] || toolkit_die 'staged release archive SHA-256 mismatch'
  printf '%s  release.tar.gz\n' "$expected" >"$destination/release.tar.gz.sha256" || toolkit_die 'cannot stage release checksum'
  # shellcheck disable=SC2034 # read by the caller
  TOOLKIT_STAGED_ARCHIVE_SHA256="$expected"
}

toolkit_verify_release() {
  local archive="$1" checksum="$2" temp_dir manifest_version file_version
  temp_dir="$(mktemp -d /tmp/toolkit-inspect.XXXXXXXX)" || toolkit_die 'cannot create release verification directory'
  toolkit_register_temp_path "$temp_dir"
  toolkit_stage_archive "$archive" "$checksum" "$temp_dir"
  toolkit_check_archive "$temp_dir/release.tar.gz" "$temp_dir/release.tar.gz.sha256"
  mkdir -m 0700 "$temp_dir/payload" || toolkit_die 'cannot prepare release inspection directory'
  tar -xzf "$temp_dir/release.tar.gz" --no-same-owner --no-same-permissions -C "$temp_dir/payload" || toolkit_die 'cannot extract verified release for inspection'
  toolkit_manifest_parse "$temp_dir/payload/toolkit/MANIFEST"
  manifest_version="${TOOLKIT_MANIFEST[VERSION]}"
  IFS= read -r file_version <"$temp_dir/payload/toolkit/VERSION" || toolkit_die 'release VERSION file is unreadable'
  [[ "$file_version" == "$manifest_version" ]] || toolkit_die 'release VERSION file does not match its manifest'
  rm -rf -- "$temp_dir"
  toolkit_log info "release verified version=$manifest_version source_commit=${TOOLKIT_MANIFEST[SOURCE_COMMIT]}"
}
