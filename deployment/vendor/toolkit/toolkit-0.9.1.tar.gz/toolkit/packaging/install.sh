#!/usr/bin/env bash
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
archive='' checksum='' deploy_user='' activate=0 ci_only=0
while (($#)); do
  case "$1" in
  --archive | --checksum | --deploy-user)
    (($# >= 2)) || {
      echo "$1 requires a value" >&2
      exit 2
    }
    case "$1" in
    --archive) archive="$2" ;;
    --checksum) checksum="$2" ;;
    --deploy-user) deploy_user="$2" ;;
    esac
    shift 2
    ;;
  --activate)
    activate=1
    shift
    ;;
  --ci-only)
    ci_only=1
    shift
    ;;
  --help | -h)
    echo 'Usage: install.sh --archive PATH --checksum PATH [--deploy-user USER] [--ci-only | --activate]'
    exit 0
    ;;
  *)
    echo "Unknown option: $1" >&2
    exit 2
    ;;
  esac
done
[[ "$EUID" == 0 && -n "$archive" && -n "$checksum" ]] || {
  echo 'Root, --archive and --checksum required' >&2
  exit 2
}
((ci_only == 0 || activate == 0)) || {
  echo '--ci-only and --activate conflict' >&2
  exit 2
}
if [[ -n "$deploy_user" ]]; then
  [[ "$deploy_user" =~ ^[A-Za-z_][A-Za-z0-9_-]{0,31}$ ]] && id "$deploy_user" >/dev/null || {
    echo 'Invalid deployment account' >&2
    exit 2
  }
  command -v visudo >/dev/null
fi
bash "$root/bin/toolkit" verify-release --archive "$archive" --checksum "$checksum"
# Match the executing installer to the verified distribution before installing code.
temporary="$(mktemp -d)"
trap 'rm -rf -- "$temporary"' EXIT
cp -- "$archive" "$temporary/$(basename -- "$archive")"
cp -- "$checksum" "$temporary/$(basename -- "$archive").sha256"
archive="$temporary/$(basename -- "$archive")"
checksum="$archive.sha256"
bash "$root/bin/toolkit" verify-release --archive "$archive" --checksum "$checksum"
tar -xzf "$archive" --no-same-owner --no-same-permissions -C "$temporary"
cmp "$root/packaging/run-bundle.py" "$temporary/toolkit/packaging/run-bundle.py"
if ((ci_only == 0)); then
  bash "$root/bin/toolkit" install --archive "$archive" --checksum "$checksum"
fi
install -d -o root -g root -m 0755 /usr/local/libexec
install -o root -g root -m 0755 "$temporary/toolkit/packaging/run-bundle.py" /usr/local/libexec/toolkit-run-bundle
if [[ -n "$deploy_user" ]]; then
  printf '%s ALL=(root) NOPASSWD: /usr/local/libexec/toolkit-run-bundle *\n' "$deploy_user" >"$temporary/sudoers"
  visudo -cf "$temporary/sudoers"
  install -o root -g root -m 0440 "$temporary/sudoers" "/etc/sudoers.d/toolkit-ci-$deploy_user"
fi
if ((activate == 1)); then
  version="$(cat "$temporary/toolkit/VERSION")"
  "/opt/toolkit/releases/$version/bin/toolkit" activate "$version"
fi
printf 'CI bundle runner installed; host activation=%s host_install=%s\n' "$activate" "$((1 - ci_only))"
