#!/usr/bin/env python3
"""CI detects skipped hooks or stale distribution without modifying tracked files."""
from pathlib import Path
import subprocess
import sys
import tempfile
root = Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory() as directory:
    subprocess.run([sys.executable, str(root / "toolkit/packaging/build-release.py"), directory], check=True)
    for generated in Path(directory).iterdir():
        tracked = root / "deployment/vendor/toolkit" / generated.name
        if not tracked.is_file() or tracked.read_bytes() != generated.read_bytes():
            raise SystemExit(f"Stale distribution: {tracked}; stage toolkit and run npm run toolkit:package")
    if (root / "deployment/toolkit.lock").read_bytes() != (Path(directory) / "toolkit.lock").read_bytes():
        raise SystemExit("Stale deployment/toolkit.lock")
