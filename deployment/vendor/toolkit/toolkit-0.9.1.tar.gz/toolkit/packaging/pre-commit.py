#!/usr/bin/env python3
"""Build only staged toolkit source and stage its distribution, on every commit."""
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"]).decode().strip())
source = subprocess.check_output(["git", "show", ":toolkit/packaging/build-release.py"], cwd=root)
with tempfile.TemporaryDirectory() as directory:
    builder = Path(directory) / "toolkit/packaging/build-release.py"
    builder.parent.mkdir(parents=True)
    builder.write_bytes(source)
    subprocess.run([sys.executable, str(builder), str(root / "deployment/vendor/toolkit"),
                    "--repository", str(root), "--ref", "index"], cwd=root, check=True)
# Keep the Infrastructure consumer pin identical to the generated distribution.
(root / "deployment/toolkit.lock").write_bytes((root / "deployment/vendor/toolkit/toolkit.lock").read_bytes())
lock = (root / "deployment/toolkit.lock").read_text(encoding="utf-8")
version = next(line.split("=", 1)[1] for line in lock.splitlines() if line.startswith("TOOLKIT_VERSION="))
subprocess.run(["git", "add", "--", "deployment/toolkit.lock", "deployment/vendor/toolkit/toolkit.lock",
                "deployment/vendor/toolkit/README.md", f"deployment/vendor/toolkit/toolkit-{version}.tar.gz",
                f"deployment/vendor/toolkit/toolkit-{version}.tar.gz.sha256"], cwd=root, check=True)
