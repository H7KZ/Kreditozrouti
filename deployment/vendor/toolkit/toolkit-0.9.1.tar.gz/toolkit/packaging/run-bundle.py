#!/usr/bin/python3
"""Stable CI dispatcher. No dependency on the active administrator toolkit."""
import argparse
import hashlib
import io
import os
from pathlib import Path
import re
import subprocess
import tarfile
import tempfile


def values(path):
    result = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line or line.startswith("#"):
            continue
        key, value = line.split("=", 1)
        if key in result or not re.fullmatch(r"[A-Z][A-Z0-9_]*", key) or not value or any(c.isspace() for c in value):
            raise ValueError("invalid/duplicate manifest field")
        result[key] = value
    return result


def run(args):
    # Read once before checking: a caller cannot swap an archive after validation.
    payload = Path(args.archive).read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    checksum = Path(args.checksum).read_text(encoding="ascii").split()
    lock = values(args.lock)
    if checksum != [digest, Path(args.archive).name] or lock.get("TOOLKIT_ARCHIVE_SHA256") != digest:
        raise ValueError("toolkit checksum/pin mismatch")
    with tempfile.TemporaryDirectory(prefix="toolkit-ci-", dir="/var/tmp") as directory:
        root = Path(directory)
        with tarfile.open(fileobj=io.BytesIO(payload), mode="r:gz") as archive:
            seen = set()
            for entry in archive.getmembers():
                name = entry.name.rstrip("/")
                if (not re.fullmatch(r"toolkit(/[A-Za-z0-9._-]+)*", name)
                        or any(part in (".", "..") for part in name.split("/"))
                        or name in seen or not (entry.isfile() or entry.isdir())):
                    raise ValueError("unsafe/duplicate toolkit archive entry")
                seen.add(name)
            for required in ("toolkit", "toolkit/MANIFEST", "toolkit/VERSION", "toolkit/bin/toolkit"):
                if required not in seen:
                    raise ValueError(f"missing {required}")
            archive.extractall(root, filter="data")
        manifest = values(root / "toolkit/MANIFEST")
        for key, value in manifest.items():
            pinned_key = {"VERSION": "TOOLKIT_VERSION", "SOURCE_COMMIT": "TOOLKIT_SOURCE_COMMIT"}.get(key, key)
            if lock.get(pinned_key) != value:
                raise ValueError(f"toolkit manifest/pin mismatch: {key}")
        version = (root / "toolkit/VERSION").read_text().strip()
        if manifest.get("VERSION") != version or not re.fullmatch(r"\d+\.\d+\.\d+", version):
            raise ValueError("toolkit version mismatch")
        command = args.command
        if command and command[0] == "--":
            command = command[1:]
        if not command:
            raise ValueError("missing toolkit command after --")
        return subprocess.run(["/bin/bash", str(root / "toolkit/bin/toolkit"), *command], check=False).returncode


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True)
    parser.add_argument("--checksum", required=True)
    parser.add_argument("--lock", required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    try:
        if os.geteuid() != 0:
            raise ValueError("run as root through sudo")
        raise SystemExit(run(args))
    except (ValueError, OSError, tarfile.TarError) as error:
        parser.exit(1, f"toolkit bundle runner: {error}\n")
