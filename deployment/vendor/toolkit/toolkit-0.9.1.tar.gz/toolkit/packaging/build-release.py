#!/usr/bin/env python3
"""Package a Git snapshot, including staged changes, without reading worktree payloads."""
import argparse
import binascii
import hashlib
import io
import os
from pathlib import Path
import re
import subprocess
import struct
import tarfile

ROOT = Path(__file__).resolve().parents[2]


def git(*args, **kwargs):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], **kwargs)


def portable_gzip(data):
    # Stored DEFLATE blocks avoid byte differences between Windows/Linux zlib versions.
    result = bytearray(b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff")
    for offset in range(0, len(data), 65535):
        block = data[offset:offset + 65535]
        result.append(int(offset + len(block) == len(data)))
        result.extend(struct.pack("<HH", len(block), 65535 - len(block)))
        result.extend(block)
    result.extend(struct.pack("<II", binascii.crc32(data), len(data) % (2 ** 32)))
    return bytes(result)


def build(output, ref):
    tree = git("write-tree").decode().strip() if ref == "index" else git("rev-parse", f"{ref}^{{tree}}").decode().strip()
    # A reproducible source commit avoids the pre-commit parent/HEAD circularity.
    # It contains the toolkit subtree only, independent of generated artifacts.
    subtree = git("rev-parse", f"{tree}:toolkit").decode().strip()
    source_tree = git("mktree", input=f"040000 tree {subtree}\ttoolkit\n".encode()).decode().strip()
    env = dict(os.environ, GIT_AUTHOR_NAME="Toolkit packaging", GIT_COMMITTER_NAME="Toolkit packaging",
               GIT_AUTHOR_EMAIL="toolkit@localhost", GIT_COMMITTER_EMAIL="toolkit@localhost",
               GIT_AUTHOR_DATE="2000-01-01T00:00:00Z", GIT_COMMITTER_DATE="2000-01-01T00:00:00Z")
    commit = git("-c", "commit.gpgsign=false", "commit-tree", source_tree, input=b"Toolkit source snapshot\n", env=env).decode().strip()
    source = tarfile.open(fileobj=io.BytesIO(git("archive", "--format=tar", tree, "toolkit")))
    version = source.extractfile("toolkit/VERSION").read().decode().strip()
    if not re.fullmatch(r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)", version):
        raise ValueError("invalid toolkit VERSION")
    manifest = dict(VERSION=version, BUNDLE_FORMAT_VERSION="1", TOOLKIT_HELPER_API_VERSION="1",
                    HOST_CONFIG_SCHEMA_VERSION="1", STATUS_SCHEMA_VERSION="1", IMAGE_PROTECTION_SCHEMA_VERSION="1",
                    BACKUP_RECOVERY_REFERENCE_SCHEMA_VERSION="1", DEVELOPMENT_RELEASE_MANIFEST_SCHEMA_VERSION="1",
                    SUPPORTED_OS="ubuntu-26.04", SUPPORTED_ARCHITECTURES="amd64", DOCKER_ENGINE_RANGE="not-applicable",
                    DOCKER_COMPOSE_RANGE="not-applicable", PROXY_BUNDLE_VERSION="not-included", PLUGIN_PINS="none",
                    IMAGE_PINS="none", SOURCE_COMMIT=commit)
    entries = {}
    for member in source.getmembers():
        if not re.fullmatch(r"toolkit(/[A-Za-z0-9._-]+)*", member.name.rstrip("/")) or any(p in (".", "..", ".env") for p in Path(member.name).parts):
            raise ValueError(f"unsafe toolkit path: {member.name}")
        if not (member.isfile() or member.isdir()):
            raise ValueError(f"toolkit supports regular files/directories only: {member.name}")
        data = source.extractfile(member).read() if member.isfile() else None
        entries[member.name.rstrip("/")] = (data, member.mode)
    entries["toolkit/MANIFEST"] = ("".join(f"{k}={v}\n" for k, v in manifest.items()).encode(), 0o644)
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        for name, (data, mode) in sorted(entries.items()):
            info = tarfile.TarInfo(name)
            info.mode = 0o755 if data is None or mode & 0o111 else 0o644
            if data is None:
                info.type = tarfile.DIRTYPE
            else:
                info.size = len(data)
            archive.addfile(info, io.BytesIO(data) if data is not None else None)
    raw = portable_gzip(payload.getvalue())
    digest = hashlib.sha256(raw).hexdigest()
    output.mkdir(parents=True, exist_ok=True)
    name = f"toolkit-{version}.tar.gz"
    artifact = output / name
    checksum = f"{digest}  {name}\n".encode()
    for path, data in ((artifact, raw), (output / (name + ".sha256"), checksum)):
        if path.exists() and path.read_bytes() != data:
            raise ValueError(f"refusing to replace {path}; bump toolkit/VERSION")
        if not path.exists():
            with path.open("xb") as stream:
                stream.write(data)
    lock = dict(TOOLKIT_VERSION=version, TOOLKIT_SOURCE_COMMIT=commit, TOOLKIT_ARCHIVE_SHA256=digest,
                **{k: v for k, v in manifest.items() if k not in ("VERSION", "SOURCE_COMMIT")})
    (output / "toolkit.lock").write_text("".join(f"{k}={v}\n" for k, v in lock.items()), encoding="utf-8", newline="\n")
    (output / "README.md").write_text(f"""# Toolkit {version}

Ubuntu 26.04 amd64. Requires Bash, Python 3, GNU tar/coreutils, flock, systemd;
release deployment also requires Docker Engine + Compose plugin and rsync.
Docker, proxy, app secrets and app services are configured separately.
Obtain this bundle through a trusted channel; SHA-256 detects corruption, not authorship.

```bash
sha256sum -c {name}.sha256
tar -xzf {name}
# Choose your deployment account. Host CLI stays inactive by default.
sudo bash toolkit/packaging/install.sh --archive "$PWD/{name}" \\
  --checksum "$PWD/{name}.sha256" --deploy-user "YOUR_DEPLOY_USER"
# Add --activate to select this version for manual admin/boot commands.
# Use --ci-only to install just the CI runner and optional account permission.
sudo /opt/toolkit/releases/{version}/bin/toolkit activate {version}
sudo install -d -m 0755 /etc/toolkit
sudo cp toolkit/config/host.conf.example /etc/toolkit/host.conf
sudoedit /etc/toolkit/host.conf
toolkit validate --config /etc/toolkit/host.conf
toolkit plan --config /etc/toolkit/host.conf
sudo toolkit apply --config /etc/toolkit/host.conf --module swap
sudo toolkit apply --config /etc/toolkit/host.conf --module docker-logs
```

Only swap and Docker log policy are supported provisioning modules. Configuration is
literal KEY=value; no shell expansion. Inspect toolkit/README.md for options/limits.
Installation never deploys apps, enables timers, restarts Docker or applies host policy.

CI sends this archive, checksum and toolkit.lock with each operation, including rollback:

```bash
sudo -n /usr/local/libexec/toolkit-run-bundle --archive "$PWD/{name}" \\
  --checksum "$PWD/{name}.sha256" --lock "$PWD/toolkit.lock" -- version
```

The runner verifies/stages private code and runs that bundle. It never reads or changes
/opt/toolkit/current. Both processes share /run/lock/toolkit and /var/lib/toolkit.
Deploy accounts are trusted root-equivalent identities; bundle checks are integrity checks.
SOURCE_COMMIT identifies a reproducible Git commit containing only the toolkit subtree
(fixed packaging identity/date), so staged source can be packaged before its repo commit.
""", encoding="utf-8", newline="\n")
    print(f"archive={artifact}\nchecksum={artifact}.sha256\nsource_commit={commit}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--ref", default="HEAD", help="Git ref, or index for staged source")
    parser.add_argument("--repository", type=Path, default=ROOT, help="Source Git repository (defaults to this checkout)")
    args = parser.parse_args()
    ROOT = args.repository.resolve()
    try:
        build(args.output.resolve(), args.ref)
    except (ValueError, subprocess.CalledProcessError) as error:
        parser.exit(1, f"toolkit packaging: {error}\n")
