# VPS toolkit

This is the v1 Ubuntu 26.04 host toolkit. Infrastructure's `deployment/host/bootstrap.sh` installs the
pinned release on a new host, and deploys, rollbacks, backups and boot recovery run under its locks.
Repository-specific owner procedures live under `deployment/host/` and `deployment/migration/`;
the proxy stack and each repository's boot recovery remain consumer policy.

The current commands are `version`, `validate`, `plan`, `firewall plan`, `apply`, `status`, `operation`, `verify-release`, `with-lock`, `install`, `activate`, `release`, `reconcile`, and `backup`.
`validate` parses a host configuration without applying it. `plan` reports the parsed values, host
and platform limits, and read-only swap and Docker logging actions. `firewall plan` inventories the active Docker
firewall backend, competing firewall managers, iptables-nft tools and both Docker user chains; it
does not change rules. It blocks native nftables and Cloudflare mode until their separate strategies
are implemented. The file helper writes through a validated
same-directory temporary and atomic rename. `with-lock` takes a repository-wide lock; add `--host-window` for host mutations. Host-only
commands take only the host lock. Release operations take the repository lock throughout and the
host lock only around Compose changes and health. `install` validates release inputs before changing the installation
tree and stages a checksummed release without activating it; `activate` changes the installed release
symlink only. `operation start`/`finish` publish atomic root-only operation records; `with-lock --action`
records lock-wrapped work automatically. `apply --config <path> --module swap` provisions only the
explicitly selected swap module: it preserves active swap, refuses implicit resize, supports ext4/xfs,
requires requested size plus 1 GiB free, and resumes a valid inactive `/swapfile`. It does not change
sysctl, zswap, or boot settings. `apply --config <path> --module docker-logs` merges bounded
`json-file` defaults (10 MB per file, three files) into Docker's `daemon.json`, preserving unrelated
valid settings and refusing conflicting log settings. It validates the staged file with `dockerd`
before atomic replacement and never restarts Docker; a restart and container recreation are needed
for existing containers to adopt new defaults. Other provisioning modules remain unimplemented.

`backup` (0.7.0) is a generic, app-agnostic backup pipe. `backup run <repo> <4h|daily>` (or the systemd
instance form `<repo>-<cadence>`) loads `/etc/toolkit/backup/<repo>.env` and the repository's component
list, takes only that repository's lock (waiting up to 30 minutes, never `host.lock`), runs each producer
through `zstd` and `age` into a temp file, releases the lock, then uploads each fully successful file with
`rclone copyto` to `daily/` (and `weekly/` on the Sunday daily run). `backup list`, `fetch` and `check` read
the bucket for restore and freshness checks. Repositories supply only the component list; see
`deployment/backups/` in this repo and the [backup plan](../docs/plans/2026-10-backup-redesign.md).

## Local use

```sh
toolkit/bin/toolkit version
toolkit/bin/toolkit validate --config toolkit/config/host.conf.example
toolkit/bin/toolkit plan --config toolkit/config/host.conf.example
toolkit/bin/toolkit firewall plan --config toolkit/config/host.conf.example
toolkit/bin/toolkit apply --config toolkit/config/host.conf.example --module swap
```

Configuration uses literal `KEY=value` lines. It is not sourced or expanded by a shell. See
[`config/host.conf.example`](config/host.conf.example) and the frozen
[`contracts/handoff-v1.md`](contracts/handoff-v1.md).

## Distribution and execution (0.9.0)

Install development hooks once with `npm ci`. Husky packages the staged toolkit on every commit,
including partially staged packager/helper code, and stages only generated archive/checksum,
installation README and lock under
`deployment/vendor/toolkit/`. Bump `toolkit/VERSION` whenever committed toolkit content changes;
existing versioned bytes are immutable. CI rebuilds from HEAD and rejects skipped/stale hooks.
The package contains all tracked toolkit files, including config examples, contracts and tests;
untracked files and repository secrets never enter it. Build manually with:

```sh
python3 toolkit/packaging/build-release.py /absolute/output --ref index
# Omit --ref to package committed HEAD.
```

Packaging normalizes file order, timestamps, modes and gzip metadata. Stored gzip blocks keep
Windows/Linux builds byte-identical across zlib versions, trading compression for portability. `SOURCE_COMMIT` is a
reproducible Git source commit containing only `toolkit/`, created with fixed packaging identity,
date and message. It can be reproduced from the staged tree before the repository commit exists;
no branch is created. Generated distribution files never participate in its identity.
The adjacent SHA-256 file detects corruption; authenticate the distribution channel separately.
See the generated [installation README](../deployment/vendor/toolkit/README.md).

Two independent execution processes share the v1 lock paths and snapshot formats:

| Process | Code selection | Installation/activation |
| --- | --- | --- |
| CI deploy, activate, rollback | Exact repository-pinned archive sent with every operation | Root-installed stable `/usr/local/libexec/toolkit-run-bundle` validates lock/checksum, extracts to a private temporary tree, runs the bundle synchronously, then removes code. No host CLI needed. |
| Manual admin, boot reconcile, scheduled backup/retention | Explicitly selected `/usr/local/bin/toolkit` -> `/opt/toolkit/current` | Owner installs/activates separately. Current compatible host releases are >=0.8.1, <1.0.0. |

From a trusted consuming checkout, install the runner and authorize the actual deployment account:

```sh
sudo bash deployment/install-toolkit.sh --ci-only --deploy-user YOUR_DEPLOY_USER
# Optional: install the host CLI inactive too (omit --ci-only).
sudo bash deployment/install-toolkit.sh --deploy-user YOUR_DEPLOY_USER
# Optional explicit selection for admin and boot recovery:
sudo /opt/toolkit/releases/0.9.0/bin/toolkit activate 0.9.0
```

`--activate` combines host install and explicit activation. `--ci-only --activate` is rejected.
The installer never deploys an app, applies host config, enables a timer or restarts Docker.
App resources, credentials and boot units remain consumer-owned. Docker installation still uses
Infrastructure's `deployment/host/install-docker.sh`; toolkit only implements swap and Docker log policy.
The runner's sudo rule grants execution of trusted repository code as root, consistent with the
existing Docker deployment trust model. The lock authenticates bytes, not the publisher.

Upgrade from existing hosts once: install the runner/sudo rule using the command above; refresh
consumer boot/retention controls through their owner installers to remove old pin equality checks.
This does not change `/opt/toolkit/current`. Keep any host release at least 0.8.1: older lock protocols
cannot safely coexist. Future lock/schema changes require a coordinated compatibility migration.

## Compose release snapshots (0.8.1)

See [deployment-release-v1](contracts/deployment-release-v1.md) for the manifest and operator commands.
`release stage` checks an archive and renders a complete Compose snapshot. `release deploy` stages
and applies it; `release activate|rollback` applies an existing snapshot, including its saved config
and digests. `reconcile` uses the current snapshot with no pull, build or recreation. Secrets and
resolved Compose JSON live in private `.runtime/<release-id>/` directories outside source releases.
No deploy deletes old releases, images, data or orphans. Capacity and live recovery drills remain
owner work; snapshot tests use Docker stubs and do not establish production readiness.
