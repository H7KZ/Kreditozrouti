#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repo_root="$(cd -- "$script_dir/../.." && pwd -P)"
toolkit_root="$repo_root/toolkit"

if (($# != 1)); then
  printf 'Usage: %s <output-directory>\n' "$0" >&2
  exit 2
fi
output_dir="$1"
mkdir -p -- "$output_dir"
output_dir="$(cd -- "$output_dir" && pwd -P)"
git -C "$repo_root" diff --quiet -- toolkit || {
  printf 'toolkit packaging requires committed source files\n' >&2
  exit 1
}
git -C "$repo_root" diff --cached --quiet -- toolkit || {
  printf 'toolkit packaging requires committed staged source files\n' >&2
  exit 1
}
[[ -z "$(git -C "$repo_root" status --porcelain --untracked-files=all -- toolkit)" ]] || {
  printf 'toolkit packaging requires a clean toolkit worktree\n' >&2
  exit 1
}
[[ -z "$(find "$toolkit_root" -type l -print -quit)" ]] || {
  printf 'toolkit packaging rejects symbolic links in the source tree\n' >&2
  exit 1
}

version="$(<"$toolkit_root/VERSION")"
[[ "$version" =~ ^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$ ]] || {
  printf 'invalid toolkit VERSION: %s\n' "$version" >&2
  exit 1
}
source_commit="$(git -C "$repo_root" log -1 --format=%H -- toolkit)"
[[ "$source_commit" =~ ^[a-f0-9]{40,64}$ ]] || {
  printf 'cannot determine source commit\n' >&2
  exit 1
}
stage="$(mktemp -d)"
archive_temp=''
checksum_temp=''
archive=''
checksum=''
published_archive=0
published_checksum=0
toolkit_cleanup_package() {
  local status=$?
  trap - EXIT
  if ((status != 0)); then
    if ((published_checksum == 1)) && [[ -e "$checksum" && -e "$checksum_temp" && "$checksum" -ef "$checksum_temp" ]]; then
      rm -f -- "$checksum"
    fi
    if ((published_archive == 1)) && [[ -e "$archive" && -e "$archive_temp" && "$archive" -ef "$archive_temp" ]]; then
      rm -f -- "$archive"
    fi
  fi
  rm -rf -- "$stage"
  [[ -z "$archive_temp" ]] || rm -f -- "$archive_temp"
  [[ -z "$checksum_temp" ]] || rm -f -- "$checksum_temp"
  exit "$status"
}
trap toolkit_cleanup_package EXIT
git -C "$repo_root" archive --format=tar HEAD toolkit | tar -xf - -C "$stage"
[[ -d "$stage/toolkit" && -f "$stage/toolkit/VERSION" ]] || {
  printf 'committed toolkit source is incomplete\n' >&2
  exit 1
}
cat >"$stage/toolkit/MANIFEST" <<MANIFEST
VERSION=$version
BUNDLE_FORMAT_VERSION=1
TOOLKIT_HELPER_API_VERSION=1
HOST_CONFIG_SCHEMA_VERSION=1
STATUS_SCHEMA_VERSION=1
IMAGE_PROTECTION_SCHEMA_VERSION=1
BACKUP_RECOVERY_REFERENCE_SCHEMA_VERSION=1
SUPPORTED_OS=ubuntu-26.04
SUPPORTED_ARCHITECTURES=amd64
DOCKER_ENGINE_RANGE=not-applicable
DOCKER_COMPOSE_RANGE=not-applicable
PROXY_BUNDLE_VERSION=not-included
PLUGIN_PINS=none
IMAGE_PINS=none
SOURCE_COMMIT=$source_commit
MANIFEST

archive="$output_dir/toolkit-$version.tar.gz"
checksum="$archive.sha256"
[[ ! -e "$archive" && ! -L "$archive" && ! -e "$checksum" && ! -L "$checksum" ]] || {
  printf 'refusing to overwrite an existing versioned toolkit artifact\n' >&2
  exit 1
}
archive_temp="$(mktemp "$output_dir/.toolkit-$version.XXXXXXXX")"
checksum_temp="$(mktemp "$output_dir/.toolkit-$version-checksum.XXXXXXXX")"
tar --sort=name --mtime='@0' --owner=0 --group=0 --numeric-owner --mode='u+rwX,go+rX,go-w' -cf - -C "$stage" toolkit | gzip -n >"$archive_temp"
digest="$(sha256sum -- "$archive_temp" | awk '{print $1}')"
printf '%s  %s\n' "$digest" "$(basename -- "$archive")" >"$checksum_temp"
chmod 0644 "$archive_temp" "$checksum_temp"
ln -- "$archive_temp" "$archive" || {
  printf 'cannot publish toolkit archive without replacing an existing file\n' >&2
  exit 1
}
published_archive=1
ln -- "$checksum_temp" "$checksum" || {
  printf 'cannot publish toolkit checksum without replacing an existing file\n' >&2
  exit 1
}
published_checksum=1
published_archive=0
published_checksum=0
printf 'archive=%s\nchecksum=%s\nsource_commit=%s\n' "$archive" "$checksum" "$source_commit"
