#!/usr/bin/env bash

declare -gA TOOLKIT_MANIFEST=()

toolkit_manifest_parse() {
  local path="$1"
  local line line_number=0 key value
  local -a required=(VERSION BUNDLE_FORMAT_VERSION TOOLKIT_HELPER_API_VERSION HOST_CONFIG_SCHEMA_VERSION STATUS_SCHEMA_VERSION IMAGE_PROTECTION_SCHEMA_VERSION BACKUP_RECOVERY_REFERENCE_SCHEMA_VERSION SUPPORTED_OS SUPPORTED_ARCHITECTURES DOCKER_ENGINE_RANGE DOCKER_COMPOSE_RANGE PROXY_BUNDLE_VERSION PLUGIN_PINS IMAGE_PINS SOURCE_COMMIT)

  [[ -f "$path" && -r "$path" ]] || toolkit_die "release manifest is missing: $path"
  toolkit_file_check_utf8 "$path"
  TOOLKIT_MANIFEST=()
  while IFS= read -r line || [[ -n "$line" ]]; do
    ((line_number += 1))
    line="${line%$'\r'}"
    [[ -z "$line" ]] && continue
    [[ "$line" == *=* ]] || toolkit_die "release manifest line $line_number must be KEY=value"
    key="${line%%=*}"
    value="${line#*=}"
    [[ "$key" =~ ^[A-Z][A-Z0-9_]*$ && -n "$value" && "$value" != *[[:space:]]* ]] || toolkit_die "release manifest line $line_number is invalid"
    case "$key" in
    VERSION | BUNDLE_FORMAT_VERSION | TOOLKIT_HELPER_API_VERSION | HOST_CONFIG_SCHEMA_VERSION | STATUS_SCHEMA_VERSION | IMAGE_PROTECTION_SCHEMA_VERSION | BACKUP_RECOVERY_REFERENCE_SCHEMA_VERSION | SUPPORTED_OS | SUPPORTED_ARCHITECTURES | DOCKER_ENGINE_RANGE | DOCKER_COMPOSE_RANGE | PROXY_BUNDLE_VERSION | PLUGIN_PINS | IMAGE_PINS | SOURCE_COMMIT) ;;
    *) toolkit_die "release manifest has unknown key $key" ;;
    esac
    [[ -z "${TOOLKIT_MANIFEST[$key]+present}" ]] || toolkit_die "release manifest duplicates $key"
    TOOLKIT_MANIFEST["$key"]="$value"
  done <"$path"

  for key in "${required[@]}"; do
    [[ -n "${TOOLKIT_MANIFEST[$key]+present}" ]] || toolkit_die "release manifest is missing $key"
  done
  toolkit_validate_version "${TOOLKIT_MANIFEST[VERSION]}" || toolkit_die 'release VERSION must be semantic major.minor.patch'
  [[ "${TOOLKIT_MANIFEST[BUNDLE_FORMAT_VERSION]}" == 1 && "${TOOLKIT_MANIFEST[TOOLKIT_HELPER_API_VERSION]}" == 1 && "${TOOLKIT_MANIFEST[HOST_CONFIG_SCHEMA_VERSION]}" == 1 && "${TOOLKIT_MANIFEST[STATUS_SCHEMA_VERSION]}" == 1 && "${TOOLKIT_MANIFEST[IMAGE_PROTECTION_SCHEMA_VERSION]}" == 1 && "${TOOLKIT_MANIFEST[BACKUP_RECOVERY_REFERENCE_SCHEMA_VERSION]}" == 1 ]] || toolkit_die 'release contract versions are incompatible with this toolkit foundation'
  [[ "${TOOLKIT_MANIFEST[SUPPORTED_OS]}" == ubuntu-26.04 ]] || toolkit_die 'release manifest has an unsupported OS declaration'
  [[ "${TOOLKIT_MANIFEST[SUPPORTED_ARCHITECTURES]}" == amd64 ]] || toolkit_die 'release manifest has an unsupported architecture declaration'
  [[ "${TOOLKIT_MANIFEST[SOURCE_COMMIT]}" =~ ^[a-f0-9]{40,64}$ ]] || toolkit_die 'release SOURCE_COMMIT must be a Git object ID'
}

toolkit_check_archive() {
  local archive="$1"
  local checksum="$2"
  local expected actual lines listed line normalized segment
  local -A seen=()
  local -a segments=()
  local temp_dir

  [[ -f "$archive" && -r "$archive" ]] || toolkit_die "release archive is not readable: $archive"
  [[ -f "$checksum" && -r "$checksum" ]] || toolkit_die "release checksum is not readable: $checksum"
  mapfile -t lines <"$checksum"
  ((${#lines[@]} == 1)) || toolkit_die 'checksum file must contain exactly one line'
  read -r expected listed extra <<<"${lines[0]}"
  [[ "$expected" =~ ^[a-f0-9]{64}$ && -z "${extra:-}" ]] || toolkit_die 'checksum file must begin with one SHA-256 digest'
  if [[ -n "${listed:-}" && "$listed" != "$(basename -- "$archive")" ]]; then
    toolkit_die 'checksum filename does not match the archive basename'
  fi
  actual="$(sha256sum -- "$archive" | awk '{print $1}')" || toolkit_die 'cannot hash release archive'
  [[ "$actual" == "$expected" ]] || toolkit_die 'release archive SHA-256 mismatch'

  temp_dir="$(mktemp -d /tmp/toolkit-validation.XXXXXXXX)" || toolkit_die 'cannot create temporary release-validation directory'
  toolkit_register_temp_path "$temp_dir"
  if ! tar -tzf "$archive" --quoting-style=escape >"$temp_dir/names"; then
    rm -rf -- "$temp_dir"
    toolkit_die 'release archive is not a readable gzip tar archive'
  fi
  if ! tar -tvzf "$archive" --quoting-style=escape >"$temp_dir/details"; then
    rm -rf -- "$temp_dir"
    toolkit_die 'cannot inspect release archive entries'
  fi

  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ "$line" != *\\* ]] || {
      rm -rf -- "$temp_dir"
      toolkit_die 'release archive path contains an escaped or control character'
    }
    normalized="${line%/}"
    [[ "$normalized" =~ ^toolkit(/[A-Za-z0-9._-]+)*$ ]] || {
      rm -rf -- "$temp_dir"
      toolkit_die "release archive contains an unsafe path: $line"
    }
    IFS='/' read -r -a segments <<<"$normalized"
    for segment in "${segments[@]}"; do
      [[ "$segment" != . && "$segment" != .. ]] || {
        rm -rf -- "$temp_dir"
        toolkit_die "release archive contains a traversal path: $line"
      }
    done
    [[ -z "${seen[$normalized]+present}" ]] || {
      rm -rf -- "$temp_dir"
      toolkit_die "release archive contains a duplicate path: $line"
    }
    seen["$normalized"]=1
  done <"$temp_dir/names"

  while IFS= read -r line || [[ -n "$line" ]]; do
    case "${line:0:1}" in
    - | d) ;;
    *)
      rm -rf -- "$temp_dir"
      toolkit_die 'release archive may contain only regular files and directories'
      ;;
    esac
  done <"$temp_dir/details"
  rm -rf -- "$temp_dir"
  [[ -n "${seen[toolkit]+present}" && -n "${seen["toolkit/MANIFEST"]+present}" && -n "${seen["toolkit/VERSION"]+present}" && -n "${seen["toolkit/bin/toolkit"]+present}" ]] || toolkit_die 'release archive is missing required toolkit files'
}
