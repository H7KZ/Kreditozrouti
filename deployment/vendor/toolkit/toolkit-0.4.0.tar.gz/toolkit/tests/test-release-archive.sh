#!/usr/bin/env bash
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
temporary="$(mktemp -d)"
trap 'rm -rf -- "$temporary"' EXIT
mkdir -p "$temporary/source/toolkit/bin" "$temporary/valid" "$temporary/traversal" "$temporary/symlink"
cat >"$temporary/source/toolkit/VERSION" <<'VERSION'
0.1.0
VERSION
cat >"$temporary/source/toolkit/MANIFEST" <<'MANIFEST'
VERSION=0.1.0
BUNDLE_FORMAT_VERSION=1
TOOLKIT_HELPER_API_VERSION=1
HOST_CONFIG_SCHEMA_VERSION=1
STATUS_SCHEMA_VERSION=1
IMAGE_PROTECTION_SCHEMA_VERSION=1
BACKUP_RECOVERY_REFERENCE_SCHEMA_VERSION=1
SUPPORTED_OS=ubuntu-26.04
SUPPORTED_ARCHITECTURES=amd64
DOCKER_ENGINE_RANGE=not-applicable
DOCKER_COMPOSE_RANGE=not-applicable
PROXY_BUNDLE_VERSION=not-included
PLUGIN_PINS=none
IMAGE_PINS=none
SOURCE_COMMIT=0123456789012345678901234567890123456789
MANIFEST
printf '#!/usr/bin/env bash\nexit 0\n' >"$temporary/source/toolkit/bin/toolkit"

make_checksum() {
  local path="$1"
  (cd -- "$(dirname -- "$path")" && sha256sum "$(basename -- "$path")" >"$(basename -- "$path").sha256")
}

tar -czf "$temporary/valid/release.tar.gz" -C "$temporary/source" toolkit
make_checksum "$temporary/valid/release.tar.gz"
bash "$toolkit_root/bin/toolkit" verify-release --archive "$temporary/valid/release.tar.gz" --checksum "$temporary/valid/release.tar.gz.sha256" >/dev/null

tar -czf "$temporary/traversal/release.tar.gz" --transform='s|toolkit/bin/toolkit|../escape|' -C "$temporary/source" toolkit
make_checksum "$temporary/traversal/release.tar.gz"
if bash "$toolkit_root/bin/toolkit" verify-release --archive "$temporary/traversal/release.tar.gz" --checksum "$temporary/traversal/release.tar.gz.sha256" >/dev/null 2>&1; then
  printf 'expected path traversal archive to be rejected\n' >&2
  exit 1
fi

ln -s /tmp "$temporary/source/toolkit/link"
tar -czf "$temporary/symlink/release.tar.gz" -C "$temporary/source" toolkit
make_checksum "$temporary/symlink/release.tar.gz"
if bash "$toolkit_root/bin/toolkit" verify-release --archive "$temporary/symlink/release.tar.gz" --checksum "$temporary/symlink/release.tar.gz.sha256" >/dev/null 2>&1; then
  printf 'expected symlink archive entry to be rejected\n' >&2
  exit 1
fi

printf 'toolkit release archive checks passed\n'
