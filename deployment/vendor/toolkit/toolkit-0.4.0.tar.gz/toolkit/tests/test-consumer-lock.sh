#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)"
temporary="$(mktemp -d)"
trap 'rm -rf -- "$temporary"' EXIT
mkdir -p "$temporary/source/toolkit/bin" "$temporary/mismatch/toolkit" "$temporary/incomplete/toolkit"
mkdir -p "$temporary/version-mismatch/toolkit"

cat >"$temporary/source/toolkit/VERSION" <<'VERSION'
0.1.0
VERSION
printf '#!/usr/bin/env bash\nexit 0\n' >"$temporary/source/toolkit/bin/toolkit"
cat >"$temporary/source/toolkit/MANIFEST" <<'MANIFEST'
VERSION=0.1.0
BUNDLE_FORMAT_VERSION=1
TOOLKIT_HELPER_API_VERSION=1
HOST_CONFIG_SCHEMA_VERSION=1
STATUS_SCHEMA_VERSION=1
IMAGE_PROTECTION_SCHEMA_VERSION=1
BACKUP_RECOVERY_REFERENCE_SCHEMA_VERSION=1
SUPPORTED_OS=ubuntu-26.04
SUPPORTED_ARCHITECTURES=amd64
DOCKER_ENGINE_RANGE=not-applicable
DOCKER_COMPOSE_RANGE=not-applicable
PROXY_BUNDLE_VERSION=not-included
PLUGIN_PINS=none
IMAGE_PINS=none
SOURCE_COMMIT=0123456789012345678901234567890123456789
MANIFEST
tar -czf "$temporary/release.tar.gz" -C "$temporary/source" toolkit
archive_digest="$(sha256sum "$temporary/release.tar.gz" | awk '{print $1}')"
cat >"$temporary/toolkit.lock" <<LOCK
TOOLKIT_VERSION=0.1.0
TOOLKIT_SOURCE_COMMIT=0123456789012345678901234567890123456789
TOOLKIT_ARCHIVE_SHA256=$archive_digest
BUNDLE_FORMAT_VERSION=1
TOOLKIT_HELPER_API_VERSION=1
HOST_CONFIG_SCHEMA_VERSION=1
STATUS_SCHEMA_VERSION=1
IMAGE_PROTECTION_SCHEMA_VERSION=1
BACKUP_RECOVERY_REFERENCE_SCHEMA_VERSION=1
SUPPORTED_OS=ubuntu-26.04
SUPPORTED_ARCHITECTURES=amd64
DOCKER_ENGINE_RANGE=not-applicable
DOCKER_COMPOSE_RANGE=not-applicable
PROXY_BUNDLE_VERSION=not-included
PLUGIN_PINS=none
IMAGE_PINS=none
LOCK

bash "$repo_root/toolkit-fixture-consumer/validate-lock.sh" "$temporary/toolkit.lock" "$temporary/release.tar.gz"
wrong_digest="0${archive_digest:1}"
[[ "${archive_digest:0:1}" == 0 ]] && wrong_digest="1${archive_digest:1}"
sed "s/^TOOLKIT_ARCHIVE_SHA256=.*/TOOLKIT_ARCHIVE_SHA256=$wrong_digest/" "$temporary/toolkit.lock" >"$temporary/wrong-digest.lock"
if bash "$repo_root/toolkit-fixture-consumer/validate-lock.sh" "$temporary/wrong-digest.lock" "$temporary/release.tar.gz" >/dev/null 2>&1; then
  printf 'expected consumer archive digest mismatch to fail validation\n' >&2
  exit 1
fi

cp -R "$temporary/source/toolkit/." "$temporary/mismatch/toolkit/"
sed -i 's/^VERSION=0.1.0$/VERSION=0.1.1/' "$temporary/mismatch/toolkit/MANIFEST"
tar -czf "$temporary/mismatch.tar.gz" -C "$temporary/mismatch" toolkit
mismatch_digest="$(sha256sum "$temporary/mismatch.tar.gz" | awk '{print $1}')"
sed "s/^TOOLKIT_ARCHIVE_SHA256=.*/TOOLKIT_ARCHIVE_SHA256=$mismatch_digest/" "$temporary/toolkit.lock" >"$temporary/mismatch.lock"
if bash "$repo_root/toolkit-fixture-consumer/validate-lock.sh" "$temporary/mismatch.lock" "$temporary/mismatch.tar.gz" >/dev/null 2>&1; then
  printf 'expected archive manifest to be bound to its lock to fail when mismatched\n' >&2
  exit 1
fi

cp -R "$temporary/source/toolkit/." "$temporary/version-mismatch/toolkit/"
printf '0.1.1\n' >"$temporary/version-mismatch/toolkit/VERSION"
tar -czf "$temporary/version-mismatch.tar.gz" -C "$temporary/version-mismatch" toolkit
version_mismatch_digest="$(sha256sum "$temporary/version-mismatch.tar.gz" | awk '{print $1}')"
sed "s/^TOOLKIT_ARCHIVE_SHA256=.*/TOOLKIT_ARCHIVE_SHA256=$version_mismatch_digest/" "$temporary/toolkit.lock" >"$temporary/version-mismatch.lock"
if bash "$repo_root/toolkit-fixture-consumer/validate-lock.sh" "$temporary/version-mismatch.lock" "$temporary/version-mismatch.tar.gz" >/dev/null 2>&1; then
  printf 'expected toolkit VERSION to match the pinned release manifest\n' >&2
  exit 1
fi

tar -czf "$temporary/traversal.tar.gz" --transform='s|toolkit/bin/toolkit|toolkit/../escape|' -C "$temporary/source" toolkit
traversal_digest="$(sha256sum "$temporary/traversal.tar.gz" | awk '{print $1}')"
sed "s/^TOOLKIT_ARCHIVE_SHA256=.*/TOOLKIT_ARCHIVE_SHA256=$traversal_digest/" "$temporary/toolkit.lock" >"$temporary/traversal.lock"
if bash "$repo_root/toolkit-fixture-consumer/validate-lock.sh" "$temporary/traversal.lock" "$temporary/traversal.tar.gz" >/dev/null 2>&1; then
  printf 'expected consumer archive traversal path to be rejected\n' >&2
  exit 1
fi

cp "$temporary/source/toolkit/MANIFEST" "$temporary/incomplete/toolkit/MANIFEST"
tar -czf "$temporary/incomplete.tar.gz" -C "$temporary/incomplete" toolkit
incomplete_digest="$(sha256sum "$temporary/incomplete.tar.gz" | awk '{print $1}')"
sed "s/^TOOLKIT_ARCHIVE_SHA256=.*/TOOLKIT_ARCHIVE_SHA256=$incomplete_digest/" "$temporary/toolkit.lock" >"$temporary/incomplete.lock"
if bash "$repo_root/toolkit-fixture-consumer/validate-lock.sh" "$temporary/incomplete.lock" "$temporary/incomplete.tar.gz" >/dev/null 2>&1; then
  printf 'expected incomplete toolkit bundle to be rejected\n' >&2
  exit 1
fi

printf 'toolkit consumer lock checks passed\n'
