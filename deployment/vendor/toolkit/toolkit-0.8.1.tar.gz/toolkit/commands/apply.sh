#!/usr/bin/env bash

toolkit_apply_module_locked() {
  case "$1" in
  swap) toolkit_swap_apply / "${TOOLKIT_CONFIG[SWAP_SIZE_GB]}" ;;
  docker-logs) toolkit_docker_logging_apply / ;;
  *) toolkit_die "unsupported apply module: $1" ;;
  esac
}

toolkit_apply() {
  local config='' module=''
  while (($#)); do
    case "$1" in
    --config)
      (($# >= 2)) || toolkit_die '--config requires a path'
      [[ -z "$config" ]] || toolkit_die '--config may be specified only once'
      config="$2"
      shift 2
      ;;
    --module)
      (($# >= 2)) || toolkit_die '--module requires a value'
      [[ -z "$module" ]] || toolkit_die '--module may be specified only once'
      module="$2"
      shift 2
      ;;
    *) toolkit_die "unknown apply option: $1" ;;
    esac
  done
  [[ -n "$config" && -n "$module" ]] || toolkit_die 'apply requires --config <path> and --module <name>'
  [[ "$module" == swap || "$module" == docker-logs ]] || toolkit_die "unsupported apply module: $module (available: swap, docker-logs)"
  toolkit_config_parse "$config"
  toolkit_require_root
  toolkit_assert_supported_platform
  [[ -d /run/systemd/system ]] || toolkit_die 'apply requires a running systemd host'
  command -v systemctl >/dev/null 2>&1 || toolkit_die 'apply requires systemctl'
  toolkit_with_locks --host-window \
    --repository infrastructure \
    --environment infrastructure \
    --action toolkit \
    --release-id "$TOOLKIT_VERSION" \
    -- toolkit_apply_module_locked "$module"
}
