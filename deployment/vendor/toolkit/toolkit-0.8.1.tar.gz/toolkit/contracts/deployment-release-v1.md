# Compose deployment release v1

Toolkit 0.8.1. One implementation serves application, monitoring and Infrastructure projects.
Deployments stay manual and owner initiated in production. A commit or a directory is not evidence
that it has been deployed or that recovery has been rehearsed.

## Commands

```bash
sudo toolkit release deploy --repository ohlidame --environment production \
  --root "$HOME/ohlidame/versions/production" --user "$(id -un)" \
  --archive "$incoming/source.tar.gz" --checksum "$incoming/source.tar.gz.sha256" \
  --manifest "$incoming/release.json" --env-file "$incoming/runtime.env" \
  --registry-config "$incoming/docker-config"
sudo toolkit release rollback --repository ohlidame --environment production \
  --root "$HOME/ohlidame/versions/production" --user "$(id -un)" --release-id previous
sudo toolkit reconcile --repository ohlidame --environment production \
  --root "$HOME/ohlidame/versions/production" --user "$(id -un)"
```

`stage` takes the same arguments as `deploy` and publishes a verified snapshot without applying it.
`activate` takes the same arguments as `rollback` and requires an explicit saved release ID.
For private images, rollback also needs a fresh isolated `--registry-config` directory. Create it
with `umask 077`, log in once for this operation, and delete only that operation's credentials after
the synchronous command completes. Never log out another job's global Docker config.

The release root must be an absolute path below the named non-root user's home. Source archive
entries must be regular files/directories, with safe relative paths and no duplicates, symlinks,
`.env`, `.rendered`, `.secrets` or toolkit snapshot metadata. SHA-256 is checked before extraction.
IDs are never overwritten; rerun with a fresh workflow attempt or select an existing snapshot.

## Manifest input

```json
{
  "schema_version": 1,
  "repository": "ohlidame",
  "environment": "production",
  "release_id": "0123456789012345678901234567890123456789-1234-1",
  "source_commit": "0123456789012345678901234567890123456789",
  "project": "ohlidame",
  "compose_files": ["production/networks.yml", "production/volumes.yml", "production/docker-compose.production.yml"],
  "images": {"api": "ghcr.io/h7kz/ohlidame/api@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"},
  "environment_variables": {"IMAGE_REGISTRY": "ghcr.io", "IMAGE_PREFIX": "h7kz/ohlidame"},
  "health_urls": ["https://ohlidame.cz/api/health"]
}
```

Application consumers provide their complete selected digest set and validate promotion evidence
before calling the host. Third-party images in Compose are pulled and resolved to repository digests
when staged; the retained resolved model pins every service, including inactive profiles. The source
commit identifies source, not data/schema compatibility. Production promotion must not rebuild images.

Optional `qualification` retains the exact validated development manifest for backup/recovery evidence.
Optional `runtime_directories` lists generated secret/config directories to link into private runtime
storage. `prepare_script` runs as the deploy user with dotenv exported before Compose config, and may
write derived literal dotenv values to `$TOOLKIT_RUNTIME_DIR/extra.env`. `post_deploy_script` runs after
Compose health and before pointer publication; it must not change the frozen runtime files. Both hooks
are synchronous, archive-relative paths, reviewed as deployment code. They may not start detached work.

## Apply, failure and rollback

The repository-wide lock is held throughout. Archive, prepare and image downloads precede the host
capacity window. Under host lock, missing owned external volumes/networks are created; shared
`public-network` must already exist unless Infrastructure is creating it. Existing data services
are never automatically recreated. A differing data image fails and needs an explicit data upgrade.
Other active services use `up --no-deps --pull never --no-build --wait` as one complete set. No orphan
removal, host prune or release deletion occurs. Public HTTPS health needs three consecutive successes.

Failed subprocess output is retained only in root-private `.operation-logs/` files. Actions/journal
messages contain the diagnostic path and exit status, not captured credentials or rendered config.

Only then does `previous` record the former `current`, and an atomic symlink replacement publishes
`current`. The two pointer writes are not a filesystem transaction; a crash between them can leave
`previous` equal to `current`. A failed Compose apply can change some containers while `current` still
names the last healthy snapshot. Inspect before retrying or explicitly roll back; no automatic database
rollback is attempted. Immutable snapshots retain source inventory, image digests and hashes of all
private runtime files. Tampering fails before apply/reconcile.

Resolved Compose JSON and literal dotenv are in `.runtime/<id>/`, outside the read-only source tree.
Keep them and the referenced registry images while any active release or retained backup needs them.
Snapshots contain secrets; copying/backup of private runtime must be encrypted. No cleanup assumes age
alone proves that a release or image is disposable.

## Boot and installation

`toolkit reconcile` verifies `current`, then runs `up -d --no-recreate --pull never --no-build` under
repository then host lock. Missing `current` is skipped. Corrupt/legacy pointers fail visibly; migrate
by staging a new snapshot before enabling reconcile. Removed containers can be created from cached
images. Existing containers are never recreated. Intentionally stopped declared services start again;
remove them from the deployment configuration and stage a new snapshot to keep them down.

One optional systemd template ships in `packaging/toolkit-reconcile.service.in` (install it as `toolkit-reconcile@.service`). An owner installs the
template and root-owned JSON registrations at `/etc/toolkit/reconcile/<target>.json`:

```json
{"repository":"ohlidame","environment":"production","root":"/home/deploy/ohlidame/versions/production","user":"deploy"}
```

Enable each `toolkit-reconcile@<target>.service` only after its current snapshot exists and a manual
reconcile succeeds. Retire legacy/global boot units first; never leave a starts-all-containers unit
enabled beside snapshot reconcile. No code deployment enables units, timers or rotates credentials.
Upgrade host toolkit and all consumer pins together: 0.8.1 uses `repository.lock`, while older releases
used separate environment locks. Mixing versions breaks coordination.

## Upstream references

Compose recreation, dependency and wait semantics: [docker compose up](https://docs.docker.com/reference/cli/docker/compose/up/).
Compose config serialization already escapes literal dollars for re-reading (do not escape twice):
[Compose interpolation](https://docs.docker.com/reference/compose-file/interpolation/).
Thin local reusable workflows retain per-repo environment scoping; public repositories cannot call
private reusable workflows: [GitHub reusable workflows](https://docs.github.com/en/actions/reference/workflows-and-actions/reusing-workflow-configurations).
