# Cross-repository handoff contract v1

Status: frozen implementation contract, 2026-10-10. Source of truth: Infrastructure's
`toolkit/contracts/` directory. Consumer repositories pin a reviewed bundle and may not update the
host's `/opt/toolkit/current` as a side effect.

## Versions

| Contract | v1 value |
| --- | --- |
| Bundle format | `1` |
| Toolkit helper API | `1` |
| Host config schema | `1` |
| Operation status schema | `1` |
| Image protection manifest schema | `1` |
| Backup recovery reference schema | `1` |
| Hosted backup maintenance catalog and snapshot inventory schemas | `1` |
| Qualified development release manifest schema | `1` |

Toolkit releases use semantic versions. The source release manifest carries the exact Git commit,
config/helper versions, Ubuntu version and supported architectures.

## Locks

- Repository lock: `/run/lock/toolkit/repos/<repository>/repository.lock`. All environments,
  monitoring, retention, reconcile and backup capture share it since toolkit 0.8.1. Environment
  remains operation metadata. Old `<environment>.lock` files are no longer used.
- Host capacity/mutation lock: `/run/lock/toolkit/host.lock`.
- Exclusive `flock`; repository first, then host. Never acquire a repository lock while holding host.
  A backup waiting/running in one repository cannot hold the host lock or block other repositories.
- `with-lock --repository <id> --environment <env>` takes only the repository lock. Add
  `--host-window` for host mutations. With no repository, `with-lock` takes the host lock.
- `release deploy|activate|rollback` holds the repository lock throughout staging, pull, mutation,
  health and pointer publication; the controller takes host only for Compose changes and health.
- `reconcile` holds repository then host while applying the exact current snapshot without pulls,
  builds or recreation. Each target has its own operation record and uses the same repo lock.
- Backup takes only repository (wait at most 1800 seconds); it releases after capture. Off-site
  transfer requires neither VPS lock. Monitoring and production captures cannot race retention.
- Host-wide maintenance uses `with-lock --all-repositories --host-window`: registered repository
  locks in sorted order, then host. Registration includes existing lock directories, durable
  operation directories, and `/etc/toolkit/backup/<repo>.env` configs (so reboot does not erase it). This also excludes backup capture in the other repositories.
  Register a new repository (its first toolkit operation creates its lock directory) before enabling
  its backup timer. Never nest all-repository locking inside a repository/host lock.
- `install`/`activate` for the toolkit and host `apply` take infrastructure repository then host.
- Default wait for `with-lock` is 300 seconds, accepted range 1-3600. Release operations wait 1800
  seconds for repository and host independently. Timeout fails; locks are never stolen by PID/age.
- Commands must remain synchronous within their wrapper. SSH/Actions cancellation is not rollback;
  a failed apply can leave some containers changed while `current` remains the last healthy release.
- Upgrade all pins and host toolkit together. Do not run old and new lock protocols concurrently.

The deploy identity remains root-equivalent through Docker and permitted toolkit commands.

## Operation outcome

Mutating provisioning, deployment, proxy, backup, cleanup and maintenance operations publish a JSON
status record with `schema_version`, `operation_id`, `repository`,
`environment`, `action`, `state`, `started_at`, `finished_at`, `toolkit_version`, and optional
`release_id` and `failure_phase`. `state` is `running`, `succeeded`, `failed`, or `interrupted`;
timestamps are UTC RFC 3339. Updates are atomic replacements. Status records contain no credentials
or secret values. Deployment and backup records may add namespaced fields, but cannot redefine these
fields or states. The toolkit publishes root-only records under
`/var/lib/toolkit/operations/<repository>/<environment>/<operation-id>.json`. The `operation start`
and `operation finish` commands write individual records; `with-lock --action` also records the
operation around lock acquisition and command execution. A process interrupted before it can publish
its terminal update leaves a `running` record for the operator or hosted maintainer to reconcile.
Toolkit install and activation use action `toolkit`.

## Shared proxy identities

The Infrastructure Traefik stack is the active proxy owner on the shared VPS. Its Compose project is
`global`. These external Docker network names are stable contract values:

- `public-network` - app-facing proxy network used by all three repositories.
- `traefik-socket-proxy-network` - Traefik to socket-proxy only.
- `traefik-crowdsec-network` - Traefik to CrowdSec only.
- `infrastructure-monitoring-network` - Infrastructure-owned monitoring access.

The app-facing middleware names are also stable. Global entrypoint chain, in order:
`crowdsec@file`, `www-redirect@file`, `rate-limit@file`, `security-headers@file`, `compress@file`.
Optional file-provider names: `admin-rate-limit@file`, `auth-rate-limit@file`, `in-flight-req@file`,
`retry@file`, `cloudflare-only@file`, `deny-all@file`, `secure-chain@file`,
`auth-endpoint-chain@file`, `admin-chain@file`. Docker-provider names such as the Traefik dashboard
allowlist/auth and app-local buffering middleware are not shared names.

Do not rename a shared network or middleware without a contract version change and an explicit
migration plan. On the current VPS, Infrastructure alone installs or changes the active proxy.

## Backup ownership inventory

`backup-recovery-inventory-v1.md` is the static source-to-owner and recovery-dependency map. It is
versioned with this toolkit bundle. It reflects repository configuration and capture adapters, not a
live production inventory; verify it read-only against Docker before enabling capture timers or
maintenance.

## Image protection and backup recovery references

`image-protection-v1.schema.json` is a data-only local host manifest. It identifies each repository,
environment, current/rollback/candidate release, the exact digest in its registry reference and the
local Docker image ID.
Only Docker image IDs are eligible for local cleanup. Missing, malformed or stale protection data
causes a safe skip; it never broadens deletion. Local cache cleanup does not delete registry content.

`backup-recovery-reference-v1.schema.json` is published by hosted backup maintenance only after a
complete set is accepted; `restore_validated` and `last_good` are assigned by that trusted maintainer,
not asserted by the VPS writer. A reference records the Kopia snapshot and manifest checksum plus the
release/config/toolkit/proxy/image dependencies needed to restore it. Preserve every digest/bundle
referenced by an unexpired or last-good recovery set. Last-good references remain protected past the
ten-day logical window while capture or restore verification is unhealthy.

`backup-maintenance-catalog-v1.schema.json` and `backup-snapshot-inventory-v1.schema.json` define
the inputs to Infrastructure's offline expiration planner. The planner freezes expiration on stale
health evidence, incomplete recovery dependencies, or any catalog/inventory mismatch. It does not
authenticate inputs or execute Kopia/B2 mutations; hosted publication, credentials, monitoring, and
disposable proof remain separate gates. Maintenance inputs accept only the `production` environment
for all three repository identities, including Infrastructure; the repository field identifies the
owner. The trusted publisher owns atomic rotation of exactly one `last_good` reference per bucket
after restore validation. `backup-validation-evidence-v1.schema.json` binds a restore result to the
exact repository, environment, snapshot, backup set, manifest hash, and validation time. The offline
catalog candidate builder checks those fields and emits an expected prior-catalog hash for future
compare-and-swap publication. The evidence remains an assertion until a trusted hosted validator
authenticates its provenance; `validator_id` and hashes alone are not proof.

`development-release-manifest-v1.schema.json` describes the immutable GitHub Actions artifact emitted
only after the complete production-capable development image set deploys and passes Compose health
checks. It binds every required service digest to the source commit, workflow path, run ID and run attempt. Production
promotion validates the originating successful development run, then deploys selected services from
that complete set by digest. Ohlidame's development-only Test shop is excluded. The artifact is a
qualification handoff, not a long-term release catalog; backup recovery references retain dependencies
beyond the artifact retention window.

Remote registry retention consumes the union of deployment rollback references and trusted backup
recovery references. Missing or unreadable reference input disables remote deletion. It is independent
of local Docker image cleanup. No registry deletion implementation is enabled by this contract alone.
