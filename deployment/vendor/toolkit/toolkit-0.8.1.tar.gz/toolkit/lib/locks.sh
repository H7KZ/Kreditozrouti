#!/usr/bin/env bash
# shellcheck disable=SC2034 # TOOLKIT_ACTIVE_OPERATION_* are read by operations.sh

toolkit_with_locks() {
  local repository='' environment='' action='' operation_id='' release_id='' timeout=300 host_window=0 all_repositories=0 command_started=0 host_path project_dir project_path host_fd project_fd status
  local -a repositories=() project_fds=()
  while (($#)); do
    case "$1" in
    --all-repositories)
      all_repositories=1
      host_window=1
      shift
      ;;
    --host-window)
      host_window=1
      shift
      ;;
    --repository)
      (($# >= 2)) || toolkit_die '--repository requires a value'
      repository="$2"
      shift 2
      ;;
    --environment)
      (($# >= 2)) || toolkit_die '--environment requires a value'
      environment="$2"
      shift 2
      ;;
    --timeout)
      (($# >= 2)) || toolkit_die '--timeout requires a value'
      timeout="$2"
      shift 2
      ;;
    --action)
      (($# >= 2)) || toolkit_die '--action requires a value'
      action="$2"
      shift 2
      ;;
    --operation-id)
      (($# >= 2)) || toolkit_die '--operation-id requires a value'
      operation_id="$2"
      shift 2
      ;;
    --release-id)
      (($# >= 2)) || toolkit_die '--release-id requires a value'
      release_id="$2"
      shift 2
      ;;
    --)
      shift
      command_started=1
      break
      ;;
    *) toolkit_die "unknown with-lock option: $1" ;;
    esac
  done

  ((command_started == 1 && $# > 0)) || toolkit_die 'with-lock requires -- COMMAND [ARG ...]'
  toolkit_require_root
  if [[ ! "$timeout" =~ ^[1-9][0-9]{0,3}$ ]] || ((timeout > 3600)); then toolkit_die '--timeout must be an integer from 1 through 3600 seconds'; fi
  if ((all_repositories == 1)); then
    repository="${repository:-infrastructure}"
    environment="${environment:-infrastructure}"
  fi
  if [[ -n "$repository" || -n "$environment" ]]; then
    toolkit_validate_slug "$repository" || toolkit_die '--repository must be a lowercase slug'
    toolkit_validate_slug "$environment" || toolkit_die '--environment must be a lowercase slug'
  fi
  if [[ -n "$action" ]]; then
    [[ -n "$repository" && -n "$environment" ]] || toolkit_die '--action requires repository and environment locks'
    local start_output
    local -a start_args=(--repository "$repository" --environment "$environment" --action "$action")
    [[ -z "$operation_id" ]] || start_args+=(--operation-id "$operation_id")
    [[ -z "$release_id" ]] || start_args+=(--release-id "$release_id")
    start_output="$(toolkit_operation_start "${start_args[@]}")"
    TOOLKIT_ACTIVE_OPERATION_ID="${start_output#operation_id=}"
    TOOLKIT_ACTIVE_OPERATION_REPOSITORY="$repository"
    TOOLKIT_ACTIVE_OPERATION_ENVIRONMENT="$environment"
    TOOLKIT_ACTIVE_OPERATION_STATE=running
    TOOLKIT_ACTIVE_OPERATION_FAILURE_PHASE=preflight
    toolkit_log info "operation_started operation_id=$TOOLKIT_ACTIVE_OPERATION_ID action=$action repository=$repository environment=$environment"
  elif [[ -n "$operation_id" || -n "$release_id" ]]; then
    toolkit_die '--operation-id and --release-id require --action'
  fi
  toolkit_assert_supported_platform
  command -v flock >/dev/null 2>&1 || toolkit_die 'flock is required for lock coordination'

  host_path='/run/lock/toolkit/host.lock'
  TOOLKIT_ACTIVE_OPERATION_FAILURE_PHASE=lock
  [[ ! -L /run/lock/toolkit && ! -L "$host_path" ]] || toolkit_die 'toolkit lock path must not be a symlink'
  install -d -o root -g root -m 0755 /run/lock/toolkit || toolkit_die 'cannot prepare toolkit lock directory'

  # Repository/environment lock first, host lock second. Waiting for a busy repository (for example
  # a running backup) must not hold the host lock, or one repository's backup would stall every other
  # repository's deploys. Backup capture takes only the repository lock, so this order cannot deadlock.
  if [[ -n "$repository" ]]; then
    [[ ! -L /run/lock/toolkit/repos ]] || toolkit_die 'repository lock root must not be a symlink'
    install -d -o root -g root -m 0755 /run/lock/toolkit/repos "/run/lock/toolkit/repos/$repository" || toolkit_die 'cannot prepare repository lock root'
    repositories=("$repository")
    if ((all_repositories == 1)); then
      mapfile -t repositories < <(
        {
          find /run/lock/toolkit/repos -mindepth 1 -maxdepth 1 -type d -printf '%f\n'
          local registered
          for registered in /var/lib/toolkit/operations/*; do
            [[ -d "$registered" && ! -L "$registered" ]] && basename -- "$registered"
          done
          for registered in /etc/toolkit/backup/*.env; do
            [[ -f "$registered" && ! -L "$registered" ]] && basename -- "$registered" .env
          done
        } | LC_ALL=C sort -u
      )
    fi
    local locked_repository
    for locked_repository in "${repositories[@]}"; do
      toolkit_validate_slug "$locked_repository" || toolkit_die 'invalid registered repository lock directory'
      project_dir="/run/lock/toolkit/repos/$locked_repository"
      project_path="$project_dir/repository.lock"
      [[ ! -L "$project_dir" && ! -L "$project_path" ]] || toolkit_die 'repository lock path must not be a symlink'
      install -d -o root -g root -m 0755 "$project_dir" || toolkit_die 'cannot prepare repository lock directory'
      : >>"$project_path" || toolkit_die 'cannot open repository lock'
      chmod 0644 "$project_path" || toolkit_die 'cannot set repository lock permissions'
      exec {project_fd}>>"$project_path" || toolkit_die 'cannot open repository lock'
      project_fds+=("$project_fd")
      toolkit_log info "waiting for repository lock repository=$locked_repository timeout_seconds=$timeout"
      flock -x -w "$timeout" "$project_fd" || toolkit_die "timed out waiting for repository lock: $project_path"
      toolkit_log info "acquired repository lock repository=$locked_repository"
    done
  fi

  if ((host_window == 1)) || [[ -z "$repository" ]]; then
    : >>"$host_path" || toolkit_die 'cannot open shared host lock'
    chmod 0644 "$host_path" || toolkit_die 'cannot set shared host lock permissions'
    exec {host_fd}>>"$host_path" || toolkit_die 'cannot open shared host lock'
    toolkit_log info "waiting for host lock timeout_seconds=$timeout"
    if ! flock -x -w "$timeout" "$host_fd"; then
      exec {host_fd}>&-
      toolkit_die "timed out waiting for host lock: $host_path"
    fi
    toolkit_log info "acquired host lock path=$host_path"
  fi

  TOOLKIT_ACTIVE_OPERATION_FAILURE_PHASE='command'
  "$@"
  status=$?
  if ((host_window == 1)) || [[ -z "$repository" ]]; then
    flock -u "$host_fd"
    exec {host_fd}>&-
  fi
  for project_fd in "${project_fds[@]}"; do
    flock -u "$project_fd"
    exec {project_fd}>&-
  done
  return "$status"
}
