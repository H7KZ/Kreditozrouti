#!/usr/bin/env python3
"""Immutable Compose snapshots; called under the toolkit repository lock."""

from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import pwd
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.request


SLUG = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*")
IDENTITY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
DIGEST = re.compile(r"[^\s]+@sha256:[a-f0-9]{64}")
RESERVED = {".toolkit-release.json", "compose.resolved.json", ".toolkit-inventory.json"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def log(message):
    print(f"toolkit deployment: {message}", flush=True)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, data, mode=0o600):
    with path.open("x", encoding="utf-8") as stream:
        os.chmod(path, mode)
        json.dump(data, stream, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def relative(value):
    require(isinstance(value, str) and value and "\\" not in value, "invalid relative path")
    path = PurePosixPath(value)
    require(not path.is_absolute() and all(p not in {".", ".."} for p in value.split("/")), "unsafe relative path")
    require(not any(ord(c) < 32 for c in value), "control character in path")
    return Path(value)


def no_symlink(path):
    require(path.is_absolute(), "paths must be absolute")
    for part in [path, *path.parents]:
        require(not part.is_symlink(), "unexpected symlink in operation path")


def dotenv(path):
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        key, separator, value = line.partition("=")
        require(separator and re.fullmatch(r"[A-Z][A-Z0-9_]*", key), "invalid dotenv key")
        require(key not in values and key not in {"PATH", "HOME", "DOCKER_CONFIG", "LD_PRELOAD", "BASH_ENV", "ENV"}, "unsafe or duplicate dotenv key")
        if value.startswith("'") and value.endswith("'"):
            value = value[1:-1].replace("\\'", "'")
        else:
            require(not any(c in value for c in "$`\"'\r\n"), "dotenv values must be literal; use single quotes")
        values[key] = value
    return values


def run(arguments, env, cwd=None):
    result = subprocess.run(arguments, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=1200)
    # Compose configuration and script output may contain credentials. Keep failures
    # visible without echoing raw stdout/stderr into Actions logs or the journal.
    if result.returncode != 0:
        diagnostic = "inspect privately on host"
        if env.get("TOOLKIT_DIAGNOSTIC_DIR"):
            directory = Path(env["TOOLKIT_DIAGNOSTIC_DIR"])
            descriptor, filename = tempfile.mkstemp(prefix="failure-", suffix=".log", dir=directory)
            with os.fdopen(descriptor, "w", encoding="utf-8") as output:
                output.write(result.stdout)
                output.write(result.stderr)
            diagnostic = f"private diagnostic: {filename}"
        raise ValueError(f"{Path(arguments[0]).name} failed (exit {result.returncode}); {diagnostic}")
    return result.stdout


@contextlib.contextmanager
def host_window():
    path = Path("/run/lock/toolkit/host.lock")
    no_symlink(path)
    descriptor = os.open(path, os.O_CREAT | os.O_WRONLY, 0o644)
    started = time.monotonic()
    try:
        while True:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                require(time.monotonic() - started < 1800, "host capacity lock timed out")
                time.sleep(1)
        log("host capacity lock acquired")
        yield
    finally:
        os.close(descriptor)


def validate_manifest(document, args):
    require(isinstance(document, dict) and document.get("schema_version") == 1, "unsupported release manifest")
    require(document.get("repository") == args.repository and document.get("environment") == args.environment, "release identity mismatch")
    require(bool(IDENTITY.fullmatch(document.get("release_id", ""))), "invalid release ID")
    require(document["release_id"] not in {"current", "previous"} and not document["release_id"].startswith("."), "reserved release ID")
    require(bool(re.fullmatch(r"[a-f0-9]{40,64}", document.get("source_commit", ""))), "source commit must be exact")
    require(bool(IDENTITY.fullmatch(document.get("project", ""))), "invalid Compose project")
    files = document.get("compose_files")
    require(isinstance(files, list) and files, "compose_files required")
    for path in files:
        relative(path)
    for key, value in document.get("images", {}).items():
        require(bool(SLUG.fullmatch(key)) and bool(DIGEST.fullmatch(value)), "application images require exact digests")
    for key, value in document.get("environment_variables", {}).items():
        require(bool(re.fullmatch(r"[A-Z][A-Z0-9_]*", key)) and key not in {"PATH", "HOME", "DOCKER_CONFIG", "LD_PRELOAD", "BASH_ENV", "ENV"}, "unsafe manifest environment key")
        require(isinstance(value, str) and "\n" not in value and "\r" not in value, "invalid manifest environment value")
    for url in document.get("health_urls", []):
        require(isinstance(url, str) and url.startswith("https://") and "@" not in url, "public health URL must use HTTPS without credentials")
    for field in ("prepare_script", "post_deploy_script"):
        if document.get(field):
            relative(document[field])
    for path in document.get("runtime_directories", []):
        relative(path)


def extract(archive, checksum, destination):
    no_symlink(archive)
    no_symlink(checksum)
    parts = checksum.read_text(encoding="utf-8").split()
    require(1 <= len(parts) <= 2 and bool(re.fullmatch(r"[a-f0-9]{64}", parts[0])), "invalid archive checksum")
    require(len(parts) == 1 or parts[1].lstrip("*") == archive.name, "checksum archive name mismatch")
    require(digest(archive) == parts[0], "archive checksum mismatch")
    with tarfile.open(archive, "r:gz") as stream:
        members = stream.getmembers()
        require(sum(m.size for m in members) <= 1024**3, "release archive exceeds 1 GiB")
        seen = set()
        for member in members:
            name = member.name.rstrip("/")
            if name in {".", ""} and member.isdir():
                continue
            while name.startswith("./"):
                name = name[2:]
            path = relative(name)
            require(name not in seen and (member.isfile() or member.isdir()), "duplicate path or unsupported archive entry")
            require(not any(part in {".env", ".secrets", ".rendered"} for part in path.parts) and path.name not in RESERVED, "archive contains runtime or reserved content")
            seen.add(name)
            target = destination / path
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with stream.extractfile(member) as source, target.open("xb") as output:
                    shutil.copyfileobj(source, output)
                target.chmod(0o755 if member.mode & 0o111 else 0o644)
    return parts[0]


def inventory(release, skip_inventory=True):
    records = {}
    for path in sorted(release.rglob("*")):
        name = path.relative_to(release).as_posix()
        if skip_inventory and path.name == ".toolkit-inventory.json":
            continue
        if path.is_symlink():
            records[name] = {"link": os.readlink(path)}
        elif path.is_file():
            records[name] = {"sha256": digest(path)}
    return records


def script(document, field, release, runtime, env, user):
    if document.get(field):
        path = release / relative(document[field])
        require(path.is_file() and not path.is_symlink(), "release hook missing or unsafe")
        child = dict(env, TOOLKIT_RUNTIME_DIR=str(runtime), TOOLKIT_ENV_FILE=str(runtime / ".env"))
        # Hooks run without the controller's root privileges. Their subprocesses
        # are synchronous and remain inside the current operation's lock lifetime.
        command = ["runuser", "-u", user, "--preserve-environment", "--", "bash", str(path)]
        run(command, child, release)


def compose(document, release):
    return ["docker", "compose", "--project-directory", str(release), "-p", document["project"], "-f", str(release / "compose.resolved.json")]


def ensure_resources(config, repository, env):
    for item in config.get("networks", {}).values():
        if not item.get("external"):
            continue
        name = item["name"]
        exists = subprocess.run(["docker", "network", "inspect", name], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
        if exists and item.get("x-toolkit-internal"):
            require(run(["docker", "network", "inspect", "--format", "{{.Internal}}", name], env).strip() == "true", "existing private network is not internal; migrate it explicitly")
        if not exists:
            require(name.startswith(repository + "-") or repository == "infrastructure", "shared external network missing; provision its owner first")
            run(["docker", "network", "create", *(["--internal"] if item.get("x-toolkit-internal") else []), name], env)
    for item in config.get("volumes", {}).values():
        if item.get("external"):
            name = item["name"]
            exists = subprocess.run(["docker", "volume", "inspect", name], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
            if not exists:
                require(name.startswith(repository + "-") or repository == "infrastructure", "external volume not owned by repository")
                run(["docker", "volume", "create", name], env)


def pin_images(config, document, env):
    services = config["services"]
    require(set(document.get("images", {})).issubset(services), "manifest image service absent from Compose")
    for name, item in services.items():
        require("build" not in item and isinstance(item.get("image"), str), "production snapshots require prebuilt images")
        reference = document.get("images", {}).get(name, item["image"])
        run(["docker", "pull", reference], env)
        if not DIGEST.fullmatch(reference):
            observed = json.loads(run(["docker", "image", "inspect", "--format", "{{json .RepoDigests}}", reference], env))
            repository = reference.rsplit(":", 1)[0] if ":" in reference.rsplit("/", 1)[-1] else reference
            def normalized(value):
                value = value.removeprefix("docker.io/")
                return value.removeprefix("library/")
            matches = [value for value in observed or [] if normalized(value.split("@")[0]) == normalized(repository)]
            require(len(matches) == 1, "cannot uniquely resolve image repository digest")
            reference = matches[0]
        require(bool(DIGEST.fullmatch(reference)), "resolved image digest invalid")
        item["image"] = reference
    return {name: item["image"] for name, item in services.items()}


def stage(args, account, env):
    document = json.loads(args.manifest.read_text(encoding="utf-8"))
    validate_manifest(document, args)
    release = args.root / document["release_id"]
    runtime = args.root / ".runtime" / document["release_id"]
    no_symlink(runtime)
    require(not release.exists() and not release.is_symlink() and not runtime.exists(), "release ID already exists; use activate or a new attempt")
    staging = Path(tempfile.mkdtemp(prefix=".incoming-", dir=args.root))
    try:
        archive_hash = extract(args.archive, args.checksum, staging)
        # Publish to its final path before resolving bind mounts: Compose must never
        # retain a staging pathname in container labels or volume source paths.
        staging.rename(release)
        runtime.mkdir(parents=True, mode=0o700)
        runtime.parent.chmod(0o700)
        os.chown(runtime.parent, account.pw_uid, account.pw_gid)
        shutil.copyfile(args.env_file, runtime / ".env")
        (runtime / ".env").chmod(0o600)
        env.update(dotenv(runtime / ".env"))
        env.update(document.get("environment_variables", {}))
        for parent in {release, *[(release / relative(p)).parent for p in document["compose_files"]]}:
            require(parent.is_dir(), "Compose parent missing from archive")
            (parent / ".env").symlink_to(runtime / ".env")
        for name in document.get("runtime_directories", []):
            target = release / relative(name)
            require(not target.exists(), "runtime directory must be omitted from source archive")
            private = runtime / relative(name)
            private.mkdir(parents=True, mode=0o700)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.symlink_to(private, target_is_directory=True)
        for tree in (release, runtime):
            for path in [tree, *tree.rglob("*")]:
                os.lchown(path, account.pw_uid, account.pw_gid)
        script(document, "prepare_script", release, runtime, env, args.user)
        if (runtime / "extra.env").exists():
            env.update(dotenv(runtime / "extra.env"))
        command = ["docker", "compose", "--project-directory", str(release), "-p", document["project"], "--env-file", str(runtime / ".env")]
        for name in document["compose_files"]:
            command.extend(["-f", str(release / relative(name))])
        config = json.loads(run([*command, "config", "--format", "json"], env, release))
        images = pin_images(config, document, env)
        # Compose config already escapes literal dollars for safe re-reading.
        # Escaping again would change container secrets from $ to $$.
        write_json(runtime / "compose.json", config)
        (release / "compose.resolved.json").symlink_to(runtime / "compose.json")
        document["resolved_images"] = images
        document["archive_sha256"] = archive_hash
        document["runtime_sha256"] = digest(runtime / "compose.json")
        document["env_sha256"] = digest(runtime / ".env")
        document["runtime_inventory"] = inventory(runtime, skip_inventory=False)
        # Compatibility evidence for existing backup capture readers.
        write_json(release / "image-digests.json", {"schema_version": 1, "services": {k: v.split("@", 1)[1] for k, v in images.items()}}, 0o644)
        if document.get("qualification"):
            write_json(release / "release-manifest.json", document["qualification"], 0o644)
        write_json(release / ".toolkit-release.json", document, 0o644)
        write_json(release / ".toolkit-inventory.json", inventory(release), 0o644)
        for path in [release, *release.rglob("*")]:
            if not path.is_symlink():
                os.chown(path, 0, 0)
                path.chmod(0o555 if path.is_dir() or path.stat().st_mode & 0o111 else 0o444)
        # Runtime directory contents are private but hook-created secret files retain
        # their deliberate mount permissions (e.g. Alertmanager reads as non-root).
        for path in [runtime, *runtime.rglob("*")]:
            os.lchown(path, 0, 0)
        log(f"release staged id={document['release_id']}")
        return release
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def verify(release, args):
    no_symlink(release)
    path = release / ".toolkit-release.json"
    require(path.is_file() and not path.is_symlink(), "legacy or incomplete release; stage a new snapshot first")
    document = json.loads(path.read_text(encoding="utf-8"))
    validate_manifest(document, args)
    require(document["release_id"] == release.name, "release directory mismatch")
    require(inventory(release) == json.loads((release / ".toolkit-inventory.json").read_text(encoding="utf-8")), "release inventory mismatch")
    runtime = args.root / ".runtime" / release.name
    no_symlink(runtime)
    require(inventory(runtime, skip_inventory=False) == document["runtime_inventory"], "private runtime files changed")
    require(digest(runtime / "compose.json") == document["runtime_sha256"] and digest(runtime / ".env") == document["env_sha256"], "private runtime snapshot changed")
    require((release / "compose.resolved.json").resolve() == runtime / "compose.json", "runtime pointer escaped snapshot")
    return document, runtime


def resolve(args, name):
    require(bool(IDENTITY.fullmatch(name)), "invalid target release ID")
    target = args.root / name
    if name in {"current", "previous"}:
        require(target.is_symlink(), "release pointer is missing")
        target = target.resolve(strict=True)
        require(target.parent == args.root, "release pointer escaped release root")
    return target


def pointer(root, name, target):
    temporary = root / f".{name}-{os.getpid()}"
    temporary.symlink_to(target.name, target_is_directory=True)
    os.replace(temporary, root / name)


def public_health(urls):
    class HTTPSRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, message, headers, newurl):
            require(newurl.startswith("https://"), "public health redirect must remain HTTPS")
            return super().redirect_request(request, fp, code, message, headers, newurl)

    opener = urllib.request.build_opener(HTTPSRedirect)
    for url in urls:
        successful = 0
        for _ in range(30):
            try:
                request = urllib.request.Request(url, headers={"Cache-Control": "no-cache"})
                with opener.open(request, timeout=15) as response:
                    require(200 <= response.status < 300, "public health failed")
                successful += 1
                if successful == 3:
                    break
            except (OSError, ValueError):
                successful = 0
            time.sleep(2)
        require(successful == 3, "public health did not qualify release")


def apply(args, release, env, reconcile=False):
    document, runtime = verify(release, args)
    env.update(dotenv(runtime / ".env"))
    env.update(document.get("environment_variables", {}))
    if (runtime / "extra.env").exists():
        env.update(dotenv(runtime / "extra.env"))
    command = compose(document, release)
    if not reconcile:
        # Pull exact retained digests outside the host capacity window, including rollback.
        for reference in set(document["resolved_images"].values()):
            run(["docker", "pull", reference], env)
    with host_window():
        if reconcile:
            run([*command, "up", "-d", "--no-recreate", "--pull", "never", "--no-build"], env)
        else:
            config = json.loads((runtime / "compose.json").read_text(encoding="utf-8"))
            ensure_resources(config, args.repository, env)
            # Stable data containers may be created on first install but never silently
            # recreated during application rollouts. Explicit data upgrades are separate.
            stable = [name for name, item in config["services"].items() if not item.get("profiles") and (name in {"mysql", "redis", "postgres", "umami-db", "n8n-postgres"} or name.endswith(("-mysql", "-postgres", "-redis")) or re.search(r"(^|/)(mysql|mariadb|postgres|redis)(:|@)", item["image"]))]
            for service in stable:
                identifiers = run(["docker", "ps", "-aq", "--filter", f"label=com.docker.compose.project={document['project']}", "--filter", f"label=com.docker.compose.service={service}"], env).split()
                if identifiers:
                    expected = run(["docker", "image", "inspect", "--format", "{{.Id}}", document["resolved_images"][service]], env).strip()
                    for identifier in identifiers:
                        actual = run(["docker", "inspect", "--format", "{{.Image}}", identifier], env).strip()
                        require(actual == expected, "stable data image differs; perform an explicit data upgrade first")
            if stable:
                run([*command, "up", "-d", "--no-recreate", "--pull", "never", "--no-build", "--wait", "--wait-timeout", "300", *stable], env)
            changing = [name for name, item in config["services"].items() if name not in stable and not item.get("profiles")]
            if changing:
                run([*command, "up", "-d", "--no-deps", "--pull", "never", "--no-build", "--wait", "--wait-timeout", "300", *changing], env)
            script(document, "post_deploy_script", release, runtime, env, args.user)
            public_health(document.get("health_urls", []))
            if (args.root / "current").is_symlink():
                previous = resolve(args, "current")
                if previous != release:
                    pointer(args.root, "previous", previous)
            pointer(args.root, "current", release)
    log(f"{'reconciled' if reconcile else 'activated'} id={release.name}")


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "registration":
        registration_parser = argparse.ArgumentParser()
        registration_parser.add_argument("--registration", type=Path, required=True)
        registration_args = registration_parser.parse_args(sys.argv[2:])
        registration = registration_args.registration
        no_symlink(registration)
        require(registration.is_file() and registration.stat().st_uid == 0 and registration.stat().st_mode & 0o022 == 0, "reconcile registration must be root-owned and protected")
        record = json.loads(registration.read_text(encoding="utf-8"))
        require(set(record) == {"repository", "environment", "root", "user"}, "invalid reconcile registration")
        arguments = []
        for key in ("repository", "environment", "root", "user"):
            require(isinstance(record[key], str) and "\0" not in record[key], "invalid reconcile registration value")
            arguments.extend(["--" + key, record[key]])
        sys.stdout.buffer.write(b"\0".join(value.encode() for value in arguments) + b"\0")
        return
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["stage", "deploy", "activate", "rollback", "reconcile"])
    for name in ("repository", "environment", "user"):
        parser.add_argument(f"--{name}", required=True)
    parser.add_argument("--root", type=Path, required=True)
    for name in ("archive", "checksum", "manifest", "env-file", "registry-config"):
        parser.add_argument(f"--{name}", type=Path)
    parser.add_argument("--release-id")
    args = parser.parse_args()
    require(os.geteuid() == 0, "deployment controller requires root toolkit entrypoint")
    require(bool(SLUG.fullmatch(args.repository)) and bool(SLUG.fullmatch(args.environment)), "invalid repository/environment")
    account = pwd.getpwnam(args.user)
    require(account.pw_uid != 0, "deploy user must not be root")
    no_symlink(args.root)
    require(args.root.is_relative_to(Path(account.pw_dir)) and args.root != Path(account.pw_dir), "release root must be below deploy user home")
    args.root.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, HOME=account.pw_dir)
    diagnostics = args.root / ".operation-logs"
    no_symlink(diagnostics)
    diagnostics.mkdir(mode=0o700, exist_ok=True)
    os.chown(diagnostics, 0, 0)
    diagnostics.chmod(0o700)
    env["TOOLKIT_DIAGNOSTIC_DIR"] = str(diagnostics)
    if args.registry_config:
        no_symlink(args.registry_config)
        env["DOCKER_CONFIG"] = str(args.registry_config)
    else:
        # Avoid consuming a different operation's shared Docker login credentials.
        env["DOCKER_CONFIG"] = str(args.root / ".registry-empty")
    if args.action in {"stage", "deploy"}:
        for name in ("archive", "checksum", "manifest", "env_file"):
            path = getattr(args, name)
            require(path is not None and path.is_file(), f"--{name.replace('_', '-')} required")
            no_symlink(path)
        release = stage(args, account, env)
        if args.action == "deploy":
            apply(args, release, env)
    elif args.action == "reconcile":
        if not (args.root / "current").exists() and not (args.root / "current").is_symlink():
            log("no current release; skipped")
            return
        apply(args, resolve(args, "current"), env, reconcile=True)
    else:
        require(args.action != "activate" or args.release_id is not None, "activate requires --release-id")
        apply(args, resolve(args, args.release_id or "previous"), env)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, KeyError, subprocess.TimeoutExpired, tarfile.TarError) as error:
        # Values and command output are intentionally excluded from the diagnostic.
        log(str(error) if isinstance(error, ValueError) else f"operation failed ({type(error).__name__})")
        raise SystemExit(1)
