#!/usr/bin/env bash
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
temporary="$(mktemp -d)"
trap 'rm -rf -- "$temporary"' EXIT
mock_bin="$temporary/bin"
mkdir -p "$mock_bin"

cat >"$mock_bin/docker" <<'MOCK'
#!/usr/bin/env bash
set -euo pipefail
case "$*" in
  "version --format {{.Server.Version}}") printf '%s\n' "${MOCK_DOCKER_VERSION:-29.0.1}" ;;
  "info --format {{.FirewallBackend.Driver}}") printf '%s\n' "${MOCK_FIREWALL_BACKEND:-iptables}" ;;
  *) printf 'unexpected docker invocation: %s\n' "$*" >&2; exit 90 ;;
esac
MOCK

cat >"$mock_bin/systemctl" <<'MOCK'
#!/usr/bin/env bash
set -euo pipefail
[[ "$1" == is-active && "$2" == --quiet ]] || exit 90
case "$3" in
  ufw) [[ "${MOCK_UFW_ACTIVE:-false}" == true ]] ;;
  firewalld) [[ "${MOCK_FIREWALLD_ACTIVE:-false}" == true ]] ;;
  *) exit 90 ;;
esac
MOCK

for command_name in iptables ip6tables; do
  cat >"$mock_bin/$command_name" <<'MOCK'
#!/usr/bin/env bash
set -euo pipefail
if [[ "$1" == --version ]]; then
  printf '%s\n' 'iptables v1.8.10 (nf_tables)'
  exit 0
fi
[[ "$1" == -S && "$2" == DOCKER-USER ]] || {
  printf 'unexpected firewall mutation or inspection: %s %s\n' "$0" "$*" >&2
  exit 90
}
if [[ "${MOCK_IPV6_CHAIN_MISSING:-false}" == true && "${0##*/}" == ip6tables ]]; then
  exit 1
fi
printf '%s\n' '-N DOCKER-USER'
MOCK
done

for command_name in iptables-restore ip6tables-restore; do
  cat >"$mock_bin/$command_name" <<'MOCK'
#!/usr/bin/env bash
set -euo pipefail
[[ "$1" == --version ]] || {
  printf 'unexpected firewall rule application: %s %s\n' "$0" "$*" >&2
  exit 90
}
printf '%s\n' 'iptables-restore v1.8.10 (nf_tables)'
MOCK
done

chmod +x "$mock_bin"/*

plan_output="$(PATH="$mock_bin:$PATH" "$toolkit_root/bin/toolkit" firewall plan --config "$toolkit_root/config/host.conf.example")"
grep -q '^firewall_action=inventory_only mode=direct backend=iptables ' <<<"$plan_output"
grep -q 'docker_user_ipv4=present docker_user_ipv6=present' <<<"$plan_output"
grep -q 'intended_policy=published-host-ports-80-443 persistence=not_installed' <<<"$plan_output"

if PATH="$mock_bin:$PATH" MOCK_FIREWALL_BACKEND=nftables "$toolkit_root/bin/toolkit" firewall plan --config "$toolkit_root/config/host.conf.example" >"$temporary/nft.out" 2>&1; then
  printf 'expected native nftables backend to be reported as unsupported\n' >&2
  exit 1
fi
grep -q 'firewall_action=blocked reason=unsupported_docker_backend backend=nftables' "$temporary/nft.out"

if PATH="$mock_bin:$PATH" MOCK_DOCKER_VERSION=$'29.0.1\ninjected' "$toolkit_root/bin/toolkit" firewall plan --config "$toolkit_root/config/host.conf.example" >"$temporary/version.out" 2>&1; then
  printf 'expected malformed Docker version output to be rejected\n' >&2
  exit 1
fi
grep -q 'firewall_action=blocked reason=docker_server_version_unrecognized' "$temporary/version.out"

if PATH="$mock_bin:$PATH" MOCK_UFW_ACTIVE=true "$toolkit_root/bin/toolkit" firewall plan --config "$toolkit_root/config/host.conf.example" >"$temporary/ufw.out" 2>&1; then
  printf 'expected active ufw to be reported as an ownership conflict\n' >&2
  exit 1
fi
grep -q 'firewall_action=blocked reason=active_firewall_manager manager=ufw' "$temporary/ufw.out"

if PATH="$mock_bin:$PATH" MOCK_IPV6_CHAIN_MISSING=true "$toolkit_root/bin/toolkit" firewall plan --config "$toolkit_root/config/host.conf.example" >"$temporary/ipv6.out" 2>&1; then
  printf 'expected a missing IPv6 Docker hook to block the firewall plan\n' >&2
  exit 1
fi
grep -q 'firewall_action=blocked reason=docker_user_chain_missing family=ipv6' "$temporary/ipv6.out"

cloudflare_config="$temporary/cloudflare.conf"
sed 's/^WEB_INGRESS_MODE=direct$/WEB_INGRESS_MODE=cloudflare/' "$toolkit_root/config/host.conf.example" >"$cloudflare_config"
if PATH="$mock_bin:$PATH" "$toolkit_root/bin/toolkit" firewall plan --config "$cloudflare_config" >"$temporary/cloudflare.out" 2>&1; then
  printf 'expected Cloudflare mode to remain blocked until range refresh is implemented\n' >&2
  exit 1
fi
grep -q 'firewall_action=blocked reason=cloudflare_range_catalog_unimplemented' "$temporary/cloudflare.out"

printf 'toolkit firewall plan checks passed\n'
