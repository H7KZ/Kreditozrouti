#!/usr/bin/env bash
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
work="$(mktemp -d)"
holder='' waiting=''
cleanup() {
  [[ -z "$waiting" ]] || kill "$waiting" 2>/dev/null || true
  [[ -z "$holder" ]] || wait "$holder" || true
  rm -rf -- "$work"
}
trap cleanup EXIT
mkdir -p "$work/locks/repos/busy"
sed "s|/run/lock/toolkit|$work/locks|g" "$root/lib/locks.sh" >"$work/locks.sh"
cat >"$work/run.sh" <<'SCRIPT'
#!/usr/bin/env bash
set -u
source "$1/locks.sh"
shift
toolkit_require_root() { :; }
toolkit_assert_supported_platform() { :; }
toolkit_validate_slug() { [[ "$1" =~ ^[a-z]+$ ]]; }
toolkit_die() { printf '%s\n' "$*" >&2; exit 1; }
toolkit_log() { :; }
install() {
  local -a args=()
  while (($#)); do
    case "$1" in -o | -g) shift 2 ;; *) args+=("$1"); shift ;; esac
  done
  command install "${args[@]}"
}
toolkit_with_locks "$@"
SCRIPT
# Mimic a backup holding the repository lock without the host lock.
flock -x "$work/locks/repos/busy/repository.lock" bash -c 'touch "$1/held"; sleep 4' _ "$work" &
holder=$!
for ((attempt = 0; attempt < 100; attempt++)); do
  [[ ! -f "$work/held" ]] || break
  sleep 0.01
done
[[ -f "$work/held" ]]
bash "$work/run.sh" "$work" --repository busy --environment production --host-window --timeout 3 -- touch "$work/busy-ran" &
waiting=$!
# A second environment must share the same lock and fail instead of racing capture.
if bash "$work/run.sh" "$work" --repository busy --environment monitoring --timeout 1 -- touch "$work/monitoring-ran" 2>/dev/null; then
  printf 'monitoring bypassed repository backup lock\n' >&2
  exit 1
fi
# Host-wide maintenance also waits for every registered repository's capture.
if bash "$work/run.sh" "$work" --all-repositories --timeout 1 -- touch "$work/maintenance-ran" 2>/dev/null; then
  printf 'host maintenance bypassed repository backup lock\n' >&2
  exit 1
fi
# The blocked deploy must not hold host; this separate repository can finish now.
bash "$work/run.sh" "$work" --repository other --environment production --host-window --timeout 1 -- touch "$work/other-ran"
[[ -f "$work/other-ran" && ! -e "$work/busy-ran" && ! -e "$work/monitoring-ran" ]]
wait "$waiting" && exit 1
waiting=''
printf 'repository-wide locks and convoy prevention passed\n'
