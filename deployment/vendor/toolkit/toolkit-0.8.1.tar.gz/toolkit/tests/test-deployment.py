#!/usr/bin/env python3
"""Exercise snapshot integrity and failure semantics without Docker or host changes."""

import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
from types import SimpleNamespace
import tarfile
import tempfile
import unittest
from unittest.mock import patch


SPEC = importlib.util.spec_from_file_location("deployment", Path(__file__).parents[1] / "lib/deployment.py")
deployment = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(deployment)
IMAGE = "ghcr.io/example/app@sha256:" + "a" * 64


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self.work = tempfile.TemporaryDirectory()
        self.addCleanup(self.work.cleanup)
        root = Path(self.work.name)
        (root / "releases").mkdir()
        archive = root / "source.tar.gz"
        with tarfile.open(archive, "w:gz") as stream:
            data = b"services: {}\n"
            member = tarfile.TarInfo("production/compose.yml")
            member.size = len(data)
            stream.addfile(member, io.BytesIO(data))
        checksum = root / "source.tar.gz.sha256"
        checksum.write_text(hashlib.sha256(archive.read_bytes()).hexdigest() + "  source.tar.gz\n")
        env_file = root / "secret.env"
        env_file.write_text("PASSWORD='secret$literal'\n")
        manifest = root / "manifest.json"
        self.document = {"schema_version": 1, "repository": "example", "environment": "production", "release_id": "release-a", "source_commit": "a" * 40, "project": "example", "compose_files": ["production/compose.yml"], "images": {"api": IMAGE}}
        manifest.write_text(json.dumps(self.document))
        self.args = SimpleNamespace(root=root / "releases", repository="example", environment="production", archive=archive, checksum=checksum, manifest=manifest, env_file=env_file, user="nobody")
        self.account = SimpleNamespace(pw_uid=os.getuid(), pw_gid=os.getgid())
        self.commands = []
        self.fail_up = False

    def command(self, arguments, env, cwd=None):
        self.commands.append(arguments)
        if "config" in arguments:
            return json.dumps({"services": {"api": {"image": IMAGE, "environment": {"PASSWORD": "secret$$literal"}}}})
        if self.fail_up and "up" in arguments:
            raise ValueError("compose failed")
        return ""

    @contextlib.contextmanager
    def host(self):
        yield

    def stage(self):
        # Ownership changes are platform concerns; exercise production archive,
        # inventory, private config and pointer logic as an unprivileged CI user.
        with patch.object(deployment, "run", self.command), patch.object(deployment.os, "chown"), patch.object(deployment.os, "lchown"), patch.object(Path, "chmod"):
            return deployment.stage(self.args, self.account, {})

    def test_failure_keeps_current_and_rollback_uses_saved_config(self):
        first = self.stage()
        with patch.object(deployment, "run", self.command), patch.object(deployment, "host_window", self.host):
            deployment.apply(self.args, first, {})
            self.document["release_id"] = "release-b"
            self.args.manifest.write_text(json.dumps(self.document))
            second = self.stage()
            self.fail_up = True
            with self.assertRaises(ValueError):
                deployment.apply(self.args, second, {})
            self.assertEqual((self.args.root / "current").resolve(), first)
            self.fail_up = False
            deployment.apply(self.args, second, {})
            self.assertEqual(deployment.resolve(self.args, "previous"), first)
            deployment.apply(self.args, first, {})
            self.assertEqual((self.args.root / "current").resolve(), first)
            self.assertEqual(deployment.resolve(self.args, "previous"), second)
        stored = json.loads((self.args.root / ".runtime/release-a/compose.json").read_text())
        self.assertEqual(stored["services"]["api"]["environment"]["PASSWORD"], "secret$$literal")

    def test_reconcile_never_pulls_or_recreates(self):
        release = self.stage()
        self.commands.clear()
        with patch.object(deployment, "run", self.command), patch.object(deployment, "host_window", self.host):
            deployment.apply(self.args, release, {}, reconcile=True)
        self.assertEqual(len(self.commands), 1)
        self.assertIn("--no-recreate", self.commands[0])
        self.assertIn("never", self.commands[0])
        self.assertNotIn("pull", self.commands[0])
        self.assertFalse((self.args.root / "current").exists())

    def test_tampered_private_config_and_source_fail_closed(self):
        release = self.stage()
        (release / "production/compose.yml").write_text("tampered")
        with self.assertRaisesRegex(ValueError, "inventory"):
            deployment.verify(release, self.args)
        (release / "production/compose.yml").write_text("services: {}\n")
        (self.args.root / ".runtime/release-a/.env").write_text("PASSWORD=changed\n")
        with self.assertRaisesRegex(ValueError, "runtime"):
            deployment.verify(release, self.args)

    def test_traversal_and_symlink_archives_rejected(self):
        for name, kind in [("../escape", tarfile.REGTYPE), ("production/link", tarfile.SYMTYPE)]:
            with self.subTest(name=name):
                with tarfile.open(self.args.archive, "w:gz") as stream:
                    member = tarfile.TarInfo(name)
                    member.type = kind
                    member.linkname = "/etc/passwd"
                    stream.addfile(member)
                self.args.checksum.write_text(deployment.digest(self.args.archive))
                target = self.args.root / "extract"
                target.mkdir(exist_ok=True)
                with self.assertRaises(ValueError):
                    deployment.extract(self.args.archive, self.args.checksum, target)

    def test_network_owner_and_private_isolation_are_preserved(self):
        config = {"networks": {"lapi": {"external": True, "name": "traefik-crowdsec-network", "x-toolkit-internal": True}}}
        with patch.object(deployment.subprocess, "run", return_value=SimpleNamespace(returncode=1)), patch.object(deployment, "run", self.command):
            deployment.ensure_resources(config, "infrastructure", {})
            self.assertIn(["docker", "network", "create", "--internal", "traefik-crowdsec-network"], self.commands)
            config["networks"]["lapi"]["name"] = "public-network"
            with self.assertRaisesRegex(ValueError, "shared external"):
                deployment.ensure_resources(config, "example", {})


if __name__ == "__main__":
    unittest.main()
