# Backup and recovery ownership inventory v1

Status: static inventory derived from repository configuration, 2026-10-10. Not yet checked against
live production Docker state. Infrastructure maintains this map; each owner validates its sources
read-only before enabling scheduled capture.

Each persistent source has one capture owner. Recovery dependencies include pinned toolkit version,
source/config revision, immutable image digests, compatible database/application versions, and secrets
from the independent recovery kit. Registry retention must keep digests referenced by any retained
or last-good recovery set.

## Application-owned sources

| Source | Persistent backing | Capture owner and method | Recovery dependents | Required recovery dependencies |
| --- | --- | --- | --- | --- |
| Ohlidame MySQL | `ohlidame-mysql-volume-prod` | Ohlidame; logical SQL export. Exclude raw `scan_acquisition_artifact` rows; include its schema. | Ohlidame API, scraper, web | Ohlidame image digests, MySQL version, migration revision, runtime secrets |
| Ohlidame Redis | `ohlidame-redis-volume-prod` | Ohlidame; do not restore old Redis data. Recreate empty. | Ohlidame API, scraper | Ohlidame image digests and runtime secrets; reconcile durable paid work before side effects |
| Ohlidame Umami PostgreSQL | `ohlidame-umami-postgres-volume` | Ohlidame; PostgreSQL logical dump | Ohlidame Umami analytics | Umami image digest and PostgreSQL version |
| Kreditozrouti MySQL | `kreditozrouti-mysql-volume-prod` | Kreditozrouti; logical SQL export | Kreditozrouti API, web, MCP, scraper | Kreditozrouti image digests, MySQL version, migration revision, runtime secrets |
| Kreditozrouti Redis | `kreditozrouti-redis-volume-prod` | Kreditozrouti; export only `share:*` and `ical:*` keys, with original absolute expirations | API, web, MCP share and calendar links | Redis version, app image digests, isolated target; discard queues/caches/counters |
| Kreditozrouti Umami PostgreSQL | `kreditozrouti-umami-postgres-volume` | Kreditozrouti; PostgreSQL logical dump | Kreditozrouti Umami analytics | Umami image digest and PostgreSQL version |

Ohlidame and Kreditozrouti own separate Umami databases and capture them with their application
backups. Neither Infrastructure nor the other app repository is a second owner for either database.

## Infrastructure-owned sources

| Source | Persistent backing | Capture owner and method | Recovery dependents | Required recovery dependencies |
| --- | --- | --- | --- | --- |
| n8n PostgreSQL | `n8n-postgres-volume` | Infrastructure; `pg_dump` | n8n | n8n/PostgreSQL image digests, `N8N_ENCRYPTION_KEY`, database/runtime secrets |
| n8n user folder | `n8n-data-volume` | Infrastructure; stopped local volume archive paired with PostgreSQL dump | n8n and external task runners | n8n-compatible image digests and `N8N_ENCRYPTION_KEY` |
| Wakapi PostgreSQL | `wakapi-postgres-volume` | Infrastructure; `pg_dump` | Wakapi | Wakapi/PostgreSQL image digests, `WAKAPI_PASSWORD_SALT`, database/runtime secrets |
| WordPress KMK database/files | `kmk-mysql-volume`, `kmk-data-volume` | Infrastructure; MariaDB dump plus stopped files-volume archive | KMK WordPress | KMK and MariaDB image digests, compatible release and runtime secrets |
| WordPress Jirikominek database/files | `jirikominek-mysql-volume`, `jirikominek-data-volume` | Infrastructure; MariaDB dump plus stopped files-volume archive | Jirikominek WordPress | WordPress and MariaDB image digests, compatible release and runtime secrets |
| WordPress Client Showcase database/files | `client-showcase-mysql-volume`, `client-showcase-data-volume` | Infrastructure; MariaDB dump plus stopped files-volume archive | Client Showcase WordPress | WordPress and MariaDB image digests, compatible release and runtime secrets |
| Uptime Kuma | `uptime-kuma-data-volume` | Infrastructure; stopped local volume archive | Uptime Kuma | Uptime Kuma image digest and compatible runtime configuration |
| TREK data/uploads | `trek-data-volume`, `trek-uploads-volume` | Infrastructure; stopped local volume archives | TREK | TREK image digest, original encryption/JWT material, compatible release |
| CLIProxyAPI config/OAuth | `cli-proxy-api-config-volume`, `cli-proxy-api-data-volume` | Infrastructure; stopped local volume archives | CLIProxyAPI | CLIProxyAPI image digest, config and OAuth credentials |
| Traefik certificates | `traefik-certificates-volume` | Infrastructure; explicit volume archive | Shared proxy and every routed service | Traefik proxy bundle/source revision and registry image digest |
| CrowdSec data/config and proxy secrets | `crowdsec-db-volume`, `crowdsec-config-volume`, `crowdsec-lapi-key`, `traefik-htpasswd` | Infrastructure; explicit volume archives plus key files | Shared proxy and every protected service | CrowdSec/Traefik image digests, compatible config, LAPI key, dashboard auth hash |

## Exclusions and shared dependencies

- Exclude every Stash resource, including `stash-config-volume`, `stash-data-volume`,
  `stash-metadata-volume`, `stash-cache-volume`, `stash-blobs-volume`, and
  `stash-generated-volume`. Do not add a Stash restore promise.
- Exclude Prometheus and Alertmanager history, Loki data, Grafana mutable state, Alloy state,
  Traefik logs, and regenerable Traefik plugin cache. Recreate monitoring configuration from Git.
- `public-network` is the shared proxy network dependency for routed applications. Infrastructure
  owns the active `global` proxy project plus `traefik-socket-proxy-network`,
  `traefik-crowdsec-network`, and `infrastructure-monitoring-network`.
- Recovery requires immutable registry digests recorded with each capture, the exact toolkit bundle
  pin, compatible source/config revisions, and secrets from the offline recovery kit. Docker image
  archives are not part of these backups.
- Release-manifest publication, trusted off-VPS recovery-reference publication, registry-retention
  consumption of their union, and live source validation remain separate implementation/evidence
  gates. Do not claim four-hour RPO/RTO or compromise survival from this static inventory.
