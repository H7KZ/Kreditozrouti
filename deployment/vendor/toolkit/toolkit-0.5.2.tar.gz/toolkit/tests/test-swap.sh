#!/usr/bin/env bash
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
temporary="$(mktemp -d)"
trap 'toolkit_cleanup_temp_paths; rm -rf -- "$temporary"' EXIT
source "$toolkit_root/lib/common.sh"
source "$toolkit_root/lib/files.sh"
source "$toolkit_root/lib/swap.sh"

"$toolkit_root/bin/toolkit" --help | grep -q 'apply --config <path> --module <swap>'
if "$toolkit_root/bin/toolkit" apply --module swap >"$temporary/apply-error.out" 2>&1; then
  printf 'expected apply to require an explicit config path\n' >&2
  exit 1
fi
grep -q 'apply requires --config <path> and --module <name>' "$temporary/apply-error.out"

new_root() {
  local root="$temporary/$1"
  mkdir -p "$root/etc" "$root/proc"
  printf 'Filename Type Size Used Priority\n' >"$root/proc/swaps"
  printf '# existing fstab\n' >"$root/etc/fstab"
  printf '%s\n' "$root"
}

TEST_FILESYSTEM=ext4
TEST_AVAILABLE_KIB=10000000
TEST_SWAPON_FAIL=false
TEST_FALLOCATE_CALLS=0
TEST_MKSWAP_CALLS=0
TEST_SWAPON_CALLS=0

findmnt() { printf '%s\n' "$TEST_FILESYSTEM"; }
df() {
  printf 'Filesystem 1024-blocks Used Available Capacity Mounted on\n'
  printf '/dev/test 20000000 1000 %s 1%% /\n' "$TEST_AVAILABLE_KIB"
}
fallocate() {
  [[ "$1" == -l && $# == 3 ]] || return 2
  ((TEST_FALLOCATE_CALLS += 1))
  truncate -s "$2" "$3"
}
mkswap() {
  ((TEST_MKSWAP_CALLS += 1))
  [[ -f "$1" && ! -L "$1" ]]
}
blkid() {
  [[ "$*" == *'-s TYPE'* && -f "${*: -1}" ]] || return 2
  printf 'swap\n'
}
swapon() {
  ((TEST_SWAPON_CALLS += 1))
  [[ "$TEST_SWAPON_FAIL" == false ]] || return 1
  local path="${*: -1}" bytes kib
  bytes="$(stat -c '%s' -- "$path")"
  kib=$((bytes / 1024))
  printf '%s file %s 0 -2\n' "$path" "$kib" >>"${TEST_ROOT}/proc/swaps"
}

root="$(new_root disabled)"
TEST_ROOT="$root"
toolkit_swap_apply "$root" 0 >/dev/null
[[ ! -e "$root/swapfile" ]]
[[ "$(cat "$root/etc/fstab")" == '# existing fstab' ]]

root="$(new_root provider-swap)"
TEST_ROOT="$root"
printf '/dev/provider partition 2097152 0 -2\n' >>"$root/proc/swaps"
toolkit_swap_apply "$root" 4 >"$temporary/provider.out" 2>&1
grep -q 'swap_preserved=true requested_gb=4' "$temporary/provider.out"
[[ ! -e "$root/swapfile" ]]
[[ "$(grep -c '^/swapfile none swap sw 0 0$' "$root/etc/fstab" || true)" == 0 ]]

root="$(new_root fresh)"
TEST_ROOT="$root"
toolkit_swap_plan "$root" 4 >"$temporary/plan.out"
grep -q 'swap_action=create requested_gb=4 filesystem=ext4' "$temporary/plan.out"
[[ ! -e "$root/swapfile" ]]
[[ "$(cat "$root/etc/fstab")" == '# existing fstab' ]]
toolkit_swap_apply "$root" 4 >/dev/null
[[ "$(stat -c '%s' "$root/swapfile")" == 4294967296 ]]
[[ "$(stat -c '%a' "$root/swapfile")" == 600 ]]
[[ "$(grep -c '^/swapfile none swap sw 0 0$' "$root/etc/fstab")" == 1 ]]
[[ "$TEST_FALLOCATE_CALLS" == 1 && "$TEST_MKSWAP_CALLS" == 1 && "$TEST_SWAPON_CALLS" == 1 ]]
toolkit_swap_apply "$root" 4 >/dev/null
[[ "$(grep -c '^/swapfile none swap sw 0 0$' "$root/etc/fstab")" == 1 ]]
[[ "$TEST_FALLOCATE_CALLS" == 1 && "$TEST_MKSWAP_CALLS" == 1 && "$TEST_SWAPON_CALLS" == 1 ]]

root="$(new_root interrupted)"
TEST_ROOT="$root"
TEST_SWAPON_FAIL=true
if toolkit_swap_apply "$root" 4 >/dev/null 2>&1; then
  printf 'expected failed activation to be reported\n' >&2
  exit 1
fi
[[ -f "$root/swapfile" ]]
[[ "$(grep -c '^/swapfile none swap sw 0 0$' "$root/etc/fstab")" == 1 ]]
TEST_SWAPON_FAIL=false
toolkit_swap_apply "$root" 4 >/dev/null
[[ "$(grep -c '^/swapfile none swap sw 0 0$' "$root/etc/fstab")" == 1 ]]

root="$(new_root fstab-write-retry)"
TEST_ROOT="$root"
chmod 0777 "$root/etc"
if toolkit_swap_apply "$root" 4 >/dev/null 2>&1; then
  printf 'expected fstab write failure to be reported\n' >&2
  exit 1
fi
[[ -f "$root/swapfile" ]]
[[ "$(grep -c '^/swapfile none swap sw 0 0$' "$root/etc/fstab" || true)" == 0 ]]
chmod 0755 "$root/etc"
toolkit_swap_apply "$root" 4 >/dev/null
[[ "$(grep -c '^/swapfile none swap sw 0 0$' "$root/etc/fstab")" == 1 ]]

root="$(new_root unsupported-filesystem)"
TEST_ROOT="$root"
TEST_FILESYSTEM=btrfs
if toolkit_swap_apply "$root" 4 >/dev/null 2>&1; then
  printf 'expected unsupported filesystem to be rejected\n' >&2
  exit 1
fi
[[ ! -e "$root/swapfile" ]]

root="$(new_root low-space)"
TEST_ROOT="$root"
TEST_FILESYSTEM=ext4
TEST_AVAILABLE_KIB=1000
if toolkit_swap_apply "$root" 4 >/dev/null 2>&1; then
  printf 'expected insufficient free space to be rejected\n' >&2
  exit 1
fi
[[ ! -e "$root/swapfile" ]]

root="$(new_root conflicting-file)"
TEST_ROOT="$root"
printf 'do not overwrite\n' >"$root/swapfile"
if toolkit_swap_apply "$root" 4 >/dev/null 2>&1; then
  printf 'expected an existing non-swap file to be rejected\n' >&2
  exit 1
fi
[[ "$(cat "$root/swapfile")" == 'do not overwrite' ]]

root="$(new_root conflicting-fstab)"
TEST_ROOT="$root"
printf '/swapfile /data ext4 defaults 0 0\n' >>"$root/etc/fstab"
if toolkit_swap_apply "$root" 4 >/dev/null 2>&1; then
  printf 'expected a conflicting fstab entry to be rejected\n' >&2
  exit 1
fi
[[ ! -e "$root/swapfile" ]]

printf 'toolkit swap checks passed\n'
