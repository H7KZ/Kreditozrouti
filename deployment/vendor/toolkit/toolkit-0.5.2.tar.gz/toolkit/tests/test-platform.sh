#!/usr/bin/env bash
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
temporary="$(mktemp -d)"
trap 'rm -rf -- "$temporary"' EXIT
source "$toolkit_root/lib/common.sh"
source "$toolkit_root/lib/platform.sh"

cat >"$temporary/ubuntu-26.04" <<'OS'
ID=ubuntu
VERSION_ID="26.04"
OS
toolkit_assert_supported_platform "$temporary/ubuntu-26.04" x86_64
if (toolkit_assert_supported_platform "$temporary/ubuntu-26.04" aarch64) >/dev/null 2>&1; then
  printf 'expected arm64 to remain unsupported until validated\n' >&2
  exit 1
fi

cat >"$temporary/ubuntu-24.04" <<'OS'
ID=ubuntu
VERSION_ID="24.04"
OS
if (toolkit_assert_supported_platform "$temporary/ubuntu-24.04" x86_64) >/dev/null 2>&1; then
  printf 'expected Ubuntu 24.04 to be rejected\n' >&2
  exit 1
fi

printf 'toolkit platform guard checks passed\n'
