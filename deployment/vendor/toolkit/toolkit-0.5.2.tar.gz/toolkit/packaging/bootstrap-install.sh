#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
toolkit_root="$(cd -- "$script_dir/.." && pwd -P)"

if (($# != 2)); then
  printf 'Usage: %s <release-archive> <sha256-file>\n' "$0" >&2
  exit 2
fi

archive="$1"
checksum="$2"
bash "$toolkit_root/bin/toolkit" install --archive "$archive" --checksum "$checksum"
