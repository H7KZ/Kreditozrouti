#!/usr/bin/env bash

toolkit_stage_archive() {
  local archive="$1" checksum="$2" destination="$3" expected listed extra actual
  local -a lines=()
  [[ -f "$archive" && -r "$archive" && ! -L "$archive" ]] || toolkit_die 'release archive must be a readable regular file, not a symlink'
  [[ -f "$checksum" && -r "$checksum" && ! -L "$checksum" ]] || toolkit_die 'release checksum must be a readable regular file, not a symlink'
  mapfile -t lines <"$checksum"
  ((${#lines[@]} == 1)) || toolkit_die 'checksum file must contain exactly one line'
  read -r expected listed extra <<<"${lines[0]}"
  [[ "$expected" =~ ^[a-f0-9]{64}$ && -z "${extra:-}" ]] || toolkit_die 'checksum file must begin with one SHA-256 digest'
  if [[ -n "${listed:-}" && "$listed" != "$(basename -- "$archive")" ]]; then
    toolkit_die 'checksum filename does not match the archive basename'
  fi

  cp -- "$archive" "$destination/release.tar.gz" || toolkit_die 'cannot stage release archive'
  actual="$(sha256sum -- "$destination/release.tar.gz" | awk '{print $1}')" || toolkit_die 'cannot hash staged release archive'
  [[ "$actual" == "$expected" ]] || toolkit_die 'staged release archive SHA-256 mismatch'
  printf '%s  release.tar.gz\n' "$expected" >"$destination/release.tar.gz.sha256" || toolkit_die 'cannot stage release checksum'
  TOOLKIT_STAGED_ARCHIVE_SHA256="$expected"
}

toolkit_verify_release() {
  local archive="$1" checksum="$2" temp_dir manifest_version file_version
  temp_dir="$(mktemp -d /tmp/toolkit-inspect.XXXXXXXX)" || toolkit_die 'cannot create release verification directory'
  toolkit_register_temp_path "$temp_dir"
  toolkit_stage_archive "$archive" "$checksum" "$temp_dir"
  toolkit_check_archive "$temp_dir/release.tar.gz" "$temp_dir/release.tar.gz.sha256"
  mkdir -m 0700 "$temp_dir/payload" || toolkit_die 'cannot prepare release inspection directory'
  tar -xzf "$temp_dir/release.tar.gz" --no-same-owner --no-same-permissions -C "$temp_dir/payload" || toolkit_die 'cannot extract verified release for inspection'
  toolkit_manifest_parse "$temp_dir/payload/toolkit/MANIFEST"
  manifest_version="${TOOLKIT_MANIFEST[VERSION]}"
  IFS= read -r file_version <"$temp_dir/payload/toolkit/VERSION" || toolkit_die 'release VERSION file is unreadable'
  [[ "$file_version" == "$manifest_version" ]] || toolkit_die 'release VERSION file does not match its manifest'
  rm -rf -- "$temp_dir"
  toolkit_log info "release verified version=$manifest_version source_commit=${TOOLKIT_MANIFEST[SOURCE_COMMIT]}"
}

toolkit_install_release_locked() {
  local archive="$1" checksum="$2" preflight staging release_path expected file version file_version
  for file in /opt/toolkit /opt/toolkit/releases /opt/toolkit/.staging; do
    [[ ! -L "$file" ]] || toolkit_die "toolkit installation path must not be a symlink: $file"
  done
  preflight="$(mktemp -d /tmp/toolkit-install.XXXXXXXX)" || toolkit_die 'cannot create release preflight directory'
  toolkit_register_temp_path "$preflight"
  toolkit_stage_archive "$archive" "$checksum" "$preflight"
  toolkit_check_archive "$preflight/release.tar.gz" "$preflight/release.tar.gz.sha256"
  expected="$TOOLKIT_STAGED_ARCHIVE_SHA256"
  mkdir -m 0700 "$preflight/payload" || toolkit_die 'cannot prepare release extraction directory'
  tar -xzf "$preflight/release.tar.gz" --no-same-owner --no-same-permissions -C "$preflight/payload" || toolkit_die 'cannot extract release archive'
  toolkit_manifest_parse "$preflight/payload/toolkit/MANIFEST"
  version="${TOOLKIT_MANIFEST[VERSION]}"
  IFS= read -r file_version <"$preflight/payload/toolkit/VERSION" || toolkit_die 'release VERSION file is unreadable'
  [[ "$file_version" == "$version" ]] || toolkit_die 'release VERSION file does not match its manifest'
  release_path="/opt/toolkit/releases/$version"

  if [[ -e "$release_path" || -L "$release_path" ]]; then
    [[ -d "$release_path" && ! -L "$release_path" && -f "$release_path/.archive.sha256" && ! -L "$release_path/.archive.sha256" ]] || toolkit_die "release path already exists with incomplete content: $release_path"
    [[ "$(cat -- "$release_path/.archive.sha256")" == "$expected" ]] || toolkit_die "refusing to overwrite version $version with different bytes"
    toolkit_log info "matching release already installed version=$version"
    return 0
  fi

  install -d -o root -g root -m 0755 /opt/toolkit /opt/toolkit/releases /opt/toolkit/.staging || toolkit_die 'cannot prepare toolkit installation directories'
  staging="$(mktemp -d /opt/toolkit/.staging/release.XXXXXXXX)" || toolkit_die 'cannot create release staging directory'
  toolkit_register_temp_path "$staging"
  mkdir -m 0700 "$staging/payload" || toolkit_die 'cannot prepare release staging payload'
  cp -a -- "$preflight/payload/toolkit" "$staging/payload/" || toolkit_die 'cannot stage verified release payload'
  printf '%s\n' "$expected" >"$staging/payload/toolkit/.archive.sha256" || toolkit_die 'cannot record installed release checksum'
  chown -R root:root "$staging/payload/toolkit" || toolkit_die 'cannot set release ownership'
  find "$staging/payload/toolkit" -type d -exec chmod 0555 -- {} + || toolkit_die 'cannot protect release directories'
  find "$staging/payload/toolkit" -type f -perm /111 -exec chmod 0555 -- {} + || toolkit_die 'cannot protect executable release files'
  find "$staging/payload/toolkit" -type f ! -perm /111 -exec chmod 0444 -- {} + || toolkit_die 'cannot protect release files'
  mv -T -- "$staging/payload/toolkit" "$release_path" || toolkit_die 'cannot publish toolkit release directory'
  rm -rf -- "$staging/payload"
  rmdir -- "$staging" || toolkit_die 'cannot remove release staging directory'
  toolkit_log info "release installed version=$version active=false"
}

toolkit_activate_release_locked() {
  local version="$1" release_path current_target current_version temporary_link previous_link launcher_path launcher_temp
  toolkit_validate_version "$version" || toolkit_die 'activate requires a semantic major.minor.patch version'
  release_path="/opt/toolkit/releases/$version"
  [[ -d "$release_path" && ! -L "$release_path" && -f "$release_path/MANIFEST" && ! -L "$release_path/MANIFEST" && -x "$release_path/bin/toolkit" && ! -L "$release_path/bin/toolkit" ]] || toolkit_die "toolkit release is not installed: $version"
  toolkit_manifest_parse "$release_path/MANIFEST"
  [[ "${TOOLKIT_MANIFEST[VERSION]}" == "$version" ]] || toolkit_die 'installed release directory and manifest do not match'
  launcher_path='/usr/local/bin/toolkit'
  if [[ -e "$launcher_path" || -L "$launcher_path" ]]; then
    [[ -L "$launcher_path" && "$(readlink -- "$launcher_path")" == /opt/toolkit/current/bin/toolkit ]] || toolkit_die "$launcher_path exists and is not the toolkit launcher"
  fi
  install -d -o root -g root -m 0755 /opt/toolkit

  if [[ -e /opt/toolkit/current || -L /opt/toolkit/current ]]; then
    [[ -L /opt/toolkit/current ]] || toolkit_die '/opt/toolkit/current exists but is not a symlink'
    current_target="$(readlink -- /opt/toolkit/current)" || toolkit_die 'cannot read current toolkit symlink'
    [[ "$current_target" =~ ^releases/(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$ ]] || toolkit_die 'current toolkit symlink has an unexpected target'
    [[ -d "/opt/toolkit/$current_target" ]] || toolkit_die 'current toolkit release target is missing'
    current_version="${current_target#releases/}"
    if [[ "$current_version" == "$version" ]]; then
      toolkit_log info "release already active version=$version"
      return 0
    fi
    previous_link="/opt/toolkit/.previous.$$"
    ln -s -- "$current_target" "$previous_link" || toolkit_die 'cannot prepare previous toolkit symlink'
    toolkit_register_temp_path "$previous_link"
    mv -Tf -- "$previous_link" /opt/toolkit/previous || toolkit_die 'cannot publish previous toolkit symlink'
  fi

  temporary_link="/opt/toolkit/.current.$$"
  ln -s -- "releases/$version" "$temporary_link" || toolkit_die 'cannot prepare current toolkit symlink'
  toolkit_register_temp_path "$temporary_link"
  mv -Tf -- "$temporary_link" /opt/toolkit/current || toolkit_die 'cannot activate toolkit release'
  if [[ ! -L "$launcher_path" ]]; then
    install -d -o root -g root -m 0755 /usr/local/bin || toolkit_die 'cannot prepare stable launcher directory'
    launcher_temp="/usr/local/bin/.toolkit.$$"
    ln -s -- /opt/toolkit/current/bin/toolkit "$launcher_temp" || toolkit_die 'cannot prepare stable toolkit launcher'
    toolkit_register_temp_path "$launcher_temp"
    mv -Tf -- "$launcher_temp" "$launcher_path" || toolkit_die 'cannot publish stable toolkit launcher'
  fi
  toolkit_log info "release activated version=$version previous=${current_version:-none}"
}
