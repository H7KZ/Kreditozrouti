#!/usr/bin/env bash

toolkit_log() {
  local level="$1"
  shift
  printf 'toolkit event=%s version=%s message=%s\n' "$level" "${TOOLKIT_VERSION:-unknown}" "$*" >&2
}

toolkit_die() {
  toolkit_log error "$*"
  exit 1
}

toolkit_require_root() {
  if ((EUID != 0)); then
    toolkit_die 'this command requires root'
  fi
}

toolkit_resolve_root() {
  local entry="$1"
  local resolved
  resolved="$(realpath -e -- "$entry")" || toolkit_die 'cannot resolve toolkit entrypoint'
  printf '%s\n' "$(dirname -- "$(dirname -- "$resolved")")"
}

toolkit_validate_version() {
  [[ "$1" =~ ^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$ ]]
}
