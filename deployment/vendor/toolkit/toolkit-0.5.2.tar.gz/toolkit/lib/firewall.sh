#!/usr/bin/env bash

toolkit_firewall_block() {
  printf 'firewall_action=blocked reason=%s\n' "$*" >&2
  return 1
}

toolkit_firewall_plan() {
  local ingress_mode="$1" server_version='' server_major='' backend='' manager=''
  local command_name version_output

  [[ "$ingress_mode" == direct || "$ingress_mode" == cloudflare ]] || {
    toolkit_firewall_block invalid_ingress_mode
    return 1
  }
  if [[ "$ingress_mode" == cloudflare ]]; then
    toolkit_firewall_block cloudflare_range_catalog_unimplemented
    return 1
  fi

  command -v docker >/dev/null 2>&1 || {
    toolkit_firewall_block docker_cli_missing
    return 1
  }
  command -v systemctl >/dev/null 2>&1 || {
    toolkit_firewall_block systemctl_missing
    return 1
  }

  server_version="$(docker version --format '{{.Server.Version}}' 2>/dev/null)" || {
    toolkit_firewall_block docker_daemon_unavailable
    return 1
  }
  [[ "$server_version" =~ ^(0|[1-9][0-9]{0,2})\.(0|[1-9][0-9]{0,2})\.(0|[1-9][0-9]{0,2})([-+][A-Za-z0-9.-]+)?$ ]] || {
    toolkit_firewall_block docker_server_version_unrecognized
    return 1
  }
  server_major="${BASH_REMATCH[1]}"

  backend="$(docker info --format '{{.FirewallBackend.Driver}}' 2>/dev/null)" || backend=''
  case "$backend" in
  iptables) ;;
  nftables)
    toolkit_firewall_block 'unsupported_docker_backend backend=nftables'
    return 1
    ;;
  '')
    if ((server_major < 29)); then
      backend=iptables
    else
      toolkit_firewall_block docker_firewall_backend_unknown
      return 1
    fi
    ;;
  *)
    toolkit_firewall_block unsupported_docker_backend
    return 1
    ;;
  esac

  for manager in ufw firewalld nftables; do
    if systemctl is-active --quiet "$manager" >/dev/null 2>&1; then
      toolkit_firewall_block "active_firewall_manager manager=$manager"
      return 1
    fi
  done

  for command_name in iptables ip6tables iptables-restore ip6tables-restore; do
    command -v "$command_name" >/dev/null 2>&1 || {
      toolkit_firewall_block "required_command_missing command=$command_name"
      return 1
    }
  done

  for command_name in iptables ip6tables; do
    version_output="$("$command_name" --version 2>/dev/null)" || {
      toolkit_firewall_block "firewall_command_failed command=$command_name"
      return 1
    }
    [[ "$version_output" == *'(nf_tables)'* ]] || {
      toolkit_firewall_block "unsupported_iptables_frontend command=$command_name"
      return 1
    }
  done

  iptables -S DOCKER-USER >/dev/null 2>&1 || {
    toolkit_firewall_block 'docker_user_chain_missing family=ipv4'
    return 1
  }
  ip6tables -S DOCKER-USER >/dev/null 2>&1 || {
    toolkit_firewall_block 'docker_user_chain_missing family=ipv6'
    return 1
  }

  printf 'firewall_action=inventory_only mode=direct backend=iptables docker_version=%s docker_user_ipv4=present docker_user_ipv6=present intended_policy=published-host-ports-80-443 persistence=not_installed\n' \
    "$server_version"
}

toolkit_firewall_apply() {
  toolkit_die 'firewall apply is not available; only read-only Docker firewall inventory is implemented'
}
