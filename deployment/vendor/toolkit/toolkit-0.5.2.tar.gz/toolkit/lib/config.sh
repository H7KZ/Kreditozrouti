#!/usr/bin/env bash

declare -gA TOOLKIT_CONFIG=()

toolkit_trim_value() {
  local value="$1"
  value="${value#"${value%%[!$' \t']*}"}"
  value="${value%"${value##*[!$' \t']}"}"
  printf '%s' "$value"
}

toolkit_config_known_key() {
  case "$1" in
  CONFIG_VERSION | HOST_ID | HOST_OWNER | TIMEZONE | SSH_PORT | SWAP_SIZE_GB | SECURITY_UPDATES | AUTO_REBOOT | CLEANUP_TIME | MAINTENANCE_TIME | IMAGE_MIN_AGE_HOURS | PROXY_OWNER | WEB_INGRESS_MODE | CROWDSEC_MODE | NOTIFICATIONS_ENABLED) return 0 ;;
  *) return 1 ;;
  esac
}

toolkit_file_check_utf8() {
  local path="$1"
  local control_bytes
  command -v iconv >/dev/null 2>&1 || toolkit_die 'iconv is required to validate UTF-8 input'
  iconv -f UTF-8 -t UTF-8 "$path" >/dev/null 2>&1 || toolkit_die "file is not valid UTF-8: $path"
  control_bytes="$(LC_ALL=C tr -d '\011\012\015\040-\176\200-\377' <"$path" | wc -c | tr -d '[:space:]')"
  [[ "$control_bytes" == 0 ]] || toolkit_die "file contains a NUL or unsupported control byte: $path"
}

toolkit_config_parse() {
  local path="$1"
  local line line_number=0 key value

  [[ -f "$path" && -r "$path" ]] || toolkit_die "host config is not a readable regular file: $path"
  toolkit_file_check_utf8 "$path"
  TOOLKIT_CONFIG=()

  while IFS= read -r line || [[ -n "$line" ]]; do
    ((line_number += 1))
    line="${line%$'\r'}"
    [[ "$line" =~ ^[[:space:]]*$ ]] && continue
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ "$line" == *=* ]] || toolkit_die "host config line $line_number must be KEY=value"

    key="${line%%=*}"
    value="${line#*=}"
    [[ "$key" =~ ^[A-Z][A-Z0-9_]*$ ]] || toolkit_die "host config line $line_number has an invalid key"
    toolkit_config_known_key "$key" || toolkit_die "host config line $line_number has unknown key $key"
    [[ -z "${TOOLKIT_CONFIG[$key]+present}" ]] || toolkit_die "host config line $line_number duplicates $key"
    value="$(toolkit_trim_value "$value")"
    [[ "$value" != *$'\r'* ]] || toolkit_die "host config line $line_number contains an embedded carriage return"
    TOOLKIT_CONFIG["$key"]="$value"
  done <"$path"

  toolkit_config_validate
}

toolkit_config_required() {
  local key
  for key in CONFIG_VERSION HOST_ID HOST_OWNER TIMEZONE SSH_PORT SWAP_SIZE_GB SECURITY_UPDATES AUTO_REBOOT CLEANUP_TIME MAINTENANCE_TIME IMAGE_MIN_AGE_HOURS PROXY_OWNER WEB_INGRESS_MODE CROWDSEC_MODE NOTIFICATIONS_ENABLED; do
    [[ -n "${TOOLKIT_CONFIG[$key]+present}" ]] || toolkit_die "host config is missing required key $key"
  done
}

toolkit_validate_slug() {
  [[ "$1" =~ ^[a-z0-9]+(-[a-z0-9]+)*$ ]]
}

toolkit_validate_uint() {
  local value="$1" min="$2" max="$3"
  [[ "$value" =~ ^(0|[1-9][0-9]*)$ ]] || return 1
  ((${#value} <= 5)) || return 1
  ((value >= min && value <= max))
}

toolkit_validate_bool() {
  [[ "$1" == true || "$1" == false ]]
}

toolkit_validate_timezone() {
  local timezone="$1" zoneinfo_root='/usr/share/zoneinfo' resolved
  [[ "$timezone" =~ ^[A-Za-z0-9_+-]+(/[A-Za-z0-9_+-]+)*$ ]] || return 1
  [[ -f "$zoneinfo_root/$timezone" ]] || return 1
  resolved="$(realpath -e -- "$zoneinfo_root/$timezone")" || return 1
  [[ "$resolved" == "$zoneinfo_root/"* ]]
}

toolkit_config_validate() {
  local key
  toolkit_config_required
  [[ "${TOOLKIT_CONFIG[CONFIG_VERSION]}" == 1 ]] || toolkit_die "unsupported CONFIG_VERSION: ${TOOLKIT_CONFIG[CONFIG_VERSION]}"

  for key in HOST_ID HOST_OWNER PROXY_OWNER; do
    toolkit_validate_slug "${TOOLKIT_CONFIG[$key]}" || toolkit_die "$key must be a lowercase slug"
  done
  toolkit_validate_timezone "${TOOLKIT_CONFIG[TIMEZONE]}" || toolkit_die 'TIMEZONE must name a file under /usr/share/zoneinfo'
  toolkit_validate_uint "${TOOLKIT_CONFIG[SSH_PORT]}" 1 65535 || toolkit_die 'SSH_PORT must be an integer from 1 through 65535'
  toolkit_validate_uint "${TOOLKIT_CONFIG[SWAP_SIZE_GB]}" 0 64 || toolkit_die 'SWAP_SIZE_GB must be an integer from 0 through 64'
  [[ "${TOOLKIT_CONFIG[SECURITY_UPDATES]}" == true ]] || toolkit_die 'SECURITY_UPDATES must be true in schema v1'
  [[ "${TOOLKIT_CONFIG[AUTO_REBOOT]}" == false ]] || toolkit_die 'AUTO_REBOOT=true is not supported by schema v1'
  [[ "${TOOLKIT_CONFIG[CLEANUP_TIME]}" =~ ^([01][0-9]|2[0-3]):[0-5][0-9]$ ]] || toolkit_die 'CLEANUP_TIME must use 24-hour HH:MM'
  [[ "${TOOLKIT_CONFIG[MAINTENANCE_TIME]}" =~ ^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)[[:space:]]\*-\*-\*[[:space:]]([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$ ]] || toolkit_die 'MAINTENANCE_TIME must use the v1 form: Day *-*-* HH:MM:SS'
  toolkit_validate_uint "${TOOLKIT_CONFIG[IMAGE_MIN_AGE_HOURS]}" 1 8760 || toolkit_die 'IMAGE_MIN_AGE_HOURS must be an integer from 1 through 8760'
  toolkit_validate_bool "${TOOLKIT_CONFIG[NOTIFICATIONS_ENABLED]}" || toolkit_die 'NOTIFICATIONS_ENABLED must be true or false'
  [[ "${TOOLKIT_CONFIG[WEB_INGRESS_MODE]}" == direct || "${TOOLKIT_CONFIG[WEB_INGRESS_MODE]}" == cloudflare ]] || toolkit_die 'WEB_INGRESS_MODE must be direct or cloudflare'
  [[ "${TOOLKIT_CONFIG[CROWDSEC_MODE]}" == detection || "${TOOLKIT_CONFIG[CROWDSEC_MODE]}" == enforcement ]] || toolkit_die 'CROWDSEC_MODE must be detection or enforcement'
}
