#!/usr/bin/env bash

toolkit_assert_supported_platform() {
  local os_release="${1:-/etc/os-release}"
  local os_id=''
  local version_id=''
  local machine="${2:-}"

  [[ -r "$os_release" ]] || toolkit_die "OS release file is unavailable: $os_release"
  os_id="$(sed -n 's/^ID=\([A-Za-z0-9._-]*\)$/\1/p' "$os_release")"
  version_id="$(sed -n 's/^VERSION_ID="\{0,1\}\([0-9.]*\)"\{0,1\}$/\1/p' "$os_release")"
  [[ -n "$machine" ]] || machine="$(uname -m)" || toolkit_die 'cannot determine host architecture'

  [[ "$os_id" == ubuntu && "$version_id" == 26.04 ]] || toolkit_die "supported hosts are Ubuntu 26.04; found ${os_id:-unknown} ${version_id:-unknown}"
  [[ "$machine" == x86_64 ]] || toolkit_die "supported architecture is amd64; found $machine"
}
