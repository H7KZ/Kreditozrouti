# VPS toolkit

This is the side-by-side v1 foundation for the planned Ubuntu 26.04 host toolkit. It is not
installed on the production VPS and does not replace the current `scripts/`, proxy or boot units.

The current commands are `version`, `validate`, `plan`, `apply`, `status`, `operation`, `verify-release`, `with-lock`, `install`, and `activate`.
`validate` parses a host configuration without applying it. `plan` reports the parsed values and
the host/platform limits and a read-only swap action. The file helper writes through a validated
same-directory temporary and atomic rename. `with-lock` runs one command under the shared host lock and, optionally,
one repository/environment lock. `install` validates release inputs before changing the installation
tree and stages a checksummed release without activating it; `activate` changes the installed release
symlink only. `operation start`/`finish` publish atomic root-only operation records; `with-lock --action`
records lock-wrapped work automatically. `apply --config <path> --module swap` provisions only the
explicitly selected swap module: it preserves active swap, refuses implicit resize, supports ext4/xfs,
requires requested size plus 1 GiB free, and resumes a valid inactive `/swapfile`. It does not change
sysctl, zswap, or boot settings. Other provisioning modules remain unimplemented.

## Local use

```sh
toolkit/bin/toolkit version
toolkit/bin/toolkit validate --config toolkit/config/host.conf.example
toolkit/bin/toolkit plan --config toolkit/config/host.conf.example
toolkit/bin/toolkit apply --config toolkit/config/host.conf.example --module swap
```

Configuration uses literal `KEY=value` lines. It is not sourced or expanded by a shell. See
[`config/host.conf.example`](config/host.conf.example) and the frozen
[`contracts/handoff-v1.md`](contracts/handoff-v1.md).

Package a committed toolkit release with:

```sh
toolkit/packaging/build-release.sh <output-directory>
```

The adjacent SHA-256 file detects corruption; it does not authenticate who published the archive.
Release provenance must come from a reviewed source and authenticated distribution channel.
From a consuming repository checkout, install the exact pinned bundle inactive, then activate it
explicitly:

```sh
sudo bash deployment/install-toolkit.sh
sudo /opt/toolkit/releases/<pinned-version>/bin/toolkit activate <pinned-version>
```

After activation, `/usr/local/bin/toolkit` points to the active release.
