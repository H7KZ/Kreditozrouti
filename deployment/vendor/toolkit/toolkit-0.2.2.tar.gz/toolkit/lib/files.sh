#!/usr/bin/env bash

declare -ga TOOLKIT_TEMP_PATHS=()

toolkit_register_temp_path() {
  TOOLKIT_TEMP_PATHS+=("$1")
}

toolkit_cleanup_temp_paths() {
  local path
  for path in "${TOOLKIT_TEMP_PATHS[@]}"; do
    case "$path" in
    /tmp/toolkit-validation.* | /tmp/toolkit-inspect.* | /tmp/toolkit-install.* | /opt/toolkit/.staging/release.*)
      [[ -d "$path" && ! -L "$path" ]] && rm -rf -- "$path"
      ;;
    /opt/toolkit/.current.* | /opt/toolkit/.previous.* | /usr/local/bin/.toolkit.*)
      [[ -L "$path" ]] && rm -f -- "$path"
      ;;
    */.toolkit-atomic.*)
      [[ -f "$path" && ! -L "$path" ]] && rm -f -- "$path"
      ;;
    *) toolkit_log error 'refusing to clean an unregistered temporary path' ;;
    esac
  done
  TOOLKIT_TEMP_PATHS=()
}

toolkit_atomic_write_file() {
  local target="$1" mode="$2" parent canonical_parent temporary parent_mode parent_owner mode_value
  [[ "$target" == /* && "$target" != *'/../'* && "$target" != */.. ]] || toolkit_die 'atomic file target must be an absolute normalized path'
  [[ "$mode" =~ ^(0[0-7]{3}|[0-7]{3,4})$ ]] || toolkit_die 'atomic file mode must be an octal mode'
  mode_value=$((8#$mode))
  (((mode_value & 07000) == 0 && (mode_value & 0022) == 0 && (mode_value & 0111) == 0)) || toolkit_die 'atomic file mode must not grant execute, group/world write, or special permissions'
  parent="$(dirname -- "$target")"
  [[ -d "$parent" && ! -L "$parent" ]] || toolkit_die 'atomic file parent must be an existing real directory'
  canonical_parent="$(realpath -e -- "$parent")" || toolkit_die 'cannot resolve atomic file parent'
  [[ "$canonical_parent" == "$parent" ]] || toolkit_die 'atomic file parent path must not contain symlinks or dot segments'
  parent_mode="$(stat -c '%a' -- "$parent")" || toolkit_die 'cannot inspect atomic file parent permissions'
  parent_mode="${parent_mode: -3}"
  (((8#$parent_mode & 0022) == 0)) || toolkit_die 'atomic file parent must not be group- or world-writable'
  parent_owner="$(stat -c '%u' -- "$parent")" || toolkit_die 'cannot inspect atomic file parent owner'
  [[ "$parent_owner" == "$EUID" ]] || toolkit_die 'atomic file parent must be owned by the calling user'
  if [[ -e "$target" || -L "$target" ]]; then
    [[ -f "$target" && ! -L "$target" ]] || toolkit_die 'atomic file target must be absent or a regular file'
  fi
  temporary="$(mktemp "$parent/.toolkit-atomic.XXXXXXXX")" || toolkit_die 'cannot create atomic file temporary'
  toolkit_register_temp_path "$temporary"
  cat >"$temporary" || toolkit_die 'cannot write atomic file temporary'
  chmod "$mode" "$temporary" || toolkit_die 'cannot set atomic file mode'
  mv -fT -- "$temporary" "$target" || toolkit_die 'cannot atomically publish file'
}
