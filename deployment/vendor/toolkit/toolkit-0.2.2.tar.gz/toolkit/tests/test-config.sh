#!/usr/bin/env bash
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
toolkit="$toolkit_root/bin/toolkit"
fixture="$toolkit_root/config/host.conf.example"
temporary="$(mktemp -d)"
trap 'rm -rf -- "$temporary"' EXIT

"$toolkit" validate --config "$fixture" >/dev/null
"$toolkit" plan --config "$fixture" | grep -q 'plan_only=true.*required_platform=ubuntu-26.04'
{
  printf '# Příliš žluťoučký kůň\n'
  cat "$fixture"
} >"$temporary/utf8-comment.conf"
"$toolkit" validate --config "$temporary/utf8-comment.conf" >/dev/null
printf '\377' >"$temporary/invalid-utf8.conf"
if "$toolkit" validate --config "$temporary/invalid-utf8.conf" >/dev/null 2>&1; then
  printf 'expected malformed UTF-8 input to fail validation\n' >&2
  exit 1
fi
printf '\000' >"$temporary/nul.conf"
if "$toolkit" validate --config "$temporary/nul.conf" >/dev/null 2>&1; then
  printf 'expected NUL input to fail validation\n' >&2
  exit 1
fi

sed 's/CONFIG_VERSION=1/CONFIG_VERSION=2/' "$fixture" >"$temporary/unsupported.conf"
if "$toolkit" validate --config "$temporary/unsupported.conf" >/dev/null 2>&1; then
  printf 'expected unsupported config version to fail\n' >&2
  exit 1
fi

sed 's/SSH_PORT=22/SSH_PORT=999999999999999999999999999999999999/' "$fixture" >"$temporary/overflow.conf"
if "$toolkit" validate --config "$temporary/overflow.conf" >/dev/null 2>&1; then
  printf 'expected oversized integer to fail validation\n' >&2
  exit 1
fi

sed 's/HOST_ID=shared-vps-01/UNKNOWN_KEY=value/' "$fixture" >"$temporary/unknown.conf"
if "$toolkit" validate --config "$temporary/unknown.conf" >/dev/null 2>&1; then
  printf 'expected unknown key to fail validation\n' >&2
  exit 1
fi

sed 's/SSH_PORT=22/SSH_PORT=2222/' "$fixture" | sed 's/$/\r/' >"$temporary/crlf.conf"
"$toolkit" validate --config "$temporary/crlf.conf" >/dev/null

cat "$fixture" <(printf 'HOST_ID=second\n') >"$temporary/duplicate.conf"
if "$toolkit" validate --config "$temporary/duplicate.conf" >/dev/null 2>&1; then
  printf 'expected duplicate key to fail\n' >&2
  exit 1
fi

sed 's/SSH_PORT=22/SSH_PORT=$(id)/' "$fixture" >"$temporary/substitution.conf"
if "$toolkit" validate --config "$temporary/substitution.conf" >/dev/null 2>&1; then
  printf 'expected shell substitution text to fail validation\n' >&2
  exit 1
fi

sed 's/AUTO_REBOOT=false/AUTO_REBOOT=true/' "$fixture" >"$temporary/reboot.conf"
if "$toolkit" validate --config "$temporary/reboot.conf" >/dev/null 2>&1; then
  printf 'expected automatic reboot to be rejected\n' >&2
  exit 1
fi

sed 's/TIMEZONE=Europe\/Prague/TIMEZONE=Europe\/\/Prague/' "$fixture" >"$temporary/timezone.conf"
if "$toolkit" validate --config "$temporary/timezone.conf" >/dev/null 2>&1; then
  printf 'expected malformed timezone path to be rejected\n' >&2
  exit 1
fi

sed 's/TIMEZONE=Europe\/Prague/TIMEZONE=Foo\/Bar/' "$fixture" >"$temporary/unknown-timezone.conf"
if "$toolkit" validate --config "$temporary/unknown-timezone.conf" >/dev/null 2>&1; then
  printf 'expected unknown timezone to be rejected\n' >&2
  exit 1
fi

sed 's/SECURITY_UPDATES=true/SECURITY_UPDATES=false/' "$fixture" >"$temporary/security-updates.conf"
if "$toolkit" validate --config "$temporary/security-updates.conf" >/dev/null 2>&1; then
  printf 'expected disabled security updates to be rejected\n' >&2
  exit 1
fi

sed 's/IMAGE_MIN_AGE_HOURS=48/IMAGE_MIN_AGE_HOURS=0/' "$fixture" >"$temporary/image-age.conf"
if "$toolkit" validate --config "$temporary/image-age.conf" >/dev/null 2>&1; then
  printf 'expected a zero image minimum age to be rejected\n' >&2
  exit 1
fi

printf 'toolkit config checks passed\n'
