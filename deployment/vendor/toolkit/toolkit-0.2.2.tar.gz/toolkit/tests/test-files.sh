#!/usr/bin/env bash
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
temporary="$(mktemp -d)"
trap 'rm -rf -- "$temporary"' EXIT
source "$toolkit_root/lib/common.sh"
source "$toolkit_root/lib/files.sh"
trap toolkit_cleanup_temp_paths EXIT

target="$temporary/state.json"
printf '{"state":"ready"}\n' | toolkit_atomic_write_file "$target" 0640
[[ "$(cat -- "$target")" == '{"state":"ready"}' ]]
[[ "$(stat -c '%a' "$target")" == 640 ]]

ln -s "$target" "$temporary/state-link.json"
if (printf 'bad\n' | toolkit_atomic_write_file "$temporary/state-link.json" 0600) >/dev/null 2>&1; then
  printf 'expected symlink target to be rejected\n' >&2
  exit 1
fi

ln -s "$temporary" "$temporary/dir-link"
if (printf 'bad\n' | toolkit_atomic_write_file "$temporary/dir-link/other.json" 0600) >/dev/null 2>&1; then
  printf 'expected symlink parent to be rejected\n' >&2
  exit 1
fi

for unsafe_mode in 0666 0755 4755; do
  if (printf 'bad\n' | toolkit_atomic_write_file "$temporary/unsafe-$unsafe_mode.json" "$unsafe_mode") >/dev/null 2>&1; then
    printf 'expected unsafe atomic file mode to be rejected: %s\n' "$unsafe_mode" >&2
    exit 1
  fi
done

[[ -z "$(find "$temporary" -maxdepth 1 -name '.toolkit-atomic.*' -print -quit)" ]]
printf 'toolkit atomic file checks passed\n'
