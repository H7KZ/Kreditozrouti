# Cross-repository handoff contract v1

Status: frozen implementation contract, 2026-10-10. Source of truth: Infrastructure's
`toolkit/contracts/` directory. Consumer repositories pin a reviewed bundle and may not update the
host's `/opt/toolkit/current` as a side effect.

## Versions

| Contract | v1 value |
| --- | --- |
| Bundle format | `1` |
| Toolkit helper API | `1` |
| Host config schema | `1` |
| Operation status schema | `1` |
| Image protection manifest schema | `1` |
| Backup recovery reference schema | `1` |
| Hosted backup maintenance catalog and snapshot inventory schemas | `1` |
| Qualified development release manifest schema | `1` |

Toolkit releases use semantic versions. The source release manifest carries the exact Git commit,
config/helper versions, Ubuntu version and supported architectures.

## Locks

- Host mutation lock: `/run/lock/toolkit/host.lock`.
- Repository/environment lock: `/run/lock/toolkit/repos/<repository>/<environment>.lock`.
- Repository and environment IDs use lowercase slugs matching `[a-z0-9]+(-[a-z0-9]+)*`.
- Locks are exclusive `flock` locks. Default wait is 300 seconds; callers may request 1-3600 seconds.
- Acquire the host lock first, then the repository/environment lock. Never acquire the host lock
  while holding a repository/environment lock. A timeout is a failed operation; locks are never
  stolen based on age or PID text.
- Host-mutating work must hold the host lock. Deployment, rollback, manual migrations, proxy/toolkit
  changes, image registration/cleanup, and the local consistency portion of backup capture also hold
  the repository/environment lock for the affected app. Shared proxy and host-only maintenance use
  the host lock. The current Infrastructure proxy workflow additionally takes the
  `infrastructure/production` repository lock and records a `proxy` operation; acquire it only
  after the host lock.
- Backup capture releases both locks once the complete consistent local artifact set is closed.
  Off-site transfer and hosted retention maintenance run without VPS locks.
- `toolkit with-lock` starts a command while holding the declared locks and returns its exit status.
  Commands must not background work that outlives the lock wrapper.
- Toolkit release install/activation use repository `infrastructure`, environment `infrastructure`,
  after the host lock. Host-only maintenance uses only the host lock. A recorded shared-proxy action
  uses the host lock followed by its declared `infrastructure/production` repository lock.

The initial implementation uses root-owned lock files and therefore requires a root SSH command
for lock-wrapped host operations. A later deploy-identity module may grant a dedicated group access
without changing these paths or the acquisition order.

## Operation outcome

Mutating provisioning, deployment, proxy, backup, cleanup and maintenance operations publish a JSON
status record with `schema_version`, `operation_id`, `repository`,
`environment`, `action`, `state`, `started_at`, `finished_at`, `toolkit_version`, and optional
`release_id` and `failure_phase`. `state` is `running`, `succeeded`, `failed`, or `interrupted`;
timestamps are UTC RFC 3339. Updates are atomic replacements. Status records contain no credentials
or secret values. Deployment and backup records may add namespaced fields, but cannot redefine these
fields or states. The toolkit publishes root-only records under
`/var/lib/toolkit/operations/<repository>/<environment>/<operation-id>.json`. The `operation start`
and `operation finish` commands write individual records; `with-lock --action` also records the
operation around lock acquisition and command execution. A process interrupted before it can publish
its terminal update leaves a `running` record for the operator or hosted maintainer to reconcile.
Toolkit install and activation use action `toolkit`.

## Shared proxy identities

The Infrastructure Traefik stack is the active proxy owner on the shared VPS. Its Compose project is
`global`. These external Docker network names are stable contract values:

- `public-network` - app-facing proxy network used by all three repositories.
- `traefik-socket-proxy-network` - Traefik to socket-proxy only.
- `traefik-crowdsec-network` - Traefik to CrowdSec only.
- `infrastructure-monitoring-network` - Infrastructure-owned monitoring access.

The app-facing middleware names are also stable. Global entrypoint chain, in order:
`crowdsec@file`, `www-redirect@file`, `rate-limit@file`, `security-headers@file`, `compress@file`.
Optional file-provider names: `admin-rate-limit@file`, `auth-rate-limit@file`, `in-flight-req@file`,
`retry@file`, `cloudflare-only@file`, `deny-all@file`, `secure-chain@file`,
`auth-endpoint-chain@file`, `admin-chain@file`. Docker-provider names such as the Traefik dashboard
allowlist/auth and app-local buffering middleware are not shared names.

Do not rename a shared network or middleware without a contract version change and an explicit
migration plan. On the current VPS, Infrastructure alone installs or changes the active proxy.

## Backup ownership inventory

`backup-recovery-inventory-v1.md` is the static source-to-owner and recovery-dependency map. It is
versioned with this toolkit bundle. It reflects repository configuration and capture adapters, not a
live production inventory; verify it read-only against Docker before enabling capture timers or
maintenance.

## Image protection and backup recovery references

`image-protection-v1.schema.json` is a data-only local host manifest. It identifies each repository,
environment, current/rollback/candidate release, the exact digest in its registry reference and the
local Docker image ID.
Only Docker image IDs are eligible for local cleanup. Missing, malformed or stale protection data
causes a safe skip; it never broadens deletion. Local cache cleanup does not delete registry content.

`backup-recovery-reference-v1.schema.json` is published by hosted backup maintenance only after a
complete set is accepted; `restore_validated` and `last_good` are assigned by that trusted maintainer,
not asserted by the VPS writer. A reference records the Kopia snapshot and manifest checksum plus the
release/config/toolkit/proxy/image dependencies needed to restore it. Preserve every digest/bundle
referenced by an unexpired or last-good recovery set. Last-good references remain protected past the
ten-day logical window while capture or restore verification is unhealthy.

`backup-maintenance-catalog-v1.schema.json` and `backup-snapshot-inventory-v1.schema.json` define
the inputs to Infrastructure's offline expiration planner. The planner freezes expiration on stale
health evidence, incomplete recovery dependencies, or any catalog/inventory mismatch. It does not
authenticate inputs or execute Kopia/B2 mutations; hosted publication, credentials, monitoring, and
disposable proof remain separate gates. Maintenance inputs accept only the `production` environment
for all three repository identities, including Infrastructure; the repository field identifies the
owner. The trusted publisher owns atomic rotation of exactly one `last_good` reference per bucket
after restore validation. `backup-validation-evidence-v1.schema.json` binds a restore result to the
exact repository, environment, snapshot, backup set, manifest hash, and validation time. The offline
catalog candidate builder checks those fields and emits an expected prior-catalog hash for future
compare-and-swap publication. The evidence remains an assertion until a trusted hosted validator
authenticates its provenance; `validator_id` and hashes alone are not proof.

`development-release-manifest-v1.schema.json` describes the immutable GitHub Actions artifact emitted
only after the complete production-capable development image set deploys and passes Compose health
checks. It binds every required service digest to the source commit, workflow path, run ID and run attempt. Production
promotion validates the originating successful development run, then deploys selected services from
that complete set by digest. Ohlidame's development-only Test shop is excluded. The artifact is a
qualification handoff, not a long-term release catalog; backup recovery references retain dependencies
beyond the artifact retention window.

Remote registry retention consumes the union of deployment rollback references and trusted backup
recovery references. Missing or unreadable reference input disables remote deletion. It is independent
of local Docker image cleanup. No registry deletion implementation is enabled by this contract alone.
