#!/usr/bin/env bash

toolkit_swap_error() {
  toolkit_log error "$*"
  return 1
}

toolkit_swap_active_summary() {
  local path="$1" name size_kib count=0 total_kib=0
  while read -r name _ size_kib _ _; do
    [[ "$name" == Filename ]] && continue
    [[ -n "$name" ]] || continue
    [[ "$size_kib" =~ ^[0-9]+$ && ${#size_kib} -le 18 ]] || toolkit_swap_error 'active swap table contains an invalid size' || return 1
    ((count += 1))
    ((total_kib += size_kib))
    ((total_kib >= 0)) || toolkit_swap_error 'active swap size overflowed' || return 1
  done < <(tail -n +2 -- "$path")
  printf '%s %s\n' "$count" "$total_kib"
}

toolkit_swap_fstab_validate() {
  local fstab="$1/fstab" entries entry_count
  [[ -f "$fstab" && ! -L "$fstab" && -r "$fstab" ]] || {
    toolkit_swap_error 'fstab must be an existing readable regular file before swap apply'
    return 1
  }
  entries="$(awk '!/^[[:space:]]*#/ && $1 == "/swapfile" { print }' "$fstab")" || {
    toolkit_swap_error 'cannot inspect existing swapfile fstab entries'
    return 1
  }
  if [[ -n "$entries" ]]; then
    entry_count="$(printf '%s\n' "$entries" | wc -l | tr -d '[:space:]')" || {
      toolkit_swap_error 'cannot count existing swapfile fstab entries'
      return 1
    }
    [[ "$entries" == '/swapfile none swap sw 0 0' && "$entry_count" == 1 ]] || {
      toolkit_swap_error 'fstab has a conflicting or duplicate /swapfile entry'
      return 1
    }
  fi
}

toolkit_swap_fstab_ensure() {
  local etc_dir="$1"
  local fstab="$etc_dir/fstab" entry='/swapfile none swap sw 0 0'
  local entries mode uid_gid process_uid_gid temporary last_byte
  [[ -f "$fstab" && ! -L "$fstab" ]] || {
    toolkit_swap_error 'fstab must be an existing regular file before swap apply'
    return 1
  }
  entries="$(awk '!/^[[:space:]]*#/ && $1 == "/swapfile" { print }' "$fstab")" || {
    toolkit_swap_error 'cannot inspect existing swapfile fstab entries'
    return 1
  }
  if [[ -n "$entries" ]]; then
    [[ "$entries" == "$entry" ]] || {
      toolkit_swap_error 'fstab already has a conflicting /swapfile entry'
      return 1
    }
    [[ "$(printf '%s\n' "$entries" | wc -l | tr -d '[:space:]')" == 1 ]] || {
      toolkit_swap_error 'fstab has duplicate /swapfile entries'
      return 1
    }
    return 0
  fi

  mode="$(stat -c '%a' -- "$fstab")" || {
    toolkit_swap_error 'cannot inspect fstab permissions'
    return 1
  }
  mode="0$mode"
  uid_gid="$(stat -c '%u:%g' -- "$fstab")" || {
    toolkit_swap_error 'cannot inspect fstab ownership'
    return 1
  }
  process_uid_gid="$(id -u):$(id -g)" || {
    toolkit_swap_error 'cannot inspect process ownership'
    return 1
  }
  [[ "$uid_gid" == "$process_uid_gid" ]] || {
    toolkit_swap_error 'fstab owner/group differ from the apply user; refusing to change ownership'
    return 1
  }
  temporary="$(mktemp "$etc_dir/.toolkit-swap-fstab.XXXXXXXX")" || {
    toolkit_swap_error 'cannot create fstab update temporary'
    return 1
  }
  toolkit_register_temp_path "$temporary"
  cat -- "$fstab" >"$temporary" || {
    toolkit_swap_error 'cannot stage current fstab contents'
    return 1
  }
  if [[ -s "$temporary" ]]; then
    last_byte="$(tail -c 1 -- "$temporary" | od -An -t x1 | tr -d '[:space:]')" || {
      toolkit_swap_error 'cannot inspect final fstab byte'
      return 1
    }
    [[ "$last_byte" == 0a ]] || printf '\n' >>"$temporary" || {
      toolkit_swap_error 'cannot terminate existing fstab line'
      return 1
    }
  fi
  printf '%s\n' "$entry" >>"$temporary" || {
    toolkit_swap_error 'cannot add swapfile entry to staged fstab'
    return 1
  }
  chmod "$mode" "$temporary" || {
    toolkit_swap_error 'cannot preserve fstab permissions'
    return 1
  }
  chown "$uid_gid" "$temporary" || {
    toolkit_swap_error 'cannot preserve fstab ownership'
    return 1
  }
  toolkit_atomic_write_file_try "$fstab" "$mode" <"$temporary" || {
    toolkit_swap_error "cannot atomically update fstab: $TOOLKIT_ATOMIC_WRITE_ERROR"
    return 1
  }
  rm -f -- "$temporary" || {
    toolkit_swap_error 'cannot remove fstab update temporary'
    return 1
  }
}

toolkit_swap_plan() {
  local root="$1" size_gb="$2" canonical_root etc_dir proc_dir swaps swap_file fstab
  local active_summary active_count active_kib expected_bytes expected_kib file_bytes file_type
  local entries filesystem available_kib
  [[ "$size_gb" =~ ^(0|[1-9][0-9]*)$ && ${#size_gb} -le 2 && "$size_gb" -le 64 ]] || {
    printf 'swap_action=blocked reason=invalid_size\n'
    return 0
  }
  [[ "$root" == /* && "$root" != *'/../'* && "$root" != */.. && -d "$root" && ! -L "$root" ]] || {
    printf 'swap_action=unknown reason=invalid_root\n'
    return 0
  }
  canonical_root="$(realpath -e -- "$root")" || {
    printf 'swap_action=unknown reason=root_unavailable\n'
    return 0
  }
  root="$canonical_root"
  if [[ "$root" == / ]]; then
    etc_dir=/etc
    proc_dir=/proc
    swap_file=/swapfile
  else
    etc_dir="$root/etc"
    proc_dir="$root/proc"
    swap_file="$root/swapfile"
  fi
  swaps="$proc_dir/swaps"
  fstab="$etc_dir/fstab"
  [[ -d "$etc_dir" && ! -L "$etc_dir" && -f "$swaps" && ! -L "$swaps" && -r "$swaps" ]] || {
    printf 'swap_action=unknown reason=host_state_unavailable\n'
    return 0
  }
  active_summary="$(toolkit_swap_active_summary "$swaps" 2>/dev/null)" || {
    printf 'swap_action=blocked reason=active_swap_state_invalid\n'
    return 0
  }
  read -r active_count active_kib <<<"$active_summary"
  expected_kib=$((size_gb * 1024 * 1024))
  if ((active_count > 0)); then
    printf 'swap_action=preserve requested_gb=%s active_kib=%s size_matches=%s\n' \
      "$size_gb" "$active_kib" "$([[ "$active_kib" == "$expected_kib" ]] && printf true || printf false)"
    return 0
  fi
  if ((size_gb == 0)); then
    printf 'swap_action=skip requested_gb=0 active_swap=none\n'
    return 0
  fi
  expected_bytes=$((size_gb * 1024 * 1024 * 1024))

  entries="$(awk '!/^[[:space:]]*#/ && $1 == "/swapfile" { print }' "$fstab" 2>/dev/null)" || {
    printf 'swap_action=blocked reason=fstab_unreadable\n'
    return 0
  }
  if [[ -e "$swap_file" || -L "$swap_file" ]]; then
    if [[ ! -f "$swap_file" || -L "$swap_file" ]]; then
      printf 'swap_action=blocked reason=existing_path_not_regular\n'
      return 0
    fi
    file_bytes="$(stat -c '%s' -- "$swap_file" 2>/dev/null)" || {
      printf 'swap_action=blocked reason=swapfile_size_unreadable\n'
      return 0
    }
    file_type="$(blkid -p -s TYPE -o value -- "$swap_file" 2>/dev/null)" || {
      printf 'swap_action=blocked reason=swap_signature_unverified\n'
      return 0
    }
    if [[ "$file_bytes" != "$expected_bytes" || "$file_type" != swap ]]; then
      printf 'swap_action=blocked reason=existing_swapfile_mismatch\n'
      return 0
    fi
    if [[ -n "$entries" && "$entries" != '/swapfile none swap sw 0 0' ]]; then
      printf 'swap_action=blocked reason=fstab_conflict\n'
      return 0
    fi
    printf 'swap_action=resume requested_gb=%s fstab_entry=%s\n' "$size_gb" "$([[ -n "$entries" ]] && printf present || printf add)"
    return 0
  fi
  [[ -z "$entries" || "$entries" == '/swapfile none swap sw 0 0' ]] || {
    printf 'swap_action=blocked reason=fstab_conflict\n'
    return 0
  }
  filesystem="$(findmnt -n -o FSTYPE --target "$root" 2>/dev/null)" || {
    printf 'swap_action=blocked reason=filesystem_unknown\n'
    return 0
  }
  [[ "$filesystem" == ext4 || "$filesystem" == xfs ]] || {
    printf 'swap_action=blocked reason=unsupported_filesystem filesystem=%s\n' "$filesystem"
    return 0
  }
  available_kib="$(df -Pk -- "$root" 2>/dev/null | awk 'NR == 2 { print $4 }')"
  [[ "$available_kib" =~ ^[0-9]+$ ]] || {
    printf 'swap_action=blocked reason=disk_space_unknown\n'
    return 0
  }
  if ((available_kib < expected_kib + 1024 * 1024)); then
    printf 'swap_action=blocked reason=insufficient_space requested_gb=%s available_kib=%s reserve_kib=1048576\n' "$size_gb" "$available_kib"
    return 0
  fi
  command -v fallocate >/dev/null 2>&1 && command -v mkswap >/dev/null 2>&1 && command -v swapon >/dev/null 2>&1 || {
    printf 'swap_action=blocked reason=required_util_linux_tools_missing\n'
    return 0
  }
  printf 'swap_action=create requested_gb=%s filesystem=%s available_kib=%s reserve_kib=1048576\n' \
    "$size_gb" "$filesystem" "$available_kib"
}

toolkit_swap_apply() {
  local root="$1" size_gb="$2" canonical_root etc_dir proc_dir fstab swaps swap_file
  local active_summary active_count active_kib expected_bytes expected_kib available_kib filesystem
  local file_bytes file_owner file_mode file_type temporary

  [[ "$size_gb" =~ ^(0|[1-9][0-9]*)$ && ${#size_gb} -le 2 && "$size_gb" -le 64 ]] || {
    toolkit_swap_error 'swap size must be an integer from 0 through 64 GB'
    return 1
  }
  [[ "$root" == /* && "$root" != *'/../'* && "$root" != */.. && -d "$root" && ! -L "$root" ]] || {
    toolkit_swap_error 'swap root must be an existing absolute real directory'
    return 1
  }
  canonical_root="$(realpath -e -- "$root")" || {
    toolkit_swap_error 'cannot resolve swap root'
    return 1
  }
  root="$canonical_root"
  if [[ "$root" == / ]]; then
    etc_dir=/etc
    proc_dir=/proc
    swap_file=/swapfile
  else
    etc_dir="$root/etc"
    proc_dir="$root/proc"
    swap_file="$root/swapfile"
  fi
  [[ -d "$etc_dir" && ! -L "$etc_dir" && -d "$proc_dir" && ! -L "$proc_dir" ]] || {
    toolkit_swap_error 'swap root requires real etc and proc directories'
    return 1
  }
  fstab="$etc_dir/fstab"
  swaps="$proc_dir/swaps"
  [[ -f "$swaps" && ! -L "$swaps" && -r "$swaps" ]] || {
    toolkit_swap_error 'active swap table is unavailable or unsafe'
    return 1
  }

  active_summary="$(toolkit_swap_active_summary "$swaps")" || return 1
  read -r active_count active_kib <<<"$active_summary"
  expected_kib=$((size_gb * 1024 * 1024))
  if ((active_count > 0)); then
    if ((active_kib == expected_kib)); then
      toolkit_log info "swap_preserved=true requested_gb=$size_gb active_kib=$active_kib matches=true"
    else
      toolkit_log info "swap_preserved=true requested_gb=$size_gb active_kib=$active_kib matches=false resize=explicit"
    fi
    return 0
  fi
  if ((size_gb == 0)); then
    toolkit_log info 'swap_apply=skipped requested_gb=0 active_swap=none'
    return 0
  fi
  expected_bytes=$((size_gb * 1024 * 1024 * 1024))
  toolkit_swap_fstab_validate "$etc_dir" || return 1
  command -v swapon >/dev/null 2>&1 || {
    toolkit_swap_error 'swapon is required to activate swap files'
    return 1
  }

  if [[ -e "$swap_file" || -L "$swap_file" ]]; then
    [[ -f "$swap_file" && ! -L "$swap_file" ]] || {
      toolkit_swap_error 'existing /swapfile is not a regular file'
      return 1
    }
    file_bytes="$(stat -c '%s' -- "$swap_file")" || {
      toolkit_swap_error 'cannot inspect existing /swapfile size'
      return 1
    }
    file_owner="$(stat -c '%u' -- "$swap_file")" || {
      toolkit_swap_error 'cannot inspect existing /swapfile owner'
      return 1
    }
    file_mode="$(stat -c '%a' -- "$swap_file")" || {
      toolkit_swap_error 'cannot inspect existing /swapfile permissions'
      return 1
    }
    file_type="$(blkid -p -s TYPE -o value -- "$swap_file" 2>/dev/null)" || {
      toolkit_swap_error 'existing /swapfile has no verifiable swap signature'
      return 1
    }
    [[ "$file_bytes" == "$expected_bytes" && "$file_owner" == "$EUID" && "$file_mode" == 600 && "$file_type" == swap ]] || {
      toolkit_swap_error 'existing /swapfile does not match the requested size, ownership, permissions, and swap signature'
      return 1
    }
  else
    filesystem="$(findmnt -n -o FSTYPE --target "$root")" || {
      toolkit_swap_error 'cannot determine swap filesystem type'
      return 1
    }
    [[ "$filesystem" == ext4 || "$filesystem" == xfs ]] || {
      toolkit_swap_error "swap file creation supports ext4 and xfs; found $filesystem"
      return 1
    }
    available_kib="$(df -Pk -- "$root" | awk 'NR == 2 { print $4 }')" || {
      toolkit_swap_error 'cannot inspect available disk space'
      return 1
    }
    [[ "$available_kib" =~ ^[0-9]+$ ]] || {
      toolkit_swap_error 'disk space report is malformed'
      return 1
    }
    ((available_kib >= expected_kib + 1024 * 1024)) || {
      toolkit_swap_error "insufficient free space; need requested swap plus a 1 GiB reserve (available_kib=$available_kib)"
      return 1
    }
    command -v fallocate >/dev/null 2>&1 || {
      toolkit_swap_error 'fallocate is required to create swap files'
      return 1
    }
    command -v mkswap >/dev/null 2>&1 || {
      toolkit_swap_error 'mkswap is required to create swap files'
      return 1
    }
    temporary="$(mktemp "$root/swapfile.toolkit.XXXXXXXX")" || {
      toolkit_swap_error 'cannot create temporary swap file'
      return 1
    }
    toolkit_register_temp_path "$temporary"
    chmod 0600 "$temporary" || {
      toolkit_swap_error 'cannot restrict temporary swap file permissions'
      return 1
    }
    fallocate -l "$expected_bytes" "$temporary" || {
      toolkit_swap_error 'cannot allocate requested swap file'
      return 1
    }
    mkswap "$temporary" >/dev/null || {
      toolkit_swap_error 'cannot initialize temporary swap file'
      return 1
    }
    mv -T -- "$temporary" "$swap_file" || {
      toolkit_swap_error 'cannot publish swap file'
      return 1
    }
  fi

  toolkit_swap_fstab_ensure "$etc_dir" || return 1
  if ! swapon -- "$swap_file"; then
    toolkit_swap_error 'swap file and fstab entry are ready but activation failed; rerun apply after resolving the host issue'
    return 1
  fi
  toolkit_log info "swap_apply=succeeded path=/swapfile size_gb=$size_gb filesystem=${filesystem:-existing}"
}
