#!/usr/bin/env bash

toolkit_docker_logging_error() {
  toolkit_log error "$*"
  return 1
}

toolkit_docker_logging_path() {
  local root="$1" canonical_root parent canonical_parent
  [[ "$root" == /* && "$root" != *'/../'* && "$root" != */.. && -d "$root" && ! -L "$root" ]] || return 1
  canonical_root="$(realpath -e -- "$root")" || return 1
  if [[ "$canonical_root" == / ]]; then
    parent=/etc/docker
  else
    parent="$canonical_root/etc/docker"
  fi
  [[ -d "$parent" && ! -L "$parent" ]] || return 1
  canonical_parent="$(realpath -e -- "$parent")" || return 1
  [[ "$canonical_parent" == "$parent" ]] || return 1
  printf '%s/daemon.json\n' "$parent"
}

toolkit_docker_logging_prepare() {
  local path="$1" action="$2"
  python3 - "$path" "$action" <<'PY'
import json
import sys


def fail(reason):
    print(reason, file=sys.stderr)
    raise SystemExit(1)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


path, action = sys.argv[1:]
try:
    if path == "-":
        config = {}
    else:
        with open(path, encoding="utf-8") as config_file:
            config = json.load(config_file, object_pairs_hook=unique_object)
except (OSError, UnicodeError, json.JSONDecodeError, ValueError):
    fail("invalid JSON or duplicate key in Docker daemon configuration")

if not isinstance(config, dict):
    fail("Docker daemon configuration must be a JSON object")

expected_driver = "json-file"
expected_options = {"max-size": "10m", "max-file": "3"}
if "log-driver" in config and config["log-driver"] != expected_driver:
    fail("conflicting log-driver; expected json-file")

options = config.get("log-opts", {})
if not isinstance(options, dict):
    fail("conflicting log-opts; expected a JSON object")
for name, expected in expected_options.items():
    if name in options and options[name] != expected:
        fail(f"conflicting log-opts.{name}; expected {expected}")

updated = dict(config)
updated_options = dict(options)
updated["log-driver"] = expected_driver
updated_options.update(expected_options)
updated["log-opts"] = updated_options

if action == "state":
    print("unchanged" if config == updated else "configure")
elif action == "render":
    print(json.dumps(updated, indent=2, sort_keys=True))
else:
    fail("unsupported Docker logging preparation action")
PY
}

toolkit_docker_logging_plan() {
  local root="$1" path state
  path="$(toolkit_docker_logging_path "$root")" || {
    printf 'docker_logging_action=unknown reason=docker_config_directory_unavailable\n'
    return 0
  }
  if [[ -L "$path" || ( -e "$path" && ! -f "$path" ) ]]; then
    printf 'docker_logging_action=blocked reason=daemon_config_path_unsafe\n'
    return 0
  fi
  if [[ -e "$path" ]]; then
    state="$(toolkit_docker_logging_prepare "$path" state 2>/dev/null)" || {
      printf 'docker_logging_action=blocked reason=invalid_or_conflicting_daemon_config\n'
      return 0
    }
  else
    state=configure
  fi
  printf 'docker_logging_action=%s log_driver=json-file max_size=10m max_files=3\n' "$state"
}

toolkit_docker_logging_apply() {
  local root="$1" path parent canonical_parent parent_owner parent_mode
  local state temporary file_mode file_owner_group source_digest current_digest
  local source_mode source_owner_group current_mode current_owner_group
  local had_file=false

  command -v python3 >/dev/null 2>&1 || {
    toolkit_docker_logging_error 'python3 is required to safely merge Docker daemon JSON'
    return 1
  }
  command -v dockerd >/dev/null 2>&1 || {
    toolkit_docker_logging_error 'dockerd is required to validate daemon configuration'
    return 1
  }

  path="$(toolkit_docker_logging_path "$root")" || {
    toolkit_docker_logging_error 'Docker configuration directory must be an existing real directory'
    return 1
  }
  parent="$(dirname -- "$path")"
  canonical_parent="$(realpath -e -- "$parent")" || {
    toolkit_docker_logging_error 'cannot resolve Docker configuration directory'
    return 1
  }
  [[ "$canonical_parent" == "$parent" ]] || {
    toolkit_docker_logging_error 'Docker configuration directory path must not contain symlinks or dot segments'
    return 1
  }
  parent_owner="$(stat -c '%u' -- "$parent")" || {
    toolkit_docker_logging_error 'cannot inspect Docker configuration directory owner'
    return 1
  }
  parent_mode="$(stat -c '%a' -- "$parent")" || {
    toolkit_docker_logging_error 'cannot inspect Docker configuration directory permissions'
    return 1
  }
  parent_mode="0$parent_mode"
  [[ "$parent_owner" == "$EUID" ]] && (((8#$parent_mode & 0022) == 0)) || {
    toolkit_docker_logging_error 'Docker configuration directory must be owned by the apply user and not group- or world-writable'
    return 1
  }

  if [[ -L "$path" || ( -e "$path" && ! -f "$path" ) ]]; then
    toolkit_docker_logging_error 'daemon.json must be absent or an existing regular file'
    return 1
  fi
  if [[ -e "$path" ]]; then
    had_file=true
    file_owner_group="$(stat -c '%u:%g' -- "$path")" || {
      toolkit_docker_logging_error 'cannot inspect daemon.json ownership'
      return 1
    }
    file_mode="$(stat -c '%a' -- "$path")" || {
      toolkit_docker_logging_error 'cannot inspect daemon.json permissions'
      return 1
    }
    file_mode="0$file_mode"
    source_mode="$file_mode"
    source_owner_group="$file_owner_group"
    [[ "${file_owner_group%%:*}" == "$EUID" ]] || {
      toolkit_docker_logging_error 'daemon.json must be owned by the apply user'
      return 1
    }
    (((8#$file_mode & 0022) == 0 && (8#$file_mode & 07000) == 0 && (8#$file_mode & 0111) == 0)) || {
      toolkit_docker_logging_error 'daemon.json permissions must not grant group/world write, execute, or special bits'
      return 1
    }
    state="$(toolkit_docker_logging_prepare "$path" state)" || return 1
    source_digest="$(sha256sum -- "$path")" || {
      toolkit_docker_logging_error 'cannot fingerprint existing daemon.json'
      return 1
    }
    source_digest="${source_digest%% *}"
    [[ "$source_digest" =~ ^[0-9a-f]{64}$ ]] || {
      toolkit_docker_logging_error 'existing daemon.json fingerprint is malformed'
      return 1
    }
  else
    state=configure
  fi

  if [[ "$state" == unchanged ]]; then
    if ! dockerd --validate --config-file "$path"; then
      toolkit_docker_logging_error 'dockerd rejected current daemon configuration'
      return 1
    fi
    toolkit_log info 'docker_logging_apply=unchanged config=daemon.json'
    return 0
  fi

  temporary="$(mktemp "$parent/.toolkit-docker-logs.XXXXXXXX")" || {
    toolkit_docker_logging_error 'cannot create staged Docker daemon configuration'
    return 1
  }
  toolkit_register_temp_path "$temporary"
  if [[ "$had_file" == true ]]; then
    toolkit_docker_logging_prepare "$path" render >"$temporary" || return 1
    chmod "$file_mode" "$temporary" || {
      toolkit_docker_logging_error 'cannot preserve daemon.json permissions'
      return 1
    }
    chown "$file_owner_group" "$temporary" || {
      toolkit_docker_logging_error 'cannot preserve daemon.json ownership'
      return 1
    }
  else
    toolkit_docker_logging_prepare - render >"$temporary" || return 1
    chmod 0644 "$temporary" || {
      toolkit_docker_logging_error 'cannot set daemon.json permissions'
      return 1
    }
    chown "$EUID:$(id -g)" "$temporary" || {
      toolkit_docker_logging_error 'cannot set daemon.json ownership'
      return 1
    }
  fi
  if ! dockerd --validate --config-file "$temporary"; then
    toolkit_docker_logging_error 'dockerd rejected staged daemon configuration'
    return 1
  fi

  if [[ "$had_file" == true ]]; then
    [[ -f "$path" && ! -L "$path" ]] || {
      toolkit_docker_logging_error 'daemon.json changed during validation; refusing to publish'
      return 1
    }
    current_digest="$(sha256sum -- "$path")" || {
      toolkit_docker_logging_error 'cannot verify daemon.json after validation'
      return 1
    }
    current_digest="${current_digest%% *}"
    [[ "$current_digest" == "$source_digest" ]] || {
      toolkit_docker_logging_error 'daemon.json changed during validation; refusing to overwrite it'
      return 1
    }
    current_mode="$(stat -c '%a' -- "$path")" || {
      toolkit_docker_logging_error 'cannot verify daemon.json permissions after validation'
      return 1
    }
    current_owner_group="$(stat -c '%u:%g' -- "$path")" || {
      toolkit_docker_logging_error 'cannot verify daemon.json ownership after validation'
      return 1
    }
    [[ "0$current_mode" == "$source_mode" && "$current_owner_group" == "$source_owner_group" ]] || {
      toolkit_docker_logging_error 'daemon.json metadata changed during validation; refusing to overwrite it'
      return 1
    }
  else
    [[ ! -e "$path" && ! -L "$path" ]] || {
      toolkit_docker_logging_error 'daemon.json appeared during validation; refusing to overwrite it'
      return 1
    }
  fi

  mv -fT -- "$temporary" "$path" || {
    toolkit_docker_logging_error 'cannot atomically publish daemon.json'
    return 1
  }
  toolkit_log info 'docker_logging_apply=updated config=daemon.json daemon_restart=deferred container_recreation=required'
}
