#!/usr/bin/env bash

declare -ga TOOLKIT_TEMP_PATHS=()

toolkit_register_temp_path() {
  TOOLKIT_TEMP_PATHS+=("$1")
}

toolkit_cleanup_temp_paths() {
  local path
  for path in "${TOOLKIT_TEMP_PATHS[@]}"; do
    case "$path" in
    /tmp/toolkit-validation.* | /tmp/toolkit-inspect.* | /tmp/toolkit-install.* | /opt/toolkit/.staging/release.*)
      [[ -d "$path" && ! -L "$path" ]] && rm -rf -- "$path"
      ;;
    */swapfile.toolkit.* | */.toolkit-swap-fstab.*)
      [[ -f "$path" && ! -L "$path" ]] && rm -f -- "$path"
      ;;
    /opt/toolkit/.current.* | /opt/toolkit/.previous.* | /usr/local/bin/.toolkit.*)
      [[ -L "$path" ]] && rm -f -- "$path"
      ;;
    */.toolkit-atomic.* | */.toolkit-docker-logs.*)
      [[ -f "$path" && ! -L "$path" ]] && rm -f -- "$path"
      ;;
    *) toolkit_log error 'refusing to clean an unregistered temporary path' ;;
    esac
  done
  TOOLKIT_TEMP_PATHS=()
}

TOOLKIT_ATOMIC_WRITE_ERROR=''

toolkit_atomic_write_file_try() {
  local target="$1" mode="$2" parent canonical_parent temporary parent_mode parent_owner mode_value
  TOOLKIT_ATOMIC_WRITE_ERROR=''
  [[ "$target" == /* && "$target" != *'/../'* && "$target" != */.. ]] || {
    TOOLKIT_ATOMIC_WRITE_ERROR='atomic file target must be an absolute normalized path'
    return 1
  }
  [[ "$mode" =~ ^(0[0-7]{3}|[0-7]{3,4})$ ]] || {
    TOOLKIT_ATOMIC_WRITE_ERROR='atomic file mode must be an octal mode'
    return 1
  }
  mode_value=$((8#$mode))
  (((mode_value & 07000) == 0 && (mode_value & 0022) == 0 && (mode_value & 0111) == 0)) || {
    TOOLKIT_ATOMIC_WRITE_ERROR='atomic file mode must not grant execute, group/world write, or special permissions'
    return 1
  }
  parent="$(dirname -- "$target")"
  [[ -d "$parent" && ! -L "$parent" ]] || {
    TOOLKIT_ATOMIC_WRITE_ERROR='atomic file parent must be an existing real directory'
    return 1
  }
  canonical_parent="$(realpath -e -- "$parent")" || {
    TOOLKIT_ATOMIC_WRITE_ERROR='cannot resolve atomic file parent'
    return 1
  }
  [[ "$canonical_parent" == "$parent" ]] || {
    TOOLKIT_ATOMIC_WRITE_ERROR='atomic file parent path must not contain symlinks or dot segments'
    return 1
  }
  parent_mode="$(stat -c '%a' -- "$parent")" || {
    TOOLKIT_ATOMIC_WRITE_ERROR='cannot inspect atomic file parent permissions'
    return 1
  }
  parent_mode="${parent_mode: -3}"
  (((8#$parent_mode & 0022) == 0)) || {
    TOOLKIT_ATOMIC_WRITE_ERROR='atomic file parent must not be group- or world-writable'
    return 1
  }
  parent_owner="$(stat -c '%u' -- "$parent")" || {
    TOOLKIT_ATOMIC_WRITE_ERROR='cannot inspect atomic file parent owner'
    return 1
  }
  [[ "$parent_owner" == "$EUID" ]] || {
    TOOLKIT_ATOMIC_WRITE_ERROR='atomic file parent must be owned by the calling user'
    return 1
  }
  if [[ -e "$target" || -L "$target" ]]; then
    [[ -f "$target" && ! -L "$target" ]] || {
      TOOLKIT_ATOMIC_WRITE_ERROR='atomic file target must be absent or a regular file'
      return 1
    }
  fi
  temporary="$(mktemp "$parent/.toolkit-atomic.XXXXXXXX")" || {
    TOOLKIT_ATOMIC_WRITE_ERROR='cannot create atomic file temporary'
    return 1
  }
  toolkit_register_temp_path "$temporary"
  cat >"$temporary" || {
    TOOLKIT_ATOMIC_WRITE_ERROR='cannot write atomic file temporary'
    return 1
  }
  chmod "$mode" "$temporary" || {
    TOOLKIT_ATOMIC_WRITE_ERROR='cannot set atomic file mode'
    return 1
  }
  mv -fT -- "$temporary" "$target" || {
    TOOLKIT_ATOMIC_WRITE_ERROR='cannot atomically publish file'
    return 1
  }
}

toolkit_atomic_write_file() {
  toolkit_atomic_write_file_try "$@" || toolkit_die "$TOOLKIT_ATOMIC_WRITE_ERROR"
}
