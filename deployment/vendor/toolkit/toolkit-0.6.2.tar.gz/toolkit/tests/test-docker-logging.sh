#!/usr/bin/env bash
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
temporary="$(mktemp -d)"
trap 'toolkit_cleanup_temp_paths; rm -rf -- "$temporary"' EXIT
source "$toolkit_root/lib/common.sh"
source "$toolkit_root/lib/files.sh"
source "$toolkit_root/lib/docker-logging.sh"

"$toolkit_root/bin/toolkit" plan --config "$toolkit_root/config/host.conf.example" >"$temporary/cli-plan.out"
grep -q '^docker_logging_action=' "$temporary/cli-plan.out"

root="$temporary/host"
mkdir -p "$root/etc/docker"
chmod 0755 "$root" "$root/etc" "$root/etc/docker"

DOCKERD_CALLS=0
DOCKERD_FAIL=false
dockerd() {
  [[ "$1" == --validate && "$2" == --config-file && "$3" == /* ]] || return 2
  ((DOCKERD_CALLS += 1))
  local config_path="$3"
  python3 - "$config_path" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as config_file:
    json.load(config_file)
PY
  [[ "$DOCKERD_FAIL" == false ]]
}

toolkit_docker_logging_plan "$root" >"$temporary/plan.out"
grep -q '^docker_logging_action=configure log_driver=json-file max_size=10m max_files=3$' "$temporary/plan.out"
[[ ! -e "$root/etc/docker/daemon.json" ]]

printf '{"data-root":"/srv/docker","log-opts":{"labels":"service"}}\n' >"$root/etc/docker/daemon.json"
chmod 0640 "$root/etc/docker/daemon.json"
toolkit_docker_logging_apply "$root" >"$temporary/apply.out" 2>&1
grep -q 'docker_logging_apply=updated' "$temporary/apply.out"
grep -q 'daemon_restart=deferred' "$temporary/apply.out"
[[ "$(stat -c '%a' "$root/etc/docker/daemon.json")" == 640 ]]
python3 - "$root/etc/docker/daemon.json" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as config_file:
    config = json.load(config_file)

assert config["data-root"] == "/srv/docker"
assert config["log-driver"] == "json-file"
assert config["log-opts"] == {"labels": "service", "max-file": "3", "max-size": "10m"}
PY
[[ "$DOCKERD_CALLS" == 1 ]]

toolkit_docker_logging_plan "$root" >"$temporary/plan.out"
grep -q '^docker_logging_action=unchanged log_driver=json-file max_size=10m max_files=3$' "$temporary/plan.out"
toolkit_docker_logging_apply "$root" >"$temporary/apply.out" 2>&1
grep -q 'docker_logging_apply=unchanged' "$temporary/apply.out"
[[ "$DOCKERD_CALLS" == 2 ]]

printf '{"data-root":"/srv/docker","log-driver":"journald"}\n' >"$root/etc/docker/daemon.json"
toolkit_docker_logging_plan "$root" >"$temporary/plan.out"
grep -q '^docker_logging_action=blocked reason=invalid_or_conflicting_daemon_config$' "$temporary/plan.out"
if toolkit_docker_logging_apply "$root" >"$temporary/conflict.out" 2>&1; then
  printf 'expected a conflicting log driver to be rejected\n' >&2
  exit 1
fi
grep -q 'conflicting log-driver' "$temporary/conflict.out"
grep -q '"log-driver":"journald"' "$root/etc/docker/daemon.json"
[[ "$DOCKERD_CALLS" == 2 ]]

printf '{invalid json\n' >"$root/etc/docker/daemon.json"
if toolkit_docker_logging_apply "$root" >"$temporary/invalid.out" 2>&1; then
  printf 'expected invalid JSON to be rejected\n' >&2
  exit 1
fi
grep -q 'invalid JSON' "$temporary/invalid.out"

printf '{"data-root":"/srv/docker"}\n' >"$root/etc/docker/daemon.json"
DOCKERD_FAIL=true
if toolkit_docker_logging_apply "$root" >"$temporary/validation-failure.out" 2>&1; then
  printf 'expected dockerd validation failure to be reported\n' >&2
  exit 1
fi
grep -q 'dockerd rejected staged daemon configuration' "$temporary/validation-failure.out"
[[ "$DOCKERD_CALLS" == 3 ]]
grep -q '"data-root":"/srv/docker"' "$root/etc/docker/daemon.json"
! grep -q '"log-driver"' "$root/etc/docker/daemon.json"

printf 'toolkit Docker logging checks passed\n'
