#!/usr/bin/env bash
# shellcheck disable=SC2034 # BACKUP_* settings are read by component files and helper functions
# Plain encrypted backups: producer | zstd | age | temp file | rclone copyto.
# The repository supplies a component list; this file knows nothing about applications.

declare -ag TOOLKIT_BACKUP_STOPPED=()
TOOLKIT_BACKUP_LOG=''
TOOLKIT_BACKUP_TMP=''
TOOLKIT_BACKUP_LOCK_FD=''

toolkit_backup_log() {
  printf '%s backup %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >&2
}

toolkit_backup_usage() {
  cat <<'USAGE'
Usage:
  toolkit backup run <repo> <4h|daily>
  toolkit backup list <repo> [component]
  toolkit backup check <repo>
  toolkit backup install-tools   (root; installs pinned age and rclone, zstd from apt)
  toolkit backup fetch <repo> <component> -o FILE [--tier daily|weekly|pinned] [--at TIME] [--version-at TIME] [--identity FILE]
USAGE
}

# Settings come from the environment first, then /etc/toolkit/backup/<repo>.env
# (KEY=VALUE lines, allowlisted keys only; the file is never executed).
toolkit_backup_load_config() {
  local repository="$1" file key value line
  toolkit_validate_slug "$repository" || toolkit_die 'backup repository must be a lowercase slug'
  file="${TOOLKIT_BACKUP_CONFIG_DIR:-/etc/toolkit/backup}/$repository.env"
  if [[ -f "$file" ]]; then
    [[ ! -L "$file" ]] || toolkit_die "backup config must not be a symlink: $file"
    if [[ "${TOOLKIT_BACKUP_TEST_MODE:-0}" != 1 ]]; then
      [[ "$(stat -c '%u:%a' "$file")" == 0:600 ]] || toolkit_die "backup config must be root-owned mode 0600: $file"
    fi
    while IFS= read -r line || [[ -n "$line" ]]; do
      [[ -n "$line" && "$line" != '#'* ]] || continue
      [[ "$line" == *=* ]] || toolkit_die "malformed line in $file"
      key="${line%%=*}"
      value="${line#*=}"
      case "$key" in
      BACKUP_BUCKET | BACKUP_B2_KEY_ID | BACKUP_B2_KEY | BACKUP_AGE_RECIPIENT | BACKUP_AGE_IDENTITY | BACKUP_HC_4H_URL | BACKUP_HC_DAILY_URL | BACKUP_HC_FRESHNESS_URL | BACKUP_ENVIRONMENT | BACKUP_COMPONENTS_FILE | BACKUP_REMOTE) ;;
      *) toolkit_die "unknown key $key in $file" ;;
      esac
      [[ -n "${!key:-}" ]] || printf -v "$key" '%s' "$value"
    done <"$file"
  fi
  BACKUP_ENVIRONMENT="${BACKUP_ENVIRONMENT:-production}"
  [[ -n "${BACKUP_BUCKET:-}" ]] || toolkit_die 'BACKUP_BUCKET is not set'
  BACKUP_REMOTE="${BACKUP_REMOTE:-:b2:$BACKUP_BUCKET}"
  # rclone reads backend credentials from the environment, so no secret reaches argv or a config file.
  if [[ -n "${BACKUP_B2_KEY_ID:-}" ]]; then
    export RCLONE_B2_ACCOUNT="$BACKUP_B2_KEY_ID" RCLONE_B2_KEY="${BACKUP_B2_KEY:-}"
  fi
  export RCLONE_CONFIG=/dev/null
}

toolkit_backup_weekday() {
  date -u +%u
}

toolkit_backup_ping() {
  local url="$1" suffix="$2" body="${3:-}"
  [[ -n "$url" ]] || return 0
  if [[ -n "$body" && -f "$body" ]]; then
    curl -fsS -m 10 --retry 3 --data-binary "@$body" -o /dev/null "$url$suffix" >/dev/null 2>&1 || toolkit_backup_log 'healthcheck ping failed'
  else
    curl -fsS -m 10 --retry 3 -o /dev/null "$url$suffix" >/dev/null 2>&1 || toolkit_backup_log 'healthcheck ping failed'
  fi
}

toolkit_backup_resume() {
  local index id failed=0
  for ((index = ${#TOOLKIT_BACKUP_STOPPED[@]} - 1; index >= 0; index--)); do
    id="${TOOLKIT_BACKUP_STOPPED[index]}"
    if docker start "$id" >/dev/null; then
      toolkit_backup_log "restarted container $id"
    else
      toolkit_backup_log "ERROR: failed to restart container $id"
      failed=1
    fi
  done
  ((failed == 1)) || TOOLKIT_BACKUP_STOPPED=()
  return "$failed"
}

toolkit_backup_pause() {
  local id
  for id in "$@"; do
    docker inspect --format '{{.State.Running}}' "$id" 2>/dev/null | grep -qx true || {
      toolkit_backup_log "ERROR: container to pause is not running: $id"
      return 1
    }
    TOOLKIT_BACKUP_STOPPED+=("$id")
    docker stop --time 30 "$id" >/dev/null || {
      toolkit_backup_log "ERROR: could not stop container: $id"
      return 1
    }
  done
}

# Waits for the repository's own lock only (never host.lock): deploys hold both, so a
# backup and a deploy of the same repository never overlap, while other repositories are unaffected.
toolkit_backup_lock() {
  local repository="$1" timeout="$2" root dir path
  root="${TOOLKIT_BACKUP_LOCK_ROOT:-/run/lock/toolkit}"
  dir="$root/repos/$repository"
  path="$dir/$BACKUP_ENVIRONMENT.lock"
  [[ ! -L "$root" && ! -L "$root/repos" && ! -L "$dir" && ! -L "$path" ]] || toolkit_die 'repository lock path must not be a symlink'
  install -d -m 0755 "$root" "$root/repos" "$dir" || toolkit_die 'cannot prepare repository lock directory'
  : >>"$path" || toolkit_die 'cannot open repository lock'
  chmod 0644 "$path" 2>/dev/null || true
  exec {TOOLKIT_BACKUP_LOCK_FD}>>"$path" || toolkit_die 'cannot open repository lock'
  toolkit_backup_log "waiting for repository lock repository=$repository timeout_seconds=$timeout"
  if ! flock -x -w "$timeout" "$TOOLKIT_BACKUP_LOCK_FD"; then
    exec {TOOLKIT_BACKUP_LOCK_FD}>&-
    TOOLKIT_BACKUP_LOCK_FD=''
    return 1
  fi
}

toolkit_backup_unlock() {
  [[ -z "$TOOLKIT_BACKUP_LOCK_FD" ]] && return 0
  flock -u "$TOOLKIT_BACKUP_LOCK_FD" || true
  exec {TOOLKIT_BACKUP_LOCK_FD}>&-
  TOOLKIT_BACKUP_LOCK_FD=''
}

# One component: producer | zstd | age > tmp. Succeeds only if every stage exited 0 and the file clears its size floor.
toolkit_backup_capture_component() {
  local component="$1" out="$2" fn status floor size
  local -a pause_ids=() stage_status=()
  fn="produce_${component//-/_}"
  declare -F "$fn" >/dev/null || {
    toolkit_backup_log "ERROR: $component has no producer function $fn"
    return 1
  }
  # shellcheck disable=SC2206 # pause lists are space-separated container names
  pause_ids=(${BACKUP_PAUSE[$component]:-})
  if ((${#pause_ids[@]})); then
    toolkit_backup_pause "${pause_ids[@]}" || {
      toolkit_backup_resume
      return 1
    }
  fi
  "$fn" 2>>"$TOOLKIT_BACKUP_LOG" | zstd -q -T0 -3 2>>"$TOOLKIT_BACKUP_LOG" | age -r "$BACKUP_AGE_RECIPIENT" 2>>"$TOOLKIT_BACKUP_LOG" >"$out"
  stage_status=("${PIPESTATUS[@]}")
  status=0
  if ((${#pause_ids[@]})); then
    toolkit_backup_resume || status=1
  fi
  [[ "${stage_status[*]}" == '0 0 0' ]] || {
    toolkit_backup_log "ERROR: $component pipeline failed (producer/zstd/age exit: ${stage_status[*]})"
    return 1
  }
  ((status == 0)) || return 1
  floor="${BACKUP_MIN_BYTES[$component]:-${BACKUP_DEFAULT_MIN_BYTES:-300}}"
  size="$(stat -c %s "$out")"
  ((size >= floor)) || {
    toolkit_backup_log "ERROR: $component output too small ($size < $floor bytes)"
    return 1
  }
}

toolkit_backup_upload() {
  local source="$1" destination="$2"
  # shellcheck disable=SC2086 # flags are intentionally split; they come from trusted config
  rclone copyto ${BACKUP_RCLONE_UPLOAD_FLAGS---b2-no-check-bucket --no-check-dest} "$source" "$BACKUP_REMOTE/$destination"
}

toolkit_backup_cleanup() {
  toolkit_backup_resume || true
  toolkit_backup_unlock
  [[ -z "$TOOLKIT_BACKUP_TMP" || ! -d "$TOOLKIT_BACKUP_TMP" ]] || rm -rf -- "$TOOLKIT_BACKUP_TMP"
}

toolkit_backup_run() {
  # systemd passes the unit instance as one argument: <repo>-<cadence>.
  if (($# == 1)) && [[ "$1" =~ ^(.+)-(4h|daily)$ ]]; then
    set -- "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}"
  fi
  (($# == 2)) || toolkit_die 'usage: toolkit backup run <repo> <4h|daily>'
  local repository="$1" cadence="$2" url_var url run_id timestamp component tier tool status=0 rc upload_failed
  local -a ok_components=() failed_components=() tiers=()
  [[ "$cadence" == 4h || "$cadence" == daily ]] || toolkit_die 'cadence must be 4h or daily'
  [[ "${TOOLKIT_BACKUP_TEST_MODE:-0}" == 1 ]] || toolkit_require_root
  toolkit_backup_load_config "$repository"
  [[ -n "${BACKUP_AGE_RECIPIENT:-}" ]] || toolkit_die 'BACKUP_AGE_RECIPIENT is not set'
  for tool in zstd age rclone flock curl; do
    command -v "$tool" >/dev/null 2>&1 || toolkit_die "required tool is missing: $tool"
  done
  toolkit_backup_load_components

  url_var=BACKUP_HC_4H_URL
  [[ "$cadence" == daily ]] && url_var=BACKUP_HC_DAILY_URL
  url="${!url_var:-}"
  run_id="$(cat /proc/sys/kernel/random/uuid 2>/dev/null || date -u +%s)"
  TOOLKIT_BACKUP_TMP="$(mktemp -d "${TOOLKIT_BACKUP_TMP_ROOT:-/var/tmp/toolkit-backup}.XXXXXX" 2>/dev/null)" || {
    install -d -m 0700 "$(dirname -- "${TOOLKIT_BACKUP_TMP_ROOT:-/var/tmp/toolkit-backup}")"
    TOOLKIT_BACKUP_TMP="$(mktemp -d "${TOOLKIT_BACKUP_TMP_ROOT:-/var/tmp/toolkit-backup}.XXXXXX")" || toolkit_die 'cannot create backup temp directory'
  }
  chmod 0700 "$TOOLKIT_BACKUP_TMP"
  TOOLKIT_BACKUP_LOG="$TOOLKIT_BACKUP_TMP/run.log"
  trap 'toolkit_backup_cleanup; exit 143' TERM INT

  toolkit_backup_ping "$url" "/start?rid=$run_id"
  toolkit_backup_log "run start repository=$repository cadence=$cadence"

  if ! toolkit_backup_lock "$repository" "${BACKUP_LOCK_TIMEOUT:-1800}"; then
    toolkit_backup_log "ERROR: timed out waiting for the $repository lock"
    failed_components+=(repository-lock)
  else
    for component in "${BACKUP_COMPONENTS[@]}"; do
      [[ "${BACKUP_CADENCE[$component]:-}" == 4h || "${BACKUP_CADENCE[$component]:-}" == daily ]] || {
        toolkit_backup_log "ERROR: $component has no valid cadence"
        failed_components+=("$component")
        continue
      }
      # A daily run also captures the 4h components so database and files are taken together.
      [[ "$cadence" == daily || "${BACKUP_CADENCE[$component]}" == 4h ]] || continue
      toolkit_backup_log "capturing $component"
      if toolkit_backup_capture_component "$component" "$TOOLKIT_BACKUP_TMP/$component.out"; then
        ok_components+=("$component")
      else
        failed_components+=("$component")
        rm -f -- "$TOOLKIT_BACKUP_TMP/$component.out"
      fi
    done
    toolkit_backup_unlock
  fi

  tiers=(daily)
  [[ "$cadence" == daily && "$(toolkit_backup_weekday)" == 7 ]] && tiers+=(weekly)
  timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
  for component in "${ok_components[@]}"; do
    upload_failed=0
    for tier in "${tiers[@]}"; do
      if toolkit_backup_upload "$TOOLKIT_BACKUP_TMP/$component.out" "$tier/$component/$timestamp.${BACKUP_EXT[$component]:-bin}.zst.age" 2>>"$TOOLKIT_BACKUP_LOG"; then
        toolkit_backup_log "uploaded $tier/$component"
      else
        toolkit_backup_log "ERROR: upload failed for $tier/$component"
        upload_failed=1
      fi
    done
    ((upload_failed == 0)) || failed_components+=("$component")
  done
  ((${#failed_components[@]} == 0)) || status=1
  toolkit_backup_log "run end ok=${#ok_components[@]} failed=${#failed_components[@]} failed_components=${failed_components[*]:-none}"
  rc=$status
  tail -n 100 "$TOOLKIT_BACKUP_LOG" >"$TOOLKIT_BACKUP_TMP/tail.log"
  ((rc == 0)) || cat -- "$TOOLKIT_BACKUP_TMP/tail.log" >&2
  toolkit_backup_ping "$url" "/$rc?rid=$run_id" "$TOOLKIT_BACKUP_TMP/tail.log"
  toolkit_backup_cleanup
  trap - TERM INT
  return "$rc"
}

toolkit_backup_list() {
  (($# >= 1 && $# <= 2)) || toolkit_die 'usage: toolkit backup list <repo> [component]'
  local repository="$1" component="${2:-}" tier
  toolkit_backup_load_config "$repository"
  for tier in daily weekly pinned; do
    { rclone lsf -R --files-only "$BACKUP_REMOTE/$tier${component:+/$component}" 2>/dev/null || true; } | sed "s|^|$tier${component:+/$component}/|"
  done | awk -F/ '{ print $NF "\t" $0 }' | sort -r | cut -f2-
}

# Pinned third-party tools. zstd comes from the Ubuntu archive; age and rclone are verified downloads.
TOOLKIT_BACKUP_AGE_VERSION=1.3.2
TOOLKIT_BACKUP_AGE_SHA256=cbe24006683f8eb669266162894b9a522a1af52f2665fbc63a4bb032ed26ac10
TOOLKIT_BACKUP_RCLONE_VERSION=1.75.2
TOOLKIT_BACKUP_RCLONE_SHA256=349ac8fba6ff65d6247043f1750cdcb518ec5d500ef91463a10d37c0ccdf3702

toolkit_backup_download_verified() {
  local url="$1" sha="$2" dest="$3"
  curl -fsSL -m 300 --retry 3 -o "$dest" "$url" || toolkit_die "download failed: $url"
  [[ "$(sha256sum -- "$dest" | cut -d' ' -f1)" == "$sha" ]] || toolkit_die "checksum mismatch for $url"
}

toolkit_backup_install_tools() {
  local bin="${TOOLKIT_BACKUP_BIN_DIR:-/usr/local/bin}" tmp base
  [[ "${TOOLKIT_BACKUP_TEST_MODE:-0}" == 1 ]] || toolkit_require_root
  tmp="$(mktemp -d)"
  if ! command -v zstd >/dev/null 2>&1 || ! command -v flock >/dev/null 2>&1 || ! command -v curl >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then
    apt-get install -y --no-install-recommends zstd util-linux curl unzip >&2 || toolkit_die 'cannot install zstd, flock, curl and unzip'
  fi
  if [[ "$("$bin/age" --version 2>/dev/null)" != "$TOOLKIT_BACKUP_AGE_VERSION"* && "$("$bin/age" --version 2>/dev/null)" != "v$TOOLKIT_BACKUP_AGE_VERSION"* ]]; then
    base="${TOOLKIT_BACKUP_AGE_URL:-https://github.com/FiloSottile/age/releases/download/v$TOOLKIT_BACKUP_AGE_VERSION/age-v$TOOLKIT_BACKUP_AGE_VERSION-linux-amd64.tar.gz}"
    toolkit_backup_download_verified "$base" "$TOOLKIT_BACKUP_AGE_SHA256" "$tmp/age.tgz"
    tar -xzf "$tmp/age.tgz" -C "$tmp" age/age age/age-keygen || toolkit_die 'cannot unpack age'
    install -m 0755 "$tmp/age/age" "$tmp/age/age-keygen" "$bin/" || toolkit_die 'cannot install age'
  fi
  if ! "$bin/rclone" version 2>/dev/null | head -1 | grep -q "v$TOOLKIT_BACKUP_RCLONE_VERSION\$"; then
    base="${TOOLKIT_BACKUP_RCLONE_URL:-https://github.com/rclone/rclone/releases/download/v$TOOLKIT_BACKUP_RCLONE_VERSION/rclone-v$TOOLKIT_BACKUP_RCLONE_VERSION-linux-amd64.zip}"
    toolkit_backup_download_verified "$base" "$TOOLKIT_BACKUP_RCLONE_SHA256" "$tmp/rclone.zip"
    unzip -q -j "$tmp/rclone.zip" "rclone-v$TOOLKIT_BACKUP_RCLONE_VERSION-linux-amd64/rclone" -d "$tmp" || toolkit_die 'cannot unpack rclone'
    install -m 0755 "$tmp/rclone" "$bin/rclone" || toolkit_die 'cannot install rclone'
  fi
  rm -rf -- "$tmp"
  printf 'age=%s rclone=%s zstd=%s
' "$("$bin/age" --version)" "$("$bin/rclone" version | head -1)" "$(zstd --version | head -1)"
}

toolkit_backup_load_components() {
  [[ -f "${BACKUP_COMPONENTS_FILE:-}" ]] || toolkit_die 'BACKUP_COMPONENTS_FILE is not a file'
  declare -ag BACKUP_COMPONENTS=()
  declare -Ag BACKUP_CADENCE=() BACKUP_EXT=() BACKUP_PAUSE=() BACKUP_MIN_BYTES=()
  # shellcheck disable=SC1090 # repository-owned component list
  source "$BACKUP_COMPONENTS_FILE"
  ((${#BACKUP_COMPONENTS[@]})) || toolkit_die 'component list is empty'
}

# Off-host freshness check (reader key): newest daily/ object per component must be recent and above its size floor.
toolkit_backup_check() {
  (($# == 1)) || toolkit_die 'usage: toolkit backup check <repo>'
  local repository="$1" component newest size stamp epoch now max_age floor problems=0 url body
  toolkit_backup_load_config "$repository"
  toolkit_backup_load_components
  now="$(date -u +%s)"
  body="$(mktemp)"
  for component in "${BACKUP_COMPONENTS[@]}"; do
    newest="$({ rclone lsf --files-only --format 'sp' "$BACKUP_REMOTE/daily/$component" 2>/dev/null || true; } | sort -t';' -k2 | tail -1)"
    if [[ -z "$newest" ]]; then
      printf 'STALE %s: no backups found
' "$component" >>"$body"
      problems=1
      continue
    fi
    size="${newest%%;*}"
    stamp="${newest#*;}"
    stamp="${stamp:0:16}"
    epoch="$(date -u -d "${stamp:0:4}-${stamp:4:2}-${stamp:6:2}T${stamp:9:2}:${stamp:11:2}:${stamp:13:2}Z" +%s 2>/dev/null)" || {
      printf 'STALE %s: unparsable name %s
' "$component" "$stamp" >>"$body"
      problems=1
      continue
    }
    max_age=$((${BACKUP_FRESHNESS_SLACK:-7200} + 86400))
    [[ "${BACKUP_CADENCE[$component]}" != 4h ]] || max_age=$((${BACKUP_FRESHNESS_SLACK:-7200} + 14400))
    floor="${BACKUP_MIN_BYTES[$component]:-${BACKUP_DEFAULT_MIN_BYTES:-300}}"
    if ((now - epoch > max_age)); then
      printf 'STALE %s: newest %s is %ss old (limit %ss)
' "$component" "$stamp" "$((now - epoch))" "$max_age" >>"$body"
      problems=1
    elif ((size < floor)); then
      printf 'SMALL %s: newest %s is %s bytes (floor %s)
' "$component" "$stamp" "$size" "$floor" >>"$body"
      problems=1
    else
      printf 'OK    %s: newest %s, %s bytes
' "$component" "$stamp" "$size" >>"$body"
    fi
  done
  cat -- "$body"
  url="${BACKUP_HC_FRESHNESS_URL:-}"
  toolkit_backup_ping "$url" "/$problems" "$body"
  rm -f -- "$body"
  return "$problems"
}

# Normalises 20261012T035500Z or 2026-10-12T03:55:00Z to the object-name form.
toolkit_backup_stamp() {
  local value="$1"
  if [[ "$value" =~ ^[0-9]{8}T[0-9]{6}Z$ ]]; then
    printf '%s\n' "$value"
  else
    date -u -d "$value" +%Y%m%dT%H%M%SZ 2>/dev/null || toolkit_die "cannot parse time: $value"
  fi
}

toolkit_backup_fetch() {
  (($# >= 2)) || toolkit_die 'usage: toolkit backup fetch <repo> <component> -o FILE [options]'
  local repository="$1" component="$2" tier=daily at='' version_at='' output='' identity='' pick object
  shift 2
  while (($#)); do
    case "$1" in
    -o | --output)
      (($# >= 2)) || toolkit_die "$1 requires a value"
      output="$2"
      shift 2
      ;;
    --tier)
      (($# >= 2)) || toolkit_die '--tier requires a value'
      tier="$2"
      shift 2
      ;;
    --at)
      (($# >= 2)) || toolkit_die '--at requires a value'
      at="$(toolkit_backup_stamp "$2")"
      shift 2
      ;;
    --version-at)
      (($# >= 2)) || toolkit_die '--version-at requires a value'
      version_at="$2"
      shift 2
      ;;
    --identity)
      (($# >= 2)) || toolkit_die '--identity requires a value'
      identity="$2"
      shift 2
      ;;
    *) toolkit_die "unknown fetch option: $1" ;;
    esac
  done
  [[ -n "$output" ]] || toolkit_die 'fetch requires -o FILE'
  [[ "$tier" =~ ^(daily|weekly|pinned)$ ]] || toolkit_die 'tier must be daily, weekly or pinned'
  [[ -e "$output" ]] && toolkit_die "refusing to overwrite $output"
  toolkit_backup_load_config "$repository"
  identity="${identity:-${BACKUP_AGE_IDENTITY:-}}"
  [[ -f "$identity" ]] || toolkit_die 'age identity file is required (--identity or BACKUP_AGE_IDENTITY)'
  local -a rclone_flags=()
  [[ -z "$version_at" ]] || rclone_flags+=(--b2-version-at "$version_at")
  pick="$(rclone lsf "${rclone_flags[@]}" --files-only "$BACKUP_REMOTE/$tier/$component" | sort | awk -v at="$at" '{ stamp = substr($0, 1, 16); if (at == "" || stamp <= at) last = $0 } END { print last }')" || toolkit_die 'cannot list backups'
  [[ -n "$pick" ]] || toolkit_die "no $tier backup of $component found"
  object="$tier/$component/$pick"
  toolkit_backup_log "fetching $object"
  local partial="$output.partial"
  rclone cat "${rclone_flags[@]}" "$BACKUP_REMOTE/$object" | age -d -i "$identity" | zstd -d -q -o "$partial"
  local -a stage_status=("${PIPESTATUS[@]}")
  if [[ "${stage_status[*]}" != '0 0 0' ]]; then
    rm -f -- "$partial"
    toolkit_die "fetch pipeline failed (rclone/age/zstd exit: ${stage_status[*]})"
  fi
  mv -- "$partial" "$output"
  printf 'object=%s output=%s\n' "$object" "$output"
}

toolkit_backup() {
  (($# >= 1)) || {
    toolkit_backup_usage >&2
    exit 2
  }
  local verb="$1"
  shift
  case "$verb" in
  run) toolkit_backup_run "$@" ;;
  list) toolkit_backup_list "$@" ;;
  check) toolkit_backup_check "$@" ;;
  install-tools) toolkit_backup_install_tools ;;
  fetch) toolkit_backup_fetch "$@" ;;
  help | --help | -h) toolkit_backup_usage ;;
  *) toolkit_die "unknown backup action: $verb" ;;
  esac
}
