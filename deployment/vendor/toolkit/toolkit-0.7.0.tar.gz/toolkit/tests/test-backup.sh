#!/usr/bin/env bash
# Exercises `toolkit backup` with real zstd, age and rclone (local backend) and stub docker/curl.
set -euo pipefail

toolkit_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
for tool in zstd age age-keygen rclone flock; do
  command -v "$tool" >/dev/null 2>&1 || {
    printf 'test-backup.sh needs %s installed\n' "$tool" >&2
    exit 1
  }
done
work="$(mktemp -d)"
trap 'rm -rf -- "$work"' EXIT
export TOOLKIT_VERSION=test
# shellcheck disable=SC1090
for lib in common files platform config; do source "$toolkit_root/lib/$lib.sh"; done
source "$toolkit_root/commands/backup.sh"

fail() {
  [ -f "$work/run.out" ] && cat "$work/run.out" >&2
  printf 'FAIL: %s\n' "$*" >&2
  exit 1
}
assert_file() { [[ -f "$1" ]] || fail "missing file: $1"; }
assert_contains() { grep -Fq -- "$2" "$1" || fail "$1 does not contain: $2"; }
assert_not_contains() { ! grep -Fq -- "$2" "$1" || fail "$1 unexpectedly contains: $2"; }

# --- fixtures ---------------------------------------------------------------
mkdir -p "$work/bin" "$work/remote" "$work/etc"
age-keygen -o "$work/identity.txt" 2>"$work/keygen.err"
recipient="$(sed -n 's/^# public key: //p' "$work/identity.txt")"
[[ "$recipient" == age1* ]] || fail 'could not generate an age key'

cat >"$work/bin/docker" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "$*" >>"$FAKE_DOCKER_LOG"
case "$1" in
inspect) echo true ;;
stop | start) [[ "$FAKE_DOCKER_FAIL" == "$1" ]] && exit 1 ;;
esac
exit 0
STUB
cat >"$work/bin/curl" <<'STUB'
#!/usr/bin/env bash
body=''
for arg in "$@"; do
  case "$arg" in
  @*) body="$(<"${arg#@}")" ;;
  http*) url="$arg" ;;
  esac
done
printf 'PING %s\n' "$url" >>"$FAKE_CURL_LOG"
[[ -z "$body" ]] || printf 'BODY %s\n' "$body" >>"$FAKE_CURL_LOG"
STUB
chmod +x "$work/bin/docker" "$work/bin/curl"
export PATH="$work/bin:$PATH"
export FAKE_DOCKER_LOG="$work/docker.log" FAKE_CURL_LOG="$work/curl.log" FAKE_DOCKER_FAIL=none

cat >"$work/components.sh" <<'COMPONENTS'
BACKUP_COMPONENTS=(db-one db-bad files-one tiny)
BACKUP_DEFAULT_MIN_BYTES=100
BACKUP_CADENCE["db-one"]=4h
BACKUP_CADENCE["db-bad"]=4h
BACKUP_CADENCE["files-one"]=daily
BACKUP_CADENCE["tiny"]=daily
BACKUP_EXT["db-one"]=sql
BACKUP_EXT["db-bad"]=sql
BACKUP_EXT["files-one"]=tar
BACKUP_EXT["tiny"]=sql
BACKUP_PAUSE["files-one"]="app-container"
BACKUP_PAUSE["db-bad"]="bad-container"
BACKUP_MIN_BYTES["tiny"]=100000
produce_db_one() { echo "payload-db-one $(date +%s%N)"; }
produce_db_bad() { echo "partial"; return 7; }
produce_files_one() { echo "payload-files"; }
produce_tiny() { echo x; }
COMPONENTS

new_config() {
  cat >"$work/etc/repo.env" <<CONFIG
BACKUP_BUCKET=test-bucket
BACKUP_B2_KEY_ID=KEYID-visible-nowhere
BACKUP_B2_KEY=SECRET-never-log-this
BACKUP_AGE_RECIPIENT=$recipient
BACKUP_AGE_IDENTITY=$work/identity.txt
BACKUP_HC_4H_URL=https://hc.example/ping/four-hours-secret
BACKUP_HC_DAILY_URL=https://hc.example/ping/daily-secret
BACKUP_COMPONENTS_FILE=$work/components.sh
BACKUP_REMOTE=$work/remote
CONFIG
}
new_config
chmod 600 "$work/etc/repo.env"

run_backup() {
  : >"$FAKE_DOCKER_LOG"
  : >"$FAKE_CURL_LOG"
  (
    export TOOLKIT_BACKUP_TEST_MODE=1 TOOLKIT_BACKUP_CONFIG_DIR="$work/etc" TOOLKIT_BACKUP_LOCK_ROOT="$work/locks" \
      TOOLKIT_BACKUP_TMP_ROOT="$work/tmp/run" BACKUP_RCLONE_UPLOAD_FLAGS=''
    mkdir -p "$work/tmp"
    toolkit_backup_weekday() { printf '%s\n' "${FAKE_WEEKDAY:-3}"; }
    toolkit_backup run repo "$@"
  ) >"$work/run.out" 2>&1
}

# --- 4h run: only 4h components, partial failure tolerated ------------------
FAKE_WEEKDAY=3
set +e
run_backup 4h
rc=$?
set -e
((rc != 0)) || fail '4h run with a failing component must exit non-zero'
[[ -z "$(ls "$work/remote/daily/db-bad" 2>/dev/null)" ]] || fail 'failed component must not upload'
assert_file "$(ls "$work/remote"/daily/db-one/*.sql.zst.age | head -1)"
[[ ! -e "$work/remote/daily/files-one" ]] || fail 'daily component must not run on a 4h run'
[[ ! -e "$work/remote/weekly" ]] || fail 'weekly tier written outside the Sunday daily run'
assert_contains "$FAKE_CURL_LOG" 'four-hours-secret/start?rid='
assert_contains "$FAKE_CURL_LOG" 'four-hours-secret/1?rid='
assert_not_contains "$work/run.out" 'SECRET-never-log-this'
assert_not_contains "$work/run.out" 'four-hours-secret'
assert_not_contains "$FAKE_CURL_LOG" 'SECRET-never-log-this'
# Containers paused for a failing producer must still be restarted.
assert_contains "$FAKE_DOCKER_LOG" 'stop --time 30 bad-container'
assert_contains "$FAKE_DOCKER_LOG" 'start bad-container'

name="$(ls "$work/remote"/daily/db-one/ | head -1)"
[[ "$name" =~ ^[0-9]{8}T[0-9]{6}Z\.sql\.zst\.age$ ]] || fail "unexpected object name: $name"

# --- daily run on Sunday: everything, plus weekly ---------------------------
FAKE_WEEKDAY=7
sleep 1
set +e
run_backup daily
rc=$?
set -e
((rc != 0)) || fail 'daily run with failing components must exit non-zero'
assert_file "$(ls "$work/remote"/daily/files-one/*.tar.zst.age | head -1)"
assert_file "$(ls "$work/remote"/weekly/files-one/*.tar.zst.age | head -1)"
assert_file "$(ls "$work/remote"/weekly/db-one/*.sql.zst.age | head -1)"
[[ ! -e "$work/remote/daily/tiny" ]] || fail 'output below the size floor must not upload'
assert_contains "$work/run.out" 'output too small'
assert_contains "$FAKE_CURL_LOG" 'daily-secret/1?rid='
assert_contains "$FAKE_DOCKER_LOG" 'stop --time 30 app-container'
assert_contains "$FAKE_DOCKER_LOG" 'start app-container'
[[ "$(ls "$work/tmp" | wc -l)" == 0 ]] || fail 'temp directory not cleaned up'

# --- all-green run exits zero and pings success -----------------------------
cat >"$work/components.sh" <<'COMPONENTS'
BACKUP_COMPONENTS=(db-one)
BACKUP_DEFAULT_MIN_BYTES=100
BACKUP_CADENCE["db-one"]=4h
BACKUP_EXT["db-one"]=sql
produce_db_one() { echo "payload-db-one"; }
COMPONENTS
FAKE_WEEKDAY=1
run_backup 4h || fail 'all-green run should succeed'
assert_contains "$FAKE_CURL_LOG" 'four-hours-secret/0?rid='

# --- upload failure is reported ---------------------------------------------
cat >"$work/bin/rclone-fail" <<'STUB'
#!/usr/bin/env bash
exit 1
STUB
chmod +x "$work/bin/rclone-fail"
mkdir -p "$work/failbin"
cp "$work/bin/rclone-fail" "$work/failbin/rclone"
for tool in zstd age; do ln -sf "$(command -v $tool)" "$work/failbin/$tool"; done
set +e
(PATH="$work/failbin:$PATH" run_backup 4h)
rc=$?
set -e
((rc != 0)) || fail 'upload failure must exit non-zero'

# --- lock contention: wait, then fail without running producers -------------
mkdir -p "$work/locks/repos/repo"
: >"$work/locks/repos/repo/production.lock"
(flock -x "$work/locks/repos/repo/production.lock" sleep 6) &
holder=$!
sleep 1
rm -rf "$work/remote"
set +e
(BACKUP_LOCK_TIMEOUT=1 run_backup 4h)
rc=$?
set -e
wait "$holder" || true
((rc != 0)) || fail 'lock timeout must exit non-zero'
assert_contains "$work/run.out" 'timed out waiting for the repo lock'
[[ ! -e "$work/remote" ]] || fail 'nothing may upload when the lock is not acquired'
assert_contains "$FAKE_CURL_LOG" 'four-hours-secret/1?rid='

# --- list and fetch round trip ----------------------------------------------
cat >"$work/components.sh" <<'COMPONENTS'
BACKUP_COMPONENTS=(db-one)
BACKUP_DEFAULT_MIN_BYTES=100
BACKUP_CADENCE["db-one"]=4h
BACKUP_EXT["db-one"]=sql
produce_db_one() { echo "version $(date +%s%N)"; }
COMPONENTS
FAKE_WEEKDAY=1
run_backup 4h
sleep 1
run_backup 4h
listing="$(
  export TOOLKIT_BACKUP_TEST_MODE=1 TOOLKIT_BACKUP_CONFIG_DIR="$work/etc"
  toolkit_backup list repo db-one
)"
[[ "$(wc -l <<<"$listing")" == 2 ]] || fail "expected two listed backups, got: $listing"
newest="$(head -1 <<<"$listing")"
oldest="$(tail -1 <<<"$listing")"
[[ "$newest" > "$oldest" ]] || fail 'list must be newest first'

fetch() (
  export TOOLKIT_BACKUP_TEST_MODE=1 TOOLKIT_BACKUP_CONFIG_DIR="$work/etc"
  toolkit_backup fetch repo db-one "$@"
)
fetch -o "$work/latest.sql" >/dev/null 2>&1
grep -q '^version ' "$work/latest.sql" || fail 'fetched content is wrong'
oldest_stamp="$(basename "$oldest")"
oldest_stamp="${oldest_stamp%%.*}"
fetch -o "$work/at.sql" --at "$oldest_stamp" >/dev/null 2>&1
cmp -s <(rclone cat "$work/remote/daily/db-one/$(basename "$oldest")" | age -d -i "$work/identity.txt" | zstd -dq) "$work/at.sql" || fail '--at did not select the older backup'
if fetch -o "$work/at.sql" >/dev/null 2>&1; then fail 'fetch must refuse to overwrite'; fi
if fetch -o "$work/none.sql" --tier weekly >/dev/null 2>&1; then fail 'fetch of a missing tier must fail'; fi
[[ ! -e "$work/none.sql" && ! -e "$work/none.sql.partial" ]] || fail 'failed fetch left files behind'
printf 'garbage' >"$work/remote/daily/db-one/99990101T000000Z.sql.zst.age"
if fetch -o "$work/corrupt.sql" >/dev/null 2>&1; then fail 'corrupt backup must fail to fetch'; fi
[[ ! -e "$work/corrupt.sql" && ! -e "$work/corrupt.sql.partial" ]] || fail 'corrupt fetch left files behind'

# --- single-argument instance form used by systemd --------------------------
FAKE_WEEKDAY=1
sleep 1
(
  export TOOLKIT_BACKUP_TEST_MODE=1 TOOLKIT_BACKUP_CONFIG_DIR="$work/etc" TOOLKIT_BACKUP_LOCK_ROOT="$work/locks" TOOLKIT_BACKUP_TMP_ROOT="$work/tmp/run" BACKUP_RCLONE_UPLOAD_FLAGS=''
  toolkit_backup run repo-4h
) >"$work/run.out" 2>&1 || fail 'instance form run repo-4h should work'
assert_contains "$work/run.out" 'cadence=4h'

# --- freshness check --------------------------------------------------------
cat >"$work/components.sh" <<'COMPONENTS'
BACKUP_COMPONENTS=(fresh stale small missing)
BACKUP_CADENCE["fresh"]=4h
BACKUP_CADENCE["stale"]=4h
BACKUP_CADENCE["small"]=daily
BACKUP_CADENCE["missing"]=daily
BACKUP_MIN_BYTES["small"]=500
COMPONENTS
rm -rf "$work/remote"
stamp_now="$(date -u +%Y%m%dT%H%M%SZ)"
stamp_old="$(date -u -d '8 hours ago' +%Y%m%dT%H%M%SZ)"
mkdir -p "$work/remote/daily"/{fresh,stale,small}
head -c 400 /dev/zero >"$work/remote/daily/fresh/$stamp_now.sql.zst.age"
head -c 400 /dev/zero >"$work/remote/daily/stale/$stamp_old.sql.zst.age"
head -c 100 /dev/zero >"$work/remote/daily/small/$stamp_now.sql.zst.age"
: >"$FAKE_CURL_LOG"
check() (
  export TOOLKIT_BACKUP_TEST_MODE=1 TOOLKIT_BACKUP_CONFIG_DIR="$work/etc"
  printf 'BACKUP_HC_FRESHNESS_URL=https://hc.example/ping/fresh-secret
' >>"$work/etc/repo.env"
  toolkit_backup check repo
)
if check >"$work/check.out" 2>&1; then fail 'check must fail when anything is stale, small or missing'; fi
assert_contains "$work/check.out" 'OK    fresh'
assert_contains "$work/check.out" 'STALE stale'
assert_contains "$work/check.out" 'SMALL small'
assert_contains "$work/check.out" 'STALE missing: no backups found'
assert_contains "$FAKE_CURL_LOG" 'fresh-secret/1'
rm -rf "$work/remote/daily/stale" "$work/remote/daily/small"
mkdir -p "$work/remote/daily/missing"
cat >"$work/components.sh" <<'COMPONENTS'
BACKUP_COMPONENTS=(fresh)
BACKUP_CADENCE["fresh"]=4h
COMPONENTS
: >"$FAKE_CURL_LOG"
check >"$work/check.out" 2>&1 || fail 'check should pass with fresh backups'
assert_contains "$FAKE_CURL_LOG" 'fresh-secret/0'
new_config

# --- pinned tool installer --------------------------------------------------
if command -v unzip >/dev/null 2>&1; then
  mkdir -p "$work/dl/age" "$work/dl/rc/rclone-v1.75.2-linux-amd64" "$work/tools"
  printf '#!/bin/sh
echo v%s
' "$TOOLKIT_BACKUP_AGE_VERSION" >"$work/dl/age/age"
  cp "$work/dl/age/age" "$work/dl/age/age-keygen"
  tar -czf "$work/dl/age.tgz" -C "$work/dl" age
  printf '#!/bin/sh
echo rclone v1.75.2
' >"$work/dl/rc/rclone-v1.75.2-linux-amd64/rclone"
  (cd "$work/dl/rc" && zip -qr ../rclone.zip rclone-v1.75.2-linux-amd64)
  install_tools() (
    PATH="${PATH#"$work/bin:"}" # real curl, not the ping stub
    export TOOLKIT_BACKUP_TEST_MODE=1 TOOLKIT_BACKUP_BIN_DIR="$work/tools" TOOLKIT_BACKUP_AGE_URL="file://$work/dl/age.tgz" TOOLKIT_BACKUP_RCLONE_URL="file://$work/dl/rclone.zip"
    # shellcheck disable=SC2034
    TOOLKIT_BACKUP_AGE_SHA256="$(sha256sum "$work/dl/age.tgz" | cut -d' ' -f1)"
    # shellcheck disable=SC2034
    TOOLKIT_BACKUP_RCLONE_SHA256="$(sha256sum "$work/dl/rclone.zip" | cut -d' ' -f1)"
    # shellcheck disable=SC2034 # read by toolkit_backup_install_tools
    toolkit_backup_install_tools
  )
  install_tools >"$work/run.out" 2>&1 || fail 'install-tools should succeed with matching checksums'
  [[ -x "$work/tools/age" && -x "$work/tools/rclone" ]] || fail 'install-tools did not install binaries'
  rm -f "$work/tools/age" "$work/tools/rclone"
  if (
    PATH="${PATH#"$work/bin:"}"
    export TOOLKIT_BACKUP_TEST_MODE=1 TOOLKIT_BACKUP_BIN_DIR="$work/tools" TOOLKIT_BACKUP_AGE_URL="file://$work/dl/age.tgz"
    toolkit_backup_install_tools
  ) >/dev/null 2>&1; then fail 'install-tools must reject a checksum mismatch'; fi
  [[ ! -e "$work/tools/age" ]] || fail 'mismatched download was installed'
fi

# --- config hardening -------------------------------------------------------
printf 'BACKUP_EVIL=1\n' >>"$work/etc/repo.env"
if (
  export TOOLKIT_BACKUP_TEST_MODE=1 TOOLKIT_BACKUP_CONFIG_DIR="$work/etc"
  toolkit_backup list repo
) >/dev/null 2>&1; then fail 'unknown config key must be rejected'; fi
new_config
chmod 644 "$work/etc/repo.env"
if (
  export TOOLKIT_BACKUP_CONFIG_DIR="$work/etc"
  toolkit_backup_load_config repo
) >/dev/null 2>&1; then fail 'group/world-readable config must be rejected outside test mode'; fi

printf 'toolkit backup checks passed\n'
